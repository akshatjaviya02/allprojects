// Author: Akshat Javiya
// Section: CPSC240-09
// Email: akshatjaviya02@csu.fullerton.edu
// Program Purpose: The file is Displaying the values that user inputed.
#include <cstdlib>
#include <ctype.h>
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <string>
#include <cmath>

extern "C" void Display(double arr[], int arr_size);

// Prints the contents of the array, up to arr_size, determined by the fill asm
// module

void Display(double arr[], int arr_size) {
  std::cout << "You have entered\n";

  for (int i = 0; i < arr_size; i++) {
    if (i == 0) {
      std::cout << std::fixed << std::setprecision(3) << arr[i] << " volts\n";
    }
    if (i == 1) {
      std::cout << std::fixed << std::setprecision(3) << arr[i] << " ohms\n";
    }
  }
}
