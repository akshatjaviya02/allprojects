// Author: Akshat Javiya
// Section: CPSC240-09
// Email: akshatjaviya02@csu.fullerton.edu
// Program Purpose: The file is Displaying the power that code as calculated.
#include <cstdlib>
#include <ctype.h>
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <string>
#include <cmath>

extern "C" double show_power(double arr);

double show_power(double arr) {
  std::cout << "The work performed is " << arr << " Watts\n";
  return arr;
}
