# Author: Akshat Javiya
# Section: CPSC240-09
# Email: akshatjaviya02@csu.fullerton.edu
# Program Purpose: It will Compiling C++ and Asm files together.
rm *.o
rm *.out

echo "Compiling the files"
nasm -f elf64 -l faraday.lis -o faraday.o faraday.asm
nasm -f elf64 -l get_electricity.lis -o get_electricity.o get_electricity.asm
g++ -c -m64 -Wall -o ampere.o ampere.cpp -fno-pie -no-pie -std=c++17
g++ -c -m64 -Wall -o show_electricity.o show_electricity.cpp -fno-pie -no-pie -std=c++17
g++ -c -m64 -Wall -o show_power.o show_power.cpp -fno-pie -no-pie -std=c++17
g++ -m64 -o power.out ampere.o faraday.o show_power.o show_electricity.o get_electricity.o -fno-pie -no-pie -std=c++17

echo "Starts running the program"
./power.out

echo "The bash script file is now closing."
