#include <iostream>
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>

#include <iomanip>

// Declare and extern function to make it callable by other linked files.
// Declaration of area function in assembly.
extern "C" double triangle();

int main() {
  double result_code = 0.0;
  std::cout << "Welcome to Pythagoras, Inc.\nWe make the cheapest triangle anywhere. Visit us at www.cheaptriangles.com.\n\n";

  // Call assembly area function.
  result_code = triangle();
  // Print out area received from area() in 16 bit Hexidecimal.

  std::cout << "The driver recieved this number %lf and will keep it." << result_code;

  // Prints out goodbye message.
  std::cout << "\nAn integer zero will now be sent to the operating system. Have a good day.  Bye\n";
  return 0;
}
