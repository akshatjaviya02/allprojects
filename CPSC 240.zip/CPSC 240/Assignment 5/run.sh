#!/bin/bash


#Author: Akshat Javiya
#Program name: Triangle

rm *.o
rm *.out

echo "Compiling the files"

nasm -f elf64 -l triangle.lis -o triangle.o triangle.asm
g++ -c -m64 -Wall -o geometry.o geometry.cpp -fno-pie -no-pie -std=c++17
g++ -m64 -o triangle.out geometry.o triangle.o -fno-pie -no-pie -std=c++17

echo "Starts running the program"
./triangle.out

echo "The bash script file is now closing."
