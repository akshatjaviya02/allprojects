// Author: Akshat Javiya
// Section: CPSC 240-09
// Email: akshatjaviya02@csu.fullerton.edu
// Program Purpose: The file is the driver file which will call the resistance.asm.
// function.
#include <cmath>
#include <cstdlib>
#include <ctype.h>
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <string>

// Declare and extern function to make it callable by other linked files.
// Declaration of area function in assembly.
extern "C" double resistance();


int main() {
  double result_code = 0.0;
  // Call assembly area function.
  std::cout << "Welcome to the Electric Resistance Program by Timothy Light Jones\n";
  result_code = resistance();
  std::cout << "The caller received this number " << std::fixed
            << std::setprecision(9) << result_code
            << " and will keep it.\nA zero will be sent to the OS as a signal of success.\n";
  return 0;
}
