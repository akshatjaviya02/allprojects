# Author: Akshat Javiya
# Section: CPSC 240-09
# Email: akshatjaviya02@csu.fullerton.edu
# Program Purpose: It will Compiling C++ and Asm files together with gdb.
rm *.o
rm *.out

echo "Compiling the files"

nasm -f elf64 -l resistance.lis -o resistance.o resistance.asm -g -gdwarf
g++ -c -m64 -Wall -o driver.o driver.cpp -fno-pie -no-pie -std=c++17 -g
g++ -m64 -o resistance.out driver.o resistance.o -fno-pie -no-pie -std=c++17 -g

echo "Starts running the program"
gdb ./resistance.out

echo "The bash script file is now closing."
