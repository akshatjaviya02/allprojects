# Author: Akshat Javiya
# Section: CPSC240-09
# Email: akshatjaviya02@csu.fullerton.edu
# Program Purpose: It will Compiling C++ and Asm files together.
rm *.o
rm *.out

echo "Compiling the files"
nasm -f elf64 -l roots.lis -o roots.o roots.asm
g++ -c -m64 -Wall -o quad.o quad.cpp -fno-pie -no-pie -std=c++17
nasm -f elf64 -l display_values.lis -o display_values.o display_values.asm
nasm -f elf64 -l get_coeff.lis -o get_coeff.o get_coeff.asm
g++ -c -m64 -Wall -o noroots.o noroots.cpp -fno-pie -no-pie -std=c++17
g++ -c -m64 -Wall -o oneroot.o oneroot.cpp -fno-pie -no-pie -std=c++17
nasm -f elf64 -l tworoots.lis -o tworoots.o tworoots.asm
g++ -m64 -o quads.out quad.o roots.o tworoots.o display_values.o noroots.o oneroot.o get_coeff.o -fno-pie -no-pie -std=c++17

echo "Starts running the program"
./quads.out

echo "The bash script file is now closing."
