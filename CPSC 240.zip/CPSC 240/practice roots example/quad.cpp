// Author: Akshat Javiya
// Section: CPSC240-09
// Email: akshatjaviya02@csu.fullerton.edu
// Program Purpose: The file is the driver file which will call the faraday.asm.
// function.
#include <cmath>
#include <cstdlib>
#include <ctype.h>
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <string>

// Declare and extern function to make it callable by other linked files.
// Declaration of area function in assembly.
extern "C" double root();
extern "C" bool isFloat(char[]);

//IsFloat for the checking the number
bool isFloat(char w[]) {
  bool result = true;
  bool onepoint = false;
  int start = 0;
  unsigned long int k = start;
  while (!(w[k] == '\0') && result) {
    if (w[k] == '.' && !onepoint)
      onepoint = true;
    else
      result = result && isdigit(w[k]);
    k++;
  }
  return result && onepoint;
}

int main() {
  double result_code = 0.0;
  // Call assembly area function.
  std::cout << "Welcome to quadratic Computation by Aksaht Javiya\n"
               "We handle all your Math\n";
  result_code = root();
  std::cout << "Ampere received this unrecognized value " << std::fixed
            << std::setprecision(2) << result_code
            << " and will keep it.\nZero will be returned to the OS. Bye"
               ", and will keep it.\n";
  return 0;
}
