#!/bin/bash


#Author: Akshat Javiya
#Program name: Triangle

rm *.o
rm *.out

echo "Compiling the files"

nasm -f elf64 -l triangle.lis -o triangle.o triangles.asm
g++ -c -m64 -Wall -o triangle-driver.o triangles-driver.cpp -fno-pie -no-pie -std=c++17
g++ -m64 -o triangles.out triangle-driver.o triangle.o -fno-pie -no-pie -std=c++17

echo "Starts running the program"
./triangles.out

echo "The bash script file is now closing."
