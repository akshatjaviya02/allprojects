#include <cstdlib> // Header to include atof function in area.asm.
#include <ctype.h> // Header to include isdigit function.
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <string>

// Declare and extern function to make it callable by other linked files.
// Declaration of area function in assembly.
extern "C" double height();
extern "C" bool isFloat(char [ ]);

bool isFloat(char w[ ])
{   bool result = true;
    bool onepoint = false;
    int start = 0;
    unsigned long int k = start;
    while (!(w[k] == '\0') && result )
    {    if (w[k] == '.' && !onepoint)
               onepoint = true;
         else
               result = result && isdigit(w[k]) ;
         k++;
     }
     return result && onepoint;
}

int main() {
  double result_code = 0.0;
  std::cout
      << "Welcome to Gravitational Attraction maintained by Sergio Gonzalez."
      << "\n This program was last updated on February 24, 2022.\n\n";

  // Call assembly area function.
  result_code = height();
  // Print out area received from area() in 16 bit Hexidecimal.
  std::cout << "The driver recieved this number " << std::fixed
            << std::setprecision(9) << result_code << ", and will keep it.\n";

  // Prints out goodbye message.
  std::cout << "An integer zero will now be sent to the operating system.  "
               "Have a good day.  Bye\n";
  return 0;
}
