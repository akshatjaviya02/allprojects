#Author: Akshat Javiya
#Program name: Height

rm *.o
rm *.out

echo "Compiling the files"

nasm -f elf64 -l height.lis -o height.o height.asm -g
g++ -c -m64 -Wall -o driver.o driver.cpp -fno-pie -no-pie -std=c++17 -g
g++ -m64 -o height.out driver.o height.o -fno-pie -no-pie -std=c++17 -g

echo "Starts running the program"
gdb ./height.out

echo "The bash script file is now closing."
