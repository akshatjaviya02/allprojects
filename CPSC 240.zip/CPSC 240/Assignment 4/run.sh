#Author: Akshat Javiya
#Program name: manager calculator

rm *.o
rm *.out

echo "Compiling the files"
nasm -f elf64 -l manager.lis -o manager.o manager.asm -g
nasm -f elf64 -l compute_sum.lis -o compute_sum.o compute_sum.asm -g
g++ -c -m64 -Wall -o driver.o driver.cpp -fno-pie -no-pie -std=c++17 -g
g++ -c -m64 -Wall -o output_one_line.o output_one_line.cpp -fno-pie -no-pie -std=c++17 -g
g++ -m64 -o manager.out driver.o output_one_line.o compute_sum.o manager.o -fno-pie -no-pie -std=c++17 -g
echo "Starts running the program"
gdb ./manager.out

echo "The bash script file is now closing."
