#include <cstdlib> // Header to include atof function in area.asm.
#include <ctype.h> // Header to include isdigit function.
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <string>
#include <cmath>

extern "C" void Display(double value, int position);
extern "C" bool Check(int user, int it);
bool Check(int user, int it) {
  if(user == it) {
    return true;
  }
  return false;
}
void Display(double value, int position) {
    std::cout << position << "\t\t" << value << "\n";
}
