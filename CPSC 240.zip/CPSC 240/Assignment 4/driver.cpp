#include <cstdlib> // Header to include atof function in area.asm.
#include <ctype.h> // Header to include isdigit function.
#include <iomanip>
#include <iostream>
#include <stdio.h>
#include <string>
#include <cmath>

// Declare and extern function to make it callable by other linked files.
// Declaration of area function in assembly.
extern "C" double manager();

int main() {
  double result_code = 0.0;
  // Call assembly area function.
  std::cout << "Welcome to Harmonic Sum created by author Akshat Javiya.\n";
  result_code = manager();
  // Print out area received from area() in 16 bit Hexidecimal.
  std::cout << "The Assessor’s Office received this number " << std::fixed
            << std::setprecision(5) << result_code << ", and will keep it.\n";
  // Prints out goodbye message.
  std::cout << "Next an integer 0 will be sent to the operating system as a "
               "signal of successful completion.\n";
  return 0;
}
