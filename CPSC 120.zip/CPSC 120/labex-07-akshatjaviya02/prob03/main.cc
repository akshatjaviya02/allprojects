#include <iostream>
#include <string>

using std::cin;
using std::cout;
using std::endl;

int main() {
  int input;
  cout << "Enter a number n: ";
  cin >> input;

  // Determine the Fibonacci number for |input| and display it to the user.
  // Check the user input to know how to properly show
  // the message (e.g., 1st, 2nd, 3rd, ... 11th, 12th, 13th, ... 21st.. etc).
  // Don't forget to include fib.h.

  return 0;
}
