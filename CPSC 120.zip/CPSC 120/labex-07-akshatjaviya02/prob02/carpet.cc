#include "carpet.h"

void DrawCarpet(int x, int y, int size, int order, graphics::Image& image) {
  // Your code here to draw a carpet with top left corner at (x, y), recursive
  // order |order|, and size |size|, onto the graphics::Image provided.
}
