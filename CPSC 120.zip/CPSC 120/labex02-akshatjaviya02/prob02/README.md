# Find the Errors
In this program, you will debug a program that contains compile-time bugs and logical errors (run-time bugs).

## main.cpp
1. Try compiling the program to find out what errors the compiler finds.
1. Find and fix the compile-time bug(s).
1. Once the program compiles, try running it to see whether it outputs the expected results.
1. Find and fix any errors in the output results (these are run-time bugs).
1. Be sure your program output exactly matches the *Sample Output* below.

# Hints
1. Feel free to use labex01 prob02 as an example of cin/cout and computations.
1. The compiler outputs the line number and column of the error if a compile time error is encountered.
   e.g., `main.cpp:27:37` indicates an error on line 27, column 37
1. Try running the program with different widths and lengths, and ensure it is calculating the area correctly with each of the different input values.

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
What is the room's "width" in feet? <b>9.2</b>
What is the room's "length" in feet? <b>8.7</b>

The "area" of the room is 80.04 square feet.
Thank you for using the area calculator!
</pre>

## Sample Output #2
<pre>
What is the room's "width" in feet? <b>11.5</b>
What is the room's "length" in feet? <b>17.8</b>

The "area" of the room is 204.7 square feet.
Thank you for using the area calculator!
</pre>
