// This program calculates the tax and tip on a restaurant bill.
#include <iostream>

int main()
{
  double tax,tip, total_bill, meal_cost, total_tax,total_tip;
  std::cout <<"Welcome to the Restaurant Bill Calculator!"<< std::endl;

  // Get the meal cost
  std::cout <<"what is the total meal cost? ";
  std::cin >> meal_cost;

  // Get the tax on meal
  tax=0.0775;
  total_tax= meal_cost * tax;

  // Get the tip on meal
  tip= 0.20;
  total_tip= meal_cost * tip;

  // Get the total of the Restaurant Bill
  total_bill= total_tax + total_tip + meal_cost;

  // Display the Restaurant bill
  std::cout <<"Tax:" << total_tax << std::endl;
  std::cout << "Tip:" << total_tip << std::endl;
  std::cout << "Total Bill:" << total_bill << std::endl;

  return 0;
}
