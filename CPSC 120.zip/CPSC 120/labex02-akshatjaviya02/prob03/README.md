# Restaurant Bill
In this program, you will be learning to use the basic C++ programming constructs, such as cout and assignment statements.

## main.cpp
Write a program that computes the tax and tip on a restaurant bill.
1. The tax should be 7.75% of the meal cost, and the tip should be 20% of the meal cost.
1. The program should prompt the user to enter the total meal charge.
1. The program should then calculate the tax and tip, as well as the total bill after tax and tip are applied.
1. The program should then display the tax amount, tip amount, and total bill, as shown in the *Sample Output* below.

# Hints
1. Feel free to use labex01 prob02 as an example for cin/cout.
1. Choose variable names that explain the purpose of the variable.
1. Try using the `\t` <tab> escape character to line the results up.

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Welcome to the Restaurant Bill Calculator!

What is the total meal cost? $<b>9.22</b>

Tax:        $0.71455
Tip:        $1.844
Total Bill: $11.77855
</pre>

## Sample Output #2
<pre>
Welcome to the Restaurant Bill Calculator!

What is the total meal cost? $<b>44.50</b>

Tax:        $3.44875
Tip:        $8.9
Total Bill: $56.8487
</pre>
