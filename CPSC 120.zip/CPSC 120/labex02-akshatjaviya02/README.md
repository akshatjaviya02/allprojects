#  Lab Exercise 2 Objectives
1. Learn to use variables
1. Output results in different forms
1. Compile and run program

# Additional Reading
Chapter 2 of the course textbook.

# Instructions
Follow the README files for each problem assigned (e.g., prob01, prob02, prob03). If you have questions let your instructor know. You are also welcome to consult your classmates.

# Completion checklist
1. Did you use variable names appropriate for the purpose/usage of the variable?
1. Does your program compile? (i.e. no errors when you run clang++)
1. Does your program produce the desired results?
1. Does the GitHub Website show your latest code updates?

# Code evaluation
1. Get a copy of the lab exercise from GitHub. See labex00 for details if needed.

   ```
   git clone URL
   ```

1. Open the terminal and navigate to the folder that contains this exercise. For instance, if you have pulled the code inside of `/home/student/labex01-tuffy` and you are currently in `/home/student` you can type the following command.

   ```
   cd labex01-tuffy
   ```

1. You also need to navigate into the problem you want to answer. To access the files needed to answer problem 1, for example, you need to type the following command.

   ```
   cd prob01
   ```

1. When you want to answer another problem, you need to go back up to the parent folder and navigate into the next problem. For instance, if you are currently in `prob01`, you can type the following commands to go to the parent folder then go into another problem you want to answer; `prob02` for example.

   ```
   cd ..
   cd prob02
   ```

1. Use the `clang++` command to compile your code and the `./` command to run it. The sample code below shows how you would compile code saved in `main.cpp` into the executable file `main`. Make sure you use the correct filenames required in this problem.  Take note that if you make any changes to your code, you will need to again compile it before you see the changes when running it.

   ```
   clang++ -std=c++17 main.cpp -o main
   ./main
   ```

# Submission
1. To upload your code into the GitHub repository, the first step is to add your code to what is called the staging area using git's `add` command. The parameter after `add` is the name of the file you want to add. There are cases when you have multiple changed files, so you can just type . (period) to add all modified files.

    ```
    git add .
    ```

1. Once everything is in the staging area, we use the `commit` command to tell git that we have added everything we need into the staging area. This command can be issued with a message informing users of the changes made.

    ```
    git commit -m "Description of your code changes"
    ```

1. In case it asks you  to configure global variables for an email and name, just copy the commands it provides then replace the dummy text with your email and GitHub username.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```

    When you're done, make sure you type the `git commit` command again.

1. And finally, you can upload all changes to the GitHub repository using git's `push` command. Provide your GitHub username and password when you are prompted for these.

    ```
    git push
    ```
