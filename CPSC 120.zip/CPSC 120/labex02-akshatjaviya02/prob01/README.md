# Diamond Pattern
In this program, you will be learning to use the basic C++ programming constructs, such as cout.

## main.cpp
Write a program that displays a diamond pattern on the screen.

# Sample Output
```
   *
  ***
 *****
*******
 *****
  ***
   *
```
