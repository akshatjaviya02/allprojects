// This program prompts the user for a positive integer value and outputs
// a message indicating whether it is a prime number.
#include <iostream>
#include <string>
#include <cctype>
#include <cstring>
#include <cstdlib>
#include <iomanip>
#include <ctime>
#include <cmath>
#include <fstream>
#include "utilities.hpp"

int main ()
{
  int num;
  bool prime;

  num = getNumberInput();
  prime = isPrime(num);

  if(prime)
  {
    std::cout << "" << num << " is prime, It is divisible by 1 and itself.\n";
  }
  else
  {
    std::cout << "" << num << " is not a prime.\n";
  }

  return 0;
}
