// this program is a driver to test the isPrime() function

#include <iostream>
#include "utilities.hpp"

int main()
{
  int num, count = 0;

  num = -1000;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = -1;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 0;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 1;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 2;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 3;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 4;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 5;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 6;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 7;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 8;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 9;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 10;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 11;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 12;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 13;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 97;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  num = 100;
  std::cout << "Test#" << ++count << ": value " << num << " ("
    << (!isPrime(num) ? "PASS)" : "FAIL)") << std::endl;

  return 0;
}
