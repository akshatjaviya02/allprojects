//----------------------------
// function prototypes
//----------------------------

// this function prompts the user to enter the value for one of the sides
// of a rectangle, and returns that value to the caller
bool isPrime(int num);
int getNumberInput();
