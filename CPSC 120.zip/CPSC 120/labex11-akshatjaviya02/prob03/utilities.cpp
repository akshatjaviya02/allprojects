#include <iostream>
#include <sstream>
#include "utilities.hpp"

// this function returns true if the number input is a prime number
// and false otherwise
bool isPrime(int num)
{
  if (num > 1)
  {
    for (int counter = num -1; counter > 1; counter--)
    {
      if (num % counter == 0)
      {
        return false;
      }
    }
    return true;
  }
  return false;
}

// this function prompts the user to enter the value for one of the sides
// of a rectangle, and returns that value to the caller
// this function accepts a string parameter which represents the type of
// side, for instance length or width
int getNumberInput()
{
  int num;
  bool valid = false;
  std::string temp;

  // get a valid integer from the user
  do
  {
    std::cout << "Please enter a number: ";
    getline(std::cin, temp);

    // this converts the user input into a string stream
    std::stringstream ss(temp);

    // verify that the user input is a positive integer
    // note that if this is the case then "ss >> num" will successfully read
    // an integer, and "ss >> temp" will not successfully read a string
    // note: the "ss >> temp" call is rewriting to the temp string which is
    // fine since we don't need its value any longer
    if (ss >> num && !(ss >> temp) && num > 0)
    {
      valid = true;
    }
    else
    {
      std::cin.clear(); // just in case an error occurs with cin (eof, etc)
      std::cout << "Input must be a positive integer.\n";
    }
  } while (!valid);

  return num;
}
