# Is Prime Number
In this program, you will be using C++ programming constructs, such as functions and loops.

## main.cpp
Write a program that asks the user to enter a positive integer, and outputs a message indicating whether the integer is a prime number. If the user enters a negative integer, output an error message.

The body of `main()` will call both the `getNumberInput()` and the `isPrime()` functions.

## isPrime()
Create a function called `isPrime()` that contains one integer parameter, and returns a boolean result. If the integer input is a prime number, then this function returns true, and false otherwise. This function will be called by `main()`

You will place the function definition in `utilities.cpp` and the function prototype in `utilities.hpp`

*Note that negative numbers are not considered prime, nor are 0 or 1, but 2 is. All other numbers are prime if the only numbers by which they are evenly divisible are 1 and the number itself.*

## getNumberInput()
This function has been provided for you. You do not need to make any changes to this function. However, you will call this function from `main()`

## Input Validation
1. Verify the user enters an integer value, and continue asking till the input value is valid
1. If the integer input is a negative number, output an error message

# Hints
1. For numbers 3 and greater, one way to determine whether the number is prime is to loop through all numbers from 2 through `number - 1` to see if the number is evenly divisible by one of these numbers
   - *Hint: use the modulus operator.*
1. A more efficient way would be to check from 2 through the square root of `number` since the square root represents the half way point for multipliers
   - *This enhancement is not required, as long as your program produces the correct results.*

# Compile
Since your program includes two cpp files, you need to type the following in order to compile your program.
```
clang++ -std=c++17 main.cpp utilities.cpp -o main
```

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Please enter a number: <b>91</b>
91 is not prime.
</pre>

## Sample Output #2
<pre>
Please enter a number: <b>-1</b>
Input must be a positive integer.
Please enter a number: <b>0</b>
Input must be a positive integer.
Please enter a number: <b>59</b>
59 is prime. It is divisible only by 1 and itself.
</pre>

# Test Driver
In this lab, we have a test driver that calls your function `isPrime()` using various different argument values, and outputs whether each of the tests passed.

To compile the test driver program, type the following from the command prompt
```
clang++ -std=c++17 driver.cpp utilities.cpp -o driver
```
And to run the tests, type the following
```
./driver
```

*If using an online compiler, in order to run the test driver, you would replace your file `main.cpp` with the file `driver.cpp` and run the program.*

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure the results are written to a file, not the Terminal window*
     - *Be sure the output file has all of the same text as the input file*
1. **Error check**
   - Does your program print an error and ask again if the user enters an invalid value?
1. **Test driver**
   - Does your program pass all tests in the test driver program?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
