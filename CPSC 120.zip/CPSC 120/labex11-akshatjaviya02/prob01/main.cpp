// This program requests 3 integers from the user and displays the largest
// one entered. It then requests 3 characters from the user and displays
// the largest character entered, or an error message.

#include <iostream>
#include <cctype>


// This function receives 3 unsigned integer values and displays the value
// of the largest one. The caller has the option to pass into the function
// either 1, 2, or 3 unsigned integer arguments.

// TODO: add function prototype for showBiggest that takes unsigned int

void showBiggest(unsigned int num1, unsigned int num2 = 0, unsigned int num3 = 0);

// This function receives 3 character values and displays the value
// of the largest one. Note that uppercase letters are considered
// larger than lowercase letters, and if any of the characters input
// are not alphabetic, this function displays an error message.

// TODO: add function prototype for showBiggest that takes char

void showBiggest(char c1, char c2, char c3);

//-----------
// main()
//-----------

int main()
{
  unsigned int num1, num2, num3;
  char char1, char2, char3;

  // ask user for 3 numbers
  std::cout << "Please enter 3 integers: ";
  std::cin >> num1 >> num2 >> num3;

  // display the largest integer
  showBiggest(num1, num2, num3);
  std::cout << std::endl;

  // ask user for 3 characters
  std::cout << "Please enter 3 characters: ";
  std::cin >> char1 >> char2 >> char3;
  std::cout << std::endl;

  // display the largest of the 3 characters
  showBiggest(char1, char2, char3);

  // test various calls to showBiggest, including only 1 or 2 arguments
  unsigned int i1 = 1, i5 = 5, i7 = 7;
  char ca = 'a', cF = 'F', cR = 'R';

  std::cout << "\nAdditional tests:\n";
  showBiggest(i1, i5, i7);
  showBiggest(i5, i7, i1);
  showBiggest(i7, i1, i5);
  showBiggest(i1, i7, i5);
  showBiggest(i5, i1, i7);
  showBiggest(i7, i5, i1);
  showBiggest(i1, i7);
  showBiggest(i7, i5);
  showBiggest(i7);
  showBiggest(ca, cF, cR);
  showBiggest(cF, cR, ca);
  showBiggest(cR, ca, cF);
  showBiggest(ca, cR, cF);
  showBiggest(cF, ca, cR);
  showBiggest(cR, cF, ca);
  showBiggest(cR, cF, '$');
  showBiggest(cR, '@', ca);
  showBiggest('%', cF, ca);

  return 0;
}

//----------------------
// Function Definitions
//----------------------

void showBiggest(unsigned int num1, unsigned int num2, unsigned int num3)
{
  int high = 0;

  // TODO: compare the numeric values of the integers
  // and print whichever has the largest value
  if (num1 > num2 && num3 < num1)
  {
    high = num1;
  }
  else if (num2 > num3 && num2 > num1)
  {
    high = num2;
  }
  else if (num3 > num2 && num3 > num1)
  {
    high = num3;
  }
  std::cout << "The biggest number from the set ("
    << num1 << ", " << num2 << ", " << num3 << ") is: " << high << '\n';
}



// this function prints the largest of the three input characters
// if any of the chars are non-alphabetic, this function prints
// an error message
void showBiggest(char c1, char c2, char c3)
{
  char letterhigh;
  // TODO: check that all characters are alphabetic, and if any is
  // not then print an error message
  if (!(isalpha(c1) && isalpha(c2) && isalpha(c3)))
  {
    std::cout << "All characters must be alphabetic" << std::endl;
  }
  else
  {

    // if the character is lowercase, the following subtracts off the ASCII
    // value of 'a' in order to make uppercase letters come out larger than
    // lowercase (moves them all down such that lowercase 'a' starts at 0)
    char comp1 = c1;
    char comp2 = c2;
    char comp3 = c3;
    std::cout << "The biggest character from the set ("
      << comp1 << ", " << comp2 << ", " << comp3 << ") is: ";

    if (islower(c1))
    {
      comp1 -= 'a';
    }
    if (islower(c2))
    {
      comp2 -= 'a';
    }
    if (islower(c3))
    {
      comp3 -= 'a';
    }

    // TODO: compare the numeric values of the characters
    // and print whichever has the largest value
    if (comp1 > comp2 && comp3 < comp1)
    {
      letterhigh = c1;
    }
    else if (comp2 > comp3 && comp2 > comp1)
    {
      letterhigh = c2;
    }
    else if (comp3 > comp2 && comp3 > comp1)
    {
      letterhigh = c3;
    }
    std::cout << letterhigh << std::endl;
  }
}
