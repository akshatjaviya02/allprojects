# Show Biggest Value
In this program, you will be using C++ programming constructs, such as overloaded functions.

## main.cpp
***The function `main()` has been provided for you. You do not need to modify this function.***

This program requests 3 integers from the user and displays the largest one entered. It then requests 3 characters from the user and display the largest character entered. If the user enters a non-alphabetic character, the program will display an error message.

## showBiggest
Note that the function to display the largest integer and largest character have been partially written. Please find the TODO statements to fill in the rest of these functions.

This function is overloaded, meaning there are two functions with the same name, but different definitions and different function headers.

You also need to add the function prototypes for these two functions at the top of your program. *Be sure to define the function that takes unsigned int such that parameters 2 and 3 are optional.*

## Input Validation
1. For the purposes of this program, it is OK to assume the user enters valid integers for the first 3 inputs
1. For the 3 character inputs, display an error message if the user enters anything other than an alphabetic character for any of the 3 characters

# Hints
1. The `cctype` library offers a function called `isalpha()`
1. Keep in mind that the numeric ASCII values for uppercase characters are lower than those for lowercase characters, and make sure your program handles this *(this portion of the code has been provided)*

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Please enter 3 integers: <b>89 33 210</b>
The biggest number from the set (89, 33, 210) is 210

Please enter 3 characters: <b>c F z</b>
The biggest character from the set (c, F, z) is F

Additional tests:
The biggest number from the set (1, 5, 7) is: 7
The biggest number from the set (5, 7, 1) is: 7
The biggest number from the set (7, 1, 5) is: 7
The biggest number from the set (1, 7, 5) is: 7
The biggest number from the set (5, 1, 7) is: 7
The biggest number from the set (7, 5, 1) is: 7
The biggest number from the set (1, 7, 0) is: 7
The biggest number from the set (7, 5, 0) is: 7
The biggest number from the set (7, 0, 0) is: 7
The biggest character from the set (a, F, R) is: R
The biggest character from the set (F, R, a) is: R
The biggest character from the set (R, a, F) is: R
The biggest character from the set (a, R, F) is: R
The biggest character from the set (F, a, R) is: R
The biggest character from the set (R, F, a) is: R
All characters must be alphabetic
All characters must be alphabetic
All characters must be alphabetic
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
1. **Error check**
   - Does your program print an error if the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
