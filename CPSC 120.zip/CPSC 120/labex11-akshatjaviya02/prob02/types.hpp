//-----------
// Constants
//-----------

// shipping distance per segment
const int SEGMENT_MILES = 500;

// weight cutoff in lbs
const int WEIGHT_CUTOFF = 10; // lbs

// rates per 500 miles shipped
const double RATE_LOW = 3.10; // pkgs weighing <= 10 lb
const double RATE_HIGH = 6.40; // pkgs > 10 lb

//---------------------
// Function prototypes
//---------------------

// This function receives a package weight in lbs and
// a shipping distance in miles. It uses these to compute
// and return the shipping charge.
double calculateCharge(double weight, int distance);
