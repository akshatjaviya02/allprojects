# Shipping Charges
In this program, you will be using C++ programming constructs, such as functions and loops.

## main.cpp
Write a program that allows the user to enter the information for multiple packages to determine the shipping charges for each package. The program will exit when the user enters 0 for the package weight.

If the user enters a valid value for the package weight, the program then asks for the distance. If the user enters an invalid value for distance, the program will display an error message and ask again.

Once the program has valid values *(both positive integers)* for both weight and distance, the program will call the function `calculateCharge()` to calculate the shipping charges.

The function `main()` will then output the proper charge with a precision of 2 digits past the decimal point.

The `main()` function should continue prompting the user for the next package until the user enters 0 to exit the loop. ***Please use nested do/while loops for the two different user input values. The outer loop will ask for weight, and the inner loop will ask for distance, but only after a valid weight has been entered.***

## types.hpp
Constants have been defined for the shipping rates and the distance segment length. Please use these in your program.

Also, please add the function prototype for `calculateCharge()`

## calculateCharge()
Create a function called `calculateCharge()` that contains the following 2 parameters:
  - A double to represent the weight of the package
  - An integer to represent the distance the package will be shipped

This function returns a *double* for the shipping charge.

This function calculates the charge based on the package weight and distance. The rates per weight are defined in `types.hpp` and will be multiplied by the number of segments the package will be traveling.

For instance, if the distance is 1 to 500 miles, then the rate is multiplied by 1. If the distance is 501-1000 miles, then the rate is multiplied by 2 (for 2 segments). 1001-1500 is multiplied by 3, 1501-2000 is multiplied by 4, and so forth.

Please use the **constants** in your calculations.

## Input Validation
*The following is already being done within the function `getNumberInput()` - you do not need to modify this function.*
1. You can assume the user will always input numeric values
1. Package weight
   - If the user input is zero, then exit the program. And if the input is negative, then output an error message before prompting the user again for the weight of the package
1. Distance
   - If the user input is zero or negative, then output an error message and prompt the user again for the distance

# Hints
1. Be sure to include the file `types.hpp` inside `main.cpp` so that the compiler knows where to find the program constants and function prototype
1. To calculate the number of segments, you could divide the distance by the constant for the segment length, and add 1 to this result. However, you will need to add special handling for when the distance is evenly divisible by the segment length
   - Without this special handling, then for instance a distance of 500 will be charged for 2 segments, when it should actually be charged for 1 segment. *A couple of ways to do this:*
     - You could use the modulus operator to check for this boundary condition and adjust the segments accordingly
     - Or instead, you could subtract 1 from the distance before doing the division calculation as described above

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Welcome to Fast Freight Shipping Company

Enter the package weight in lbs (or 0 to exit): <b>0</b>
</pre>

## Sample Output #2
<pre>
Welcome to Fast Freight Shipping Company

Enter the package weight in lbs (or 0 to exit): <b>-3</b>
Package weight must be greater than 0.
Enter the package weight in lbs (or 0 to exit): <b>33</b>
Enter shipping distance in number of miles: <b>0</b>
Distance must be greater than 0.
Enter shipping distance in number of miles: <b>-300</b>
Distance must be greater than 0.
Enter shipping distance in number of miles: <b>300</b>

Shipping cost: $6.40

Enter the package weight in lbs (or 0 to exit): <b>0</b>
</pre>

## Sample Output #3
<pre>
Welcome to Fast Freight Shipping Company

Enter the package weight in lbs (or 0 to exit): <b>3.4</b>
Enter shipping distance in number of miles: <b>501</b>

Shipping cost: $8.40

Enter the package weight in lbs (or 0 to exit): <b>3.4</b>
Enter shipping distance in number of miles: <b>500</b>

Shipping cost: $4.20

Enter the package weight in lbs (or 0 to exit): <b>1.7</b>
Enter shipping distance in number of miles: <b>1500</b>

Shipping cost: $9.30

Enter the package weight in lbs (or 0 to exit): <b>1.7</b>
Enter shipping distance in number of miles: <b>1501</b>

Shipping cost: $12.40

Enter the package weight in lbs (or 0 to exit): <b>1.1</b>
Enter shipping distance in number of miles: <b>1</b>

Shipping cost: $3.10

Enter the package weight in lbs (or 0 to exit): <b>0</b>
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used a constant instead of a hardcoded literals in your expressions and calculations*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure the cost will always be displayed with 2 digits past the decimal*
1. **Error check**
   - Does your program print an error and ask again if the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
