// Given the weight of a package and the distance it is to be shipped,
// this program uses a function to determine the shipping charge. The
// main function contains a sentinel-controlled loop that allows multiple
// packages to be handled until a package weight of 0 is entered.

#include <iostream>
#include <iomanip>
#include "types.hpp"
double calculateCharge(double weight, int distance);

int main()
{
  double weight;
  int distance;
  double menuchocie = 1;

  std::cout << "Welcome to Fast Freight Shipping Company\n";
  do
  {
    std::cout << "Enter the package weight in lbs (or 0 to exit): ";
    std::cin >> weight;
    if (weight > 0)
    {
      do
      {
        std::cout << "Enter shipping distance in number of miles: ";
        std::cin >> distance;
        if (distance <= 0)
        {
          std::cout << "Distance must be greater than 0.\n";
        }
      } while(distance <= 0);
      std::cout << std::fixed << std::setprecision(2) << "The totalt cost is: $" << calculateCharge(weight, distance) << std::endl;

    }
    else if (weight < 0)
    {
      std::cout << "Package weight must be greater than 0.\n";
    }
  } while (weight != 0);
  return 0;
}

double calculateCharge(double weight, int distance)
{
  int rate;

  rate = (distance / SEGMENT_MILES) + 1;
  if ((distance % SEGMENT_MILES) == 0)
  {
    rate--;
  }
  if (weight <=  WEIGHT_CUTOFF)
  {
    return rate * RATE_LOW;
  }
  else
  {
    return rate * RATE_HIGH;
  }
}
