// Grading Exams
// This program checks an answer set against the answer key and outputs how
// many questions were right.

#include <iostream>
#include <fstream>

// constants
const int NUM_QUESTIONS = 10;

// function prototypes
bool getStudentExam(char student_exam[], int num_questions, std::string file_name);
int gradeExam(char answer_key[], char student_exam[], int num_questions);

int main()
{
  // answer key contains the correct answer for each of the questions
  char answer_key[NUM_QUESTIONS] =
    { 'B', 'D', 'A', 'A', 'C', 'A', 'B', 'A', 'C', 'D' };

  char student_exam[NUM_QUESTIONS];

  // get the name of the input file from the user
  std::string file_name;
  std::cout << "Enter file name: ";
  std::cin >> file_name;

  // TODO
  // call "getStudentExam()" to read the student's exam from a file
  // be sure you use the constant NUM_QUESTIONS for the number of elements
  // in the array
  bool res;
  res = getStudentExam(student_exam, NUM_QUESTIONS, file_name);


  if (res)
  {
    // TODO
    // call "gradeExam()" to grade the exam
    int num_correct;
    num_correct = gradeExam(answer_key, student_exam, NUM_QUESTIONS);


    // let the user know how many they got right
    std::cout << "You got " << num_correct << " right out of "
      << NUM_QUESTIONS << std::endl;
  }
  return 0;
}

// read in student's exam from a file
bool getStudentExam(char student_exam[], int num_questions, std::string file_name)
{
  bool success = false;

  // open the file containing the student answers
  std::ifstream infile;
  infile.open(file_name);

  // TODO
  // make sure the file exists
  // if file is not found, output a message to the user
  // otherwise set the success flag to true and read in
  // all answers into the student array
  // note that "num_questions" contains the length of the arrays
  if (infile)
  {
    success = true;
    infile.close();
  }
  else
  {
    success = false;
    std::cout << "Error opening file \"" << file_name << "\"" << std::endl;
  }

  return success;
}

// TODO
// Create a function called "gradeExam"
// Hint: you can use the function prototype at the top of this file
// Parameters:
//   1. array of the correct answers
//   2. array of the student's answers
//   3. the number of elements in the arrays
// Return Value:
//   The number of answers the student got right
//   In other words, the number of times the answers in the 2 arrays match

// Function description:
// This function loops through the two arrays received, comparing the answers
// in each to be sure they match. This function ignores case, so for example
// a is equivalent to A
int gradeExam(char answer_key[], char student_exam[], int num_questions)
{
  int count = 0;
  int i;
  for (i = 0; i < num_questions; ++i)
  {
    if ((student_exam[i] == 'A' || student_exam[i] == 'a') == (answer_key[i] == 'A'))
   {
     count++;
   }
   else if ((student_exam[i] == 'B' || student_exam[i] == 'b') == (answer_key[i] == 'B'))
   {
     count++;
   }
   else if ((student_exam[i] == 'C' || student_exam[i] == 'c') == (answer_key[i] == 'C'))
   {
     count++;
   }
   else if ((student_exam[i] == 'D' || student_exam[i] == 'd') == (answer_key[i] == 'D'))
   {
     count++;
   }
  }
  return count;
}
