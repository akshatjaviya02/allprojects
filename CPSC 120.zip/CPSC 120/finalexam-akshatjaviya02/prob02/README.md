# Exam Grading
In this program, you will be using C++ programming constructs, such as functions, arrays, and file I/O. You will fill in the TODO code, and test that the code behaves as expected.

## main.cpp
This program checks an answer set against the answer key and outputs how many questions were right.

Skeleton code has been provided. Please fill in the remaining code according to the descriptions provided in the "TODO" comments.

## Input Validation
1. Make sure the input file exists and display an error message if not.
   - *note: there are multiple ways to do this, including checking the status of the file stream variable or calling the "fail" function*

# Hints
1. Be sure your program handles both upper and lowercase letter grades, and treats them the same (letter a == A, etc.)
   - *note: there are multiple ways to do this as well, but one way is you could use the toupper() function if you'd like*
1. Don't forget to close the file

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Enter file name: <b>exam1.txt</b>
You got 10 right out of 10
</pre>

## Sample Output #2
<pre>
Enter file name: <b>exam2.txt</b>
You got 6 right out of 10
</pre>

## Sample Output #3
<pre>
Enter file name: <b>exam3.txt</b>
Error opening file "exam3.txt"
</pre>

# Grading Checklist
1. **TODO**
   - Did you complete every TODO section of the code?
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used constants instead of a hardcoded literals in your expressions and calculations*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
1. **Error check**
   - Does your program print an error if the file does not exist?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
