// Locker Toggle
// This program toggles lockers (open lockers are closed and closed lockers
// are opened. With each round of toggling, the "skipped" lockers increase.

#include <iostream>
#include <fstream>

// constants
const int MIN_LOCKERS = 5;
const int MAX_LOCKERS = 50;

const std::string RESULTS_FILE = "lockers.txt";

// function prototypes
int getUserInput(int min, int max);
void toggleLockers(bool lockers[], int num_lockers);

// main function
int main()
{
  // get number of lockers from the user and create an array with
  // that many elements
  int num_lockers;
  num_lockers = getUserInput(MIN_LOCKERS, MAX_LOCKERS);

  // initialize all values to false
  // note that variable length arrays cannot be initialized using an
  // initialization list, therefore looping through all elements of the array
  bool lockers[num_lockers]; // user defined array length (note: this is ok)

  for (int i = 0; i < num_lockers; i++)
  {
    lockers[i] = false;
  }

  // call to toggle the lockers in multiple levels and output the results
  // to a file
  toggleLockers(lockers, num_lockers);

  return 0;
}

// get input from the user, and continue asking if the user enters an
// invalid value
int getUserInput(int min, int max)
{
  int num_lockers;

  // keep looping till the user enters a valid value
  do {
    std::cout << "How many lockers? ";
    std::cin >> num_lockers;

    // make sure user input is in range
    if (min > num_lockers || num_lockers > max)
    {
      std::cout << "** Invalid ** Value must be between " << min
        << " and " << max << ".\n";
    }
  } while (num_lockers > max || num_lockers < min);

  return num_lockers;
}

// This function loops through the lockers closing those that are open
// and opening those that are closed
// 1st time through the loop, hit every locker
// 2nd time through, start with the 2nd locker and hit every other locker
// 3rd time through, start with the 3rd locker and hit every third locker
// 4th time through, start with the 4th locker and hit every fourth locker
// and so on till the last element of the array is the starting locker
// This function also prints the array of lockers to a file each time the
// array is traversed
void toggleLockers(bool lockers[], int num_lockers)
{
  std::ofstream outfile;
  outfile.open(RESULTS_FILE);

  // loop through the lockers
  for (int i = 0; i <= num_lockers; i++)
  {
    // inner loop causes starting locker to increment by 1 each time the
    // lockers are traversed
    for (int j = i; j < num_lockers; j += (i + 1))
    {
      lockers[j] = !lockers[j]; // toggle
    }

    // print current setting for all lockers to a file
    for (int j = 0; j < num_lockers; j++)
    {
      outfile << lockers[j];
    }
    outfile << std::endl;
  }
  outfile.close();

  std::cout << "Lockers have been written to the file \""
    << RESULTS_FILE << "\"\n";
}
