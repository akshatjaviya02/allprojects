# Final Exam Part 2: Programming
## Timing and General Instructions
You have **1 hour** to complete the programming part of the midterm exam. This is a closed notes exam so you should not open any Website other than GitHub and the Titanium midterm exam page. Do not communicate with your classmates or look at their screens. Direct all your questions to the instructor only.

You are allowed to use scratch paper that will be provided for you during the exam. You must put your name and CWID on the scratch paper, even if you don't use the paper.

You must use a lab computer (not your own), but you are free to use any editor on the lab computer, as well as the command line on Tuffix to compile and test your program. The instructor will use g++/clang++ to check your programs so make sure they run using one of these compilers.

The instructor will not answer questions regarding interpretting syntax errors or debugging code, but will answer questions to clarify the problem instructions.

## Problems and Points
There are two programming problems that you need to complete.

1. Toggle Lockers (*8 points*)
1. Compare Grades (*17 points*)

# Submission
Your answers will be submitted through GitHub. You can push your code as many times as you want before the end of the midterm exam. The instructor will check only the last version that was pushed.

If you are running out of time, it is a good idea to push whatever work you have done. Even if it is not complete or not working, you will still get a good portion of the possible points.

# Instructions
Follow the README files for each problem assigned (e.g., prob01, prob02). If you have questions let your instructor know. You are also welcome to consult your classmates.

# Code Evaluation
*Note:* the explanations of all commands listed below are detailed in **labex00**. Refer to the README file in labex00, if needed.

1. Get a copy of the lab exercise from GitHub, and change directory into prob01, and open main.cpp for editing in atom.

   ```
   git clone URL

   cd labex01-USERNAME/prob01

   atom main.cpp
   ```

1. Compile and run your program.

   ```
   clang++ -std=c++17 main.cpp -o main
   ```
   ```
   ./main
   ```

1. When you want to move to another problem, you need to go back up to the parent folder and navigate into the next problem. For example:

   ```
   cd ../prob02
   ```

# Submission
1. To upload your code to GitHub you will run the following 3 commands. You will replace the text *"Description of your code changes"* with an actual description of what you are checking in.

    ```
    git add .
    git commit -m "Description of your code changes"
    git push
    ```

1. If it asks you to configure global variables for an email and name, just copy the commands it provides but replace the dummy text with your email and GitHub username. When you're done, make sure you `git commit` your repository again.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```

1. Once you have pushed your changes to GitHub, double check that your local repository is clean. The following should report: **Your branch is up to date with 'origin/master'**

    ```
    git status
    ```

1. Go back to the GitHub Website and refresh the page to see that your changes are there.

# Hints
1. If your program ever gets stuck in an infinite loop, you can stop the program by typing

  ```
  <Ctrl C>
  ```

1. If your input file is not being read correctly due to dos characters, update it in `vi` by typing

  ```
  vi your_file_name.txt
  ```

  Once you're in `vi` type the following sequence of commands

  ```
  :e ++ff=dos
  :set ff=unix
  ZZ
  ```
