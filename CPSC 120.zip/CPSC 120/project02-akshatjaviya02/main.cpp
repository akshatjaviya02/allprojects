// This program calculates and displays business trip expenses.
#include <iostream>
#include <string>
#include <iomanip>

int main()

{
  std::string location;
  double trip_days, hotel_cost, meal_cost, total_hotel, total_bill;
  const int SIZE = 18; // declearing an constant for set width for location to line up.
  const int COLUMN_WIDTH = 12; // declearing an constant for set width for everything else except location.

  //Welcoming to business trip calculator.
  std::cout << "Welcome to the Bussiness Trip Tracker!" << std::endl;

  // Bussiness place.
  std::cout << "what is the business trip location? ";
  getline(std::cin, location);
  location.substr(0, 18);

  //days of the Bussiness trip.
  std::cout << "How many days will the trip take? ";
  std::cin >> trip_days;

  //hotel's expenses.
  std::cout << "What is the hotel expense per day? $";
  std::cin >> hotel_cost;

  //total expenses for all meal.
  std::cout << "What is the total expense for all the meals? $";
  std::cin >> meal_cost;

  //calculate total expenses.
  total_hotel = trip_days * hotel_cost;
  total_bill = total_hotel + meal_cost;

  //displays the things that go along with calculations.
  std::cout << std::left << std::setw(SIZE) << "Location" << std::right << std::setw(COLUMN_WIDTH) << "Days"
    << std::setw(COLUMN_WIDTH) << "Hotel" << std::setw(COLUMN_WIDTH) << "Meal" << std::setw(COLUMN_WIDTH)
    << "Total" << std::endl;

  // seting the width of columns and setting the answer to be two decimal. Displays the calculations
  std::cout << std::left << std::setw(SIZE) << location.substr(0, SIZE) << std::right
    << std::setw(COLUMN_WIDTH) << trip_days << std::setprecision(2) << std::fixed << std::setw(COLUMN_WIDTH)
    << total_hotel << std::setw(COLUMN_WIDTH) << meal_cost << std::setw(COLUMN_WIDTH) << total_bill
    << std::setw(COLUMN_WIDTH) << std::endl;

return 0;
}
