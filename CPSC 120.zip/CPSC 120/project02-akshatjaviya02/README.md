#  Project Milestone 2 Objectives
1. Use C++ strings and stream manipulators
1. Output results in different forms
1. Compile and run program

# Business Trip Expenses
In this program, you will be learning to use C++ programming data manipulators.

# Prerequesites
`main.cpp` from Project Milestone 1

## main.cpp
Update Project Milestone 1 in the following ways:
1. Allow multiple words for the business trip location
1. Add range checking to the business trip location by allowing no more than 18 characters of the location to be output. Use `substr` from the `string` object, and use a constant (defined below) rather than a hardcoded value for 18
1. Replace tab characters in the Project Milestone 1 output with column widths using `setw`
1. Update the dollar amounts so that they always show 2 digits past the decimal

Define the following constants in your program:
1. The maximum width of the location column, set to 18
1. The width of all other columns, set to 12

# Hints
1. To format the output correctly, use stream manipulators from the **iomanip** library, such as: **setw, left, right, setprecision, and fixed**
1. Notice the column alignment is right-aligned for all columns other than the location

# Completion Checklist
1. Did you comment your code where appropriate?
1. Does your code follow the coding standards (especially spacing and indentation)?
1. Did you use the constants defined above (use for `setw` and `substr` rather than hardcoded integer literals)?
1. Are the columns right-aligned for all columns other than the location?
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Does your program produce the same results as both sample output below (including digits past the decimal)?
1. Does the GitHub Website show your latest code updates?

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Welcome to the Business Trip Tracker!

What is the business trip location? <b>New York City</b>
How many days will the trip take? <b>3</b>
What is the hotel expense per day? $<b>165.45</b>
What is the total expense for all meals? $<b>220.65</b>

Location                  Days       Hotel        Meal       Total
New York City                3      496.35      220.65      717.00
</pre>

## Sample Output #2

*Note: the string for location gets cut off at 18 characters in the output. Yours needs to as well.*

<pre>
Welcome to the Business Trip Tracker!

What is the business trip location? <b>Southampton, England</b>
How many days will the trip take? <b>12</b>
What is the hotel expense per day? $<b>209.19</b>
What is the total expense for all meals? $<b>773.11</b>

Location                  Days       Hotel        Meal       Total
Southampton, Engla          12     2510.28      773.11     3283.39
</pre>

# Code Evaluation
1. Get a copy of the lab exercise from GitHub, and change directory into prob01, and open main.cpp for editing in atom. See labex00 for details if needed.

   ```
   git clone URL

   cd labex01-USERNAME/prob01

   atom main.cpp
   ```

1. Compile and run your program.

   ```
   clang++ -std=c++17 main.cpp -o main

   ./main
   ```

1. When you want to move to another problem, you need to go back up to the parent folder and navigate into the next problem. For example:

   ```
   cd ../prob02
   ```

# Submission
1. To upload your code to GitHub you will run the following 3 commands.

    ```
    git add .
    git commit -m "Description of your code changes"
    git push
    ```

1. If it asks you to configure global variables for an email and name, just copy the commands it provides but replace the dummy text with your email and GitHub username. When you're done, make sure you `git commit` your repository again.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```

1. Once you have pushed your changes to GitHub, double check that your local repository is clean. The following should report: **Your branch is up to date with 'origin/master'**

    ```
    git status
    ```

1. Go back to the GitHub Website and refresh the page to see that your changes are there.
