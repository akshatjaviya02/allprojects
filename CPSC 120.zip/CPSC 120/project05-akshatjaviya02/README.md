#  Project Milestone 5 Objectives
1. Usage of files and the do-while loop
1. Compile, debug, and run the program

# Business Trip Expenses
This program displays a menu of options to the user, and responds to whichever option the user selects. The program will continue to display options until the user selects to exit the program.

# Prerequesites
`main.cpp` from Project Milestone 4

## main.cpp
Update Project Milestone 4 in the following ways:
1. Change the type of loop to a *do-while* loop
   - *This is generally the best choice for a menu-driven program*
   - Be sure the code that displays the menu of options to the user is included **only once** in your program *(this will be at the top of your do-while loop)*
1. Add two new options for the user to select from
   - `R` to allow the user to read trip expenses from a file
   - `W` to allow the user to write trip expenses to a file
1. Be sure your program handles both uppercase and lowercase for all options
   - If the user enters a lowercase letter for the option, your program should treat it the same as if the user enters an uppercase letter
1. If the user selects to write expenses to a file, your program should do the following *(see samples of these messages in Sample Output below)*
   - If no trips have been entered (either by the user or from the file), display a message indicating this
   - Otherwise, write the most recent trip expense to the file *(in table format, similar to the format used for option `T`)*
     - The file should be opened, written to, and closed, all under this option
   - Output a message indicating the trip expenses were written to the file
1. If the user selects to read expenses from a file, your program should do the following *(see samples of these messages in Sample Output below)*
   - If the file does not exist, display a message indicating this
   - If the file is empty, display a message indicating this
   - Otherwise, read all trip expenses from the file
     - The file should be opened, read from, and closed, all under this option
     - Use the following to read in the location
       - First make sure the location string is the right length: location.resize(18);
       - Read in the location from the file, treating the std::string location as though it were a c-string in order to use the *read* call that tells the compiler how many characters to read: infile.read(&location[0], 18)
       - ***For both of these calls, use the same constant that is used for the length of the location column rather than 18 (this is also the same constant that is used in the substr call for the location variable)***
   - Output a message indicating that trips from the file have been read in
   - For this milestone, you will read the data from the file into local variables, overwriting whatever values those variables previously contained

*Note: for this milestone, we can keep track of only one trip at a time. Therefore, if the user enters multiple trips, only the last one entered can be displayed or written to the file. A future milestone will allow us to keep track of all trips.*

## Constants
1. Add a constant for the name of the file, set to "trips.txt"

# Hints
1. The first line of the file *trips.txt* contains the column headers - your program can skip this line by using *getline* to read the line into a std::string variable that your program will never use
   - The *getline* call will move the file pointer to the next line of text in order to start reading information about the trips
1. If your program gets into an infinite loop, type `<Ctrl> c` to stop the program

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
*This sample loads a trip from a file and then displays it. Note that for this milestone, your program can handle only one trip at a time.*

For this sample, the contents of the file are as follows. You can view the file contents in Atom or by typing `cat trips.txt` at the command prompt in a Terminal window.
```
cat trips.txt
```
Observe that the following is displayed.
```
Location                  Days       Hotel        Meal       Total
Kalamazoo, Michiga           5      600.00      150.00      750.00
```

Now run the program, selecting the following menu options.

<pre>
Welcome to the Business Trip Tracker!

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>r</b>

Trips from file "trips.txt" have been loaded.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>p</b>

Location: Kalamazoo, Michiga
Days:     5
Hotel:    $600.00
Meal:     $150.00
Total:    $750.00

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>t</b>

Location                  Days       Hotel        Meal       Total
Kalamazoo, Michiga           5      600.00      150.00      750.00

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>x</b>

Thank you for using the Business Trip Tracker.
</pre>

## Sample Output #2
*This sample shows the error message when trying to read from a file that is empty. You will need to edit the trips.txt file to remove all of its contents.*

<pre>
Welcome to the Business Trip Tracker!

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>o</b>

'o' is an invalid option.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>r</b>

The file "trips.txt" is empty.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>p</b>

No trips have been entered.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>w</b>

No trips have been entered.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>x</b>

Thank you for using the Business Trip Tracker.
</pre>

## Sample Output #3
*This sample shows the error message when trying to read from a file that does not exist. You will need to delete the trips.txt file.*

You can delete the *trips.txt* file by typing `rm trips.txt` at the command prompt in a Terminal window.
```
rm trips.txt
```

Now run the program, selecting the following menu options.

<pre>
Welcome to the Business Trip Tracker!

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>r</b>

The file "trips.txt" does not exist.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>e</b>

What is the business trip location? <b>Los Angeles, California</b>
How many days will the trip take? <b>2</b>
What is the hotel expense per day? $<b>220.58</b>
What is the total expense for all meals? $<b>90.84</b>

Thank you. This trip has been added.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>p</b>

Location: Los Angeles, California
Days:     2
Hotel:    $441.16
Meal:     $90.84
Total:    $532.00

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>t</b>

Location                  Days       Hotel        Meal       Total
Los Angeles, Calif           2      441.16       90.84      532.00

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>w</b>

Trips have been written to file "trips.txt"

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>x</b>

Thank you for using the Business Trip Tracker.
</pre>

After you have run your program according to the sample above, the file *trips.txt* should now contain the new trip you entered. You can view the file contents in Atom or by typing `cat trips.txt` at the command prompt in a Terminal window.
```
cat trips.txt
```
Observe that the following is displayed.
```
Location                  Days       Hotel        Meal       Total
Los Angeles, Calif           2      441.16       90.84      532.00
```

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use a constant for the file name?
     - *Be sure you used all UPPERCASE for the name of your constant*
   - Did you use a constant in the calls to *read* and *resize*?
     - *Be sure you used the constant that was defined in an earlier milestone instead of hardcoded integer literals for the number 18*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Input**
   - Does your program produce the same results whether the user enters a lowercase or uppercase option?
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure the proper message is printed with each option*
     - *Be sure single quotation marks are included around the user input character in the "invalid option" output*
     - *Be sure the location name is cut off if it is greater than 18 characters for table output*
1. **Table alignment**
   - For table output, are the columns right-aligned for all columns other than the location?
1. **Error check**
   - Does your program output an error message when the file is empty or does not exist and the user selects to read from a file?
   - Does your program output an error message when there are no trips entered and the user selects to write to the file?
1. **Files**
   - Does your program open and close the file all within the option for 'R' and 'W'?
     - *Be sure to close the file before exiting the code block for reading from or writing to the file, depending on which option was selected by the user*
1. **GitHub**
   - Does the GitHub Website show your latest code updates?

# Code Evaluation
*Note:* the explanations of all commands listed below are detailed in **labex00**. Refer to the README file in labex00, if needed.

1. Get a copy of the project milestone from GitHub, change directory into your repo, and open main.cpp for editing in atom.

   ```
   git clone URL

   cd project01-USERNAME

   atom main.cpp
   ```

1. Compile and run your program.

   ```
   clang++ -std=c++17 main.cpp -o main
   ```
   ```
   ./main
   ```

# Submission
1. To upload your code to GitHub you will run the following 3 commands. You will replace the text *"Description of your code changes"* with an actual description of what you are checking in.

    ```
    git add .
    git commit -m "Description of your code changes"
    git push
    ```

1. If it asks you to configure global variables for an email and name, just copy the commands it provides but replace the dummy text with your email and GitHub username. When you're done, make sure you `git commit` your repository again.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```

1. Once you have pushed your changes to GitHub, double check that your local repository is clean. The following should report: **Your branch is up to date with 'origin/master'**

    ```
    git status
    ```

1. Go back to the GitHub Website and refresh the page to see that your changes are there.
