# Sales Prediction
In this program, you will be using C++ programming constructs, such as cin, cout, arithmetic and assignment operators.

## main.cpp
CompanyX produced total sales of $2,103,419,277 in 2018. Their sales so far for 2019 show sales have increased by 18%.

Write a program that prints out last year's sales as well as the prediction for this year's sales, assuming this year's sales continue to show the 18% increase.

*Please use whole numbers only (i.e., integer data types, rather than floating point for this exercise).*

Define the following 2 constants in your program:
1. The percent by which sales have increased
2. Last year's total sales

# Hints
1. The compiler outputs the line number and column of the error if a compile time error is encountered
   e.g., `main.cpp:27:37` indicates an error in your code on line 27, column 37
1. Make sure the data types you choose are large enough to hold the values that are assigned and calculated
   (check the maximum value allowed for each type of integer variable you choose)
1. Watch out for rounding errors. Make sure you get the same result as in the sample output

# Completion Checklist
1. Did you comment your code where appropriate?
1. Did you declare and use 2 constants (also did you name them with all capital letters)?
1. Did you store predicted sales in an integer data type (not a floating-point type)?
1. Does your code follow the coding standards (especially spacing and indentation)?
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Does your program produce the same results the sample output below?
1. Does the GitHub Website show your latest code updates?

# Sample Output
```
Last year's sales were $2103419277
This year's sales prediction: $2482034746
```
