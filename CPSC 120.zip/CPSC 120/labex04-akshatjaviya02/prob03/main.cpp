// Calculate and display the sales prediction for next year
#include <iostream>

int main ()

{
  // addition of 1 to 18% or 0.18
  const double INCREASE_IN_SALES = 1.18;
  const int SALES2019 = 2103419277;
  long estimatesales;

  //calculation
  estimatesales = INCREASE_IN_SALES * SALES2019;

  //display the calculation
  std::cout << "Last year's sales were $" << SALES2019 << std::endl;
  std::cout << "This year's sales prediction: $" << estimatesales << std::endl;

  return 0;
}
