#include <iomanip>
#include <iostream>

int main()
{
  // TODO#1: use the "static_cast" operator to cast the char variable to a short
  // and print both the char and the short
  // note: add a static_cast to cast the 2nd occurrence of the variable my_char1
  // to a short in the cout statement below
  char my_char1 = 'J';
  std::cout << "The ASCII value for " << my_char1 << " is stored as" << static_cast<short>(my_char1) << std::endl;

  std::cout << std::endl; // blank line to separate output from the different exercises

  // TODO#2: for my_char2b, add one to the char variable my_char2a to see what
  // gets printed out
  char my_char2a = 'C';
  char my_char2b = my_char2a + 1; // TODO: set this equal to my_char2a plus 1
  std::cout << "Char " << my_char2a << " becomes " << my_char2b
    << " after adding 1." << std::endl;

  std::cout << std::endl; // blank line to separate output from the different exercises

  // TODO#3: for my_char3b, add one to the char variable my_char3a to see what
  // gets printed out
  // Also add a comment explaining why the value of the character is no
  // longer alphabetic. Hint: look in the ASCII character chart

  char my_char3a = 'z';
  char my_char3b = my_char3a + 1; // TODO: set this equal to my_char3a plus 1
  std::cout << "Char " << my_char3a << " becomes " << my_char3b
    << " after adding 1." << std::endl; // after adding the 1 to z which would make the as to a parenthsis because z is cosidered to be a last letter

  std::cout << std::endl; // blank line to separate output from the different exercises

  // TODO#4: print each number, then subtract one from each number and print it
  // again (note that these print statements have been provided for you)
  // also update the explanation with why my_short2 value became positive after
  // subtracting one, but my_int2 did not
  // note that std::hex causes the output to be formatted as hexadecimal and
  // std::dec changes it back to the default of decimal

  short my_short2 = -32768; // minimum value for a short
  int my_int2 = my_short2;

  std::cout << "Short (" << sizeof(my_short2) << " bytes): "
    << std::dec << my_short2 << std::hex << " (0x" << my_short2 << ')';

  my_short2 = my_short2 - 1; // TODO: decrement my_short2 by one
  std::cout << ", after subtracting 1: " << std::dec << my_short2
    << std::hex << " (0x" << my_short2 << ")\n";

  std::cout << "Int (" << sizeof(my_short2) << " bytes): "
    << std::dec << my_short2 << std::hex << " (0x" << my_short2 << ')';

  my_int2 = my_int2 - 1; // TODO: decrement my_int2 by one
  std::cout << ", after subtracting 1: " << std::dec << my_int2
    << std::hex << " (0x" << my_int2 << ")\n";

  // TODO: replace ... with the reason why the values differ
  std::cout << "The reason subtracting 1 from each of the numbers caused a"
    << " different result is because the answer overflow\n";

  std::cout << std::endl; // blank line to separate output from the different xercises

  // TODO#5: print each number, then add one to each number and print it again
  // (note that these print statements have been provided for you)
  // also update the explanation with why my_short3 value became zero after
  // adding one, but my_int3 did not

  unsigned short my_short3 = 65535; // maximum value for an unsigned short
  unsigned int my_int3 = my_short3;

  std::cout << "Unsigned short (" << sizeof(my_short3) << " bytes): "
    << std::dec << my_short3 << std::hex << " (0x" << my_short3 << ')';

  my_short3 = my_short3 + 1; // TODO: increment my_short3 by one
  std::cout << ", after adding 1: " << std::dec << my_short3
    << std::hex << " (0x" << my_short3 << ")\n";

  std::cout << "Same value as unsigned int (" << sizeof(my_int3) << " bytes): "
    << std::dec << my_short3 << std::hex << " (0x" << my_short3 << ')';

  my_int3 = my_int3 + 1; // TODO: increment my_int3 by one
  std::cout << ", after adding 1: " << std::dec << my_int3
    << std::hex << " (0x" << my_int3 << ")\n";

  // TODO: replace ... with the reason why the values differ
  std::cout << "The reason adding 1 to each of the numbers caused a" << my_int3
   << " different result is because the answer is overflow\n";

  std::cout << std::endl; // blank line to separate output from the different exercises

  // TODO#6: no code to change, just notice how the actual values of the variables
  // are not exactly 7.41 (the value they were set to) if you print out enough places
  // past the decimal
  std::cout << std::fixed << std::setprecision(80);

  float f2 = 7.41;
  double d2 = 7.41;

  std::cout << "float value: " << f2 << std::endl;
  std::cout << "double value: " << d2 << std::endl;
  std::cout << "The reason these values are not exactly 7.41 (the value they were"
    << " both set to) is because floating-point numbers are generally not exact\n";
  std::cout << "However, the double is closer to the actual value since it is"
    << " larger and has more precision than a float\n";

  // TODO#7: notice how the values of f2 and d2 start to diverge from each other
  // as they become smaller and smaller (i.e., as they become closer to zero)
  // replace the ellipsis (...) below with the reason the two values differ even
  // though the same operations are being performed on them
  // (i.e., both are being multiplied by the same numbers)
  // hint: keep in mind the size of each variable's data type
  f2 = 3.1111111E-38;
  d2 = f2;

  std::cout << "\nInitially the double and the float are the same value.\n";
  std::cout << sizeof(f2) << " bytes, value: " << f2 << std::endl;
  std::cout << sizeof(d2) << " bytes, value: " << d2 << std::endl;

  f2 *= 0.00001;
  d2 *= 0.00001;

  std::cout << "\nThey start to drift apart the closer they get to 0.\n";
  std::cout << sizeof(f2) << " bytes, value: " << f2 << std::endl;
  std::cout << sizeof(d2) << " bytes, value: " << d2 << std::endl;

  f2 *= 0.01;
  d2 *= 0.01;

  std::cout << "\nThe reason the float is losing precision faster than the"
    << "double is because double is considered to be higher than float in data type.\n";
  std::cout << sizeof(f2) << " bytes, value: " << f2 << std::endl;
  std::cout << sizeof(d2) << " bytes, value: " << d2 << std::endl;

  f2 *= 0.1;
  d2 *= 0.1;

  // TODO#8: replace the ellipsis (...) a description of why f2 is now zero
  std::cout << "\nThe reason the variable f2 is now 0 is because it have become close to zero which made it to show zero or in other words it is underflow.\n";
  std::cout << sizeof(f2) << " bytes, value: " << f2 << std::endl;
  std::cout << sizeof(d2) << " bytes, value: " << d2 << std::endl;

  return 0;
}
