# Manipulating char, data overflow/underflow
In this program, you will be learning to use the basic C++ programming constructs, such as cout, sizeof, dec, hex, and the ASCII character set, as well as viewing what happens with variable overflow and underflow.

## main.cpp
Find the statements marked "TODO" in the program, and follow the instructions found there.

# Completion Checklist
1. Make sure you have checked in your updates for all "TODO" statements
1. Does your program compile? (i.e. no errors when you run clang++)
1. Does the GitHub Website show your latest code updates?
