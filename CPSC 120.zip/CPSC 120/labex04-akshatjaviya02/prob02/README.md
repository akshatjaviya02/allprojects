# Find the Errors
In this program, you will debug a program that contains the following:
1. Compile time bugs
1. Run time bugs (these compile but produce error output values)
1. Style guide violations

## main.cpp
1. Visually inspect the code and fix any code statements that do not follow the style guide (e.g., spacing and indentation). If needed, refer to the "CPSC 120 C++ Style Guide" on Titanium class page.
1. Try compiling the program to find out what errors the compiler finds.
1. Find and fix the compile time bug(s).
1. Once the program compiles, try running it to see whether it outputs the expected results.
1. Find and fix any bug(s) in the program that are causing incorrect results to be output.

# Hints
1. The compiler outputs the line number and column of the error if a compile time error is encountered
   e.g., `main.cpp:27:37` indicates an error in your code on line 27, column 37
1. Make sure the result for average **includes the decimal digits**
   (use a static_cast to force floating point division)

# Completion Checklist
1. Does your code follow the coding standards (especially spacing and indentation)?
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Does your program produce the same results as both of the sample output below?
1. Does the GitHub Website show your latest code updates?

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Enter three integers, each separated by one or more spaces: <b>33 36 37</b>
The average of 33, 36, and 37 is: 35.3333
</pre>

## Sample Output #2
<pre>
Enter three integers, each separated by one or more spaces: <b>155 28 74</b>
The average of 155, 28, and 74 is: 85.6667
</pre>
