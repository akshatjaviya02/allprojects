// Discount Applied
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>

int main()
{
  double total, discount, total_bill;
  const int MAX = 500;
  const int LOW = 200;
  const double MAX_DISCOUNT = 15;
  const double LOW_DISCOUNT = 10;

  std::cout << "Please enter the total amount: $";
  std::cin >> total;

  if (total <= 0)
  {
    std::cout << "The total amount must be greater than zero" << std::endl;
  }
  // User would not get discount lower than 200
  else if (total < LOW)
  {
    std::cout << "You did not earn a discount\n";
    std::cout << "Your bill is $" << total << "." <<std::endl;
  }
  // User would get discount if the bill is over 200 dollars
  else if (total < MAX)
  {
    //calculate
    discount = total * LOW_DISCOUNT / 100;
    total_bill = total - discount;

    std::cout << "You earned a " << LOW_DISCOUNT << "% discount\n";
    std::cout << "Your discount is $" << std::setprecision(2) << std::fixed << discount << '\n';
    std::cout << "Your bill is $" << total_bill << std::endl;
  }
  // if the bill is greater than 500 then the user would get 15% off
  else
  {
    //calculate
    discount = total * MAX_DISCOUNT / 100;
    total_bill = total - discount;

    std::cout << "You earned a " << MAX_DISCOUNT << "% discount\n";
    std::cout << "Your discount is $" << std::setprecision(2) << std::fixed << discount << '\n';
    std::cout << "Your bill is $" << total_bill << std::endl;
  }

  return 0;
}
