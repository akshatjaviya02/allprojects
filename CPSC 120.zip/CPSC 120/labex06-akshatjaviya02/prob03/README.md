# Discount Applied
In this program, you will be using C++ programming constructs, such as relational and arithmetic operators.

## main.cpp
Write a program that calculates the discount applied to an order, based on the total amount of the order.

Your program will ask the user to input the total amount, and will then output the discount in terms of percentage as well as amount, along with the total bill after applying the discount. Your program should always print 2 digits past the decimal point. See Sample Output below.

If the user enters an amount of 0 or a negative value then your program will output an error message, as shown in the Sample Output below.

If the user enters an amount less than 200, then no discount is applied and a message indicating such is displayed to the user, as shown in the Sample Output below.

## Constants
Define the following constants in your program:
1. The discount applied on orders of $500 or more, set to 15
1. The discount applied on orders of $200 to $499.99, set to 10
1. The value of the upper boundary for discounts, set to 500
1. The value of the lower boundary for discounts, set to 200

# Hints
1. Try different values, especially values at and near the boundaries 200 and 500, to see if the proper discount is always applied

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Please enter the total amount: $<b>371.98</b>
You earned a 10% discount
Your discount is $37.20
Your total bill is $334.78
</pre>

## Sample Output #2
<pre>
Please enter the total amount: $<b>88.72</b>
You did not earn a discount
Your total bill is $88.72
</pre>

## Sample Output #3
<pre>
Please enter the total amount: $<b>0</b>
The total amount must be greater than zero
</pre>

## Sample Output #4
<pre>
Please enter the total amount: $<b>500</b>
You earned a 15% discount
Your discount is $75.00
Your total bill is $425.00
</pre>

# Grading Checklist
1. Did you comment your code where appropriate?
1. Does your code follow the coding standards (especially spacing and indentation)?
1. Did you define and use the constants described above (also did you name them with all uppercase)?
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Does your program produce the same results as the Sample Output (including digits past the decimal)?
1. Did you test the boundary conditions (amounts on the boundary of a discount, such as 199, 200, 201, 499, 500, 501)?
1. Does your program output an error message when the user enters 0 or a negative value?
1. Does the GitHub Website show your latest code updates?
