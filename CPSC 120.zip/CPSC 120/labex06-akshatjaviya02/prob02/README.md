# Find the Errors
In this program, you will debug a program that contains the following errors:
1. Compile time bugs
1. Run time bugs (these compile but produce error output values)
1. Style guide violations

## main.cpp
1. Visually inspect the code and fix any code statements that do not follow the style guide (e.g., spacing and indentation). If needed, refer to the "CPSC 120 C++ Style Guide" on Titanium class page
1. Try compiling the program to find out what errors the compiler finds
1. Find and fix the compile time bug(s)
1. Once the program compiles, try running it to see whether it outputs the expected results
1. Find and fix any bug(s) in the program that are causing incorrect results to be output

# Hints
1. Purposefully enter an incorrect answer to see how your program handles it
1. Make sure the level is always printed to indicate either beginning, intermediate, or advanced addition
   (beginning when both addends are 1 digit long, intermediate when only of the 1 addends is 1 digit long, and advanced when both addends are 2 digits long)
1. The compiler outputs the line number and column of the error if a compile time error is encountered
   e.g., `main.cpp:27:37` indicates an error in your code on line 27, column 37
1. Make sure you have included all of the necessary libraries
   e.g., `main.cpp:54:8: error: no member named 'cout' in namespace 'std'` indicates the library for 'cout' is missing from the list of include files

# Sample Output
Please run your program multiple times to see that the addition equation changes each time you run the program. You do not need to recompile between runs.

*Note: your addition problems will not necessarily match the ones shown in the samples below due to the randomness of the problems.*

Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Beginning Addition
    5
  + 2
   --
    <b>7</b>

Congratulations! 7 is correct. You are good at level: Beginning.
</pre>

## Sample Output #2
<pre>
Intermediate Addition
   15
  + 3
   --
   <b>18</b>

Congratulations! 18 is correct. You are good at level: Intermediate.
</pre>

## Sample Output #3
<pre>
Advanced Addition
   15
 + 20
   --
   <b>30</b>

30 is not correct. Try reviewing level: Advanced.
</pre>

# Grading Checklist
1. Does your code follow the coding standards (especially spacing and indentation)?
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Does your program produce a different addition problem every time you run it?
1. Does the addition problem always print the level/difficulty of the problem? (run the program several times to see if it always prints either beginning, intermediate, or advanced)
1. Does your program print the proper error message when you enter an incorrect answer to the addition problem?
1. Does the GitHub Website show your latest code updates?
