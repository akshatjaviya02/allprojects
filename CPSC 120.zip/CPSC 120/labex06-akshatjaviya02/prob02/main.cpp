// This program generates a math addition problem containing random numbers
// from 0 to 20 and asks the user to enter the answer.

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <iomanip>

int main()
{
  // the maximum value allowed for either of the addends
  const int MAX_ADDEND = 20;

  // set the random number generator seed
  unsigned seed = time(0);
  srand(seed);

  // randomly generate 2 addends
  int addend1 = rand() % (MAX_ADDEND + 1);
  int addend2 = rand() % (MAX_ADDEND + 1);
  int answer, sum = addend1 + addend2;

  // determine whether the addition problem is beginning, intermediate,
  // or advanced
  // "Beginning" if both addends are 1 digit long
  // "Intermediate" if only one of the addends is 1 digit long
  // "Advanced" if both addends are 2 digits long
  std::string level;

  if (addend1 < 10)
  {
    if (addend2 < 10)
    {
      level = "Beginning";
    }
    else
    {
      level = "Intermediate";
    }
  }
  else //addend2 >= 10 and addend2;
  {
    if (addend2 < 10)
    {
      level = "Intermediate";
    }
    else
    {
      level = "Advance";
    }

  }

  // output the header
  std::cout << level << " Addition\n";

  // output the math problem to the user
  std::cout << std::setw(5) << addend1 << std::endl;
  std::cout << std::setw(5) << "+ " + std::to_string(addend2) << std::endl;
  std::cout << std::setw(5) << "--" << std::endl;

  std::cout << "   "; // indent to the same level as the addends
  if (sum < 10)
  {
    std::cout << ' '; // add another space to line up if answer is only 1 digit
  }
  std::cin >> answer;

  if (answer == sum)
  {
    std::cout << "Congratulations! " << answer
      << " is correct. You are good at level: " << level << ".\n";
  }
  else
  {
    std::cout << answer << " is not correct. Try reviewing level: "
      << level << ".\n";
  }

  return 0;
}
