# Relational Expressions
In this program, you will describe what happens with floating-point relational expressions.

## main.cpp
Find the statements marked "TODO" in the program, and follow the instructions found there.

# Hints
1. You are welcome to check through the lecture slides to help you answer the TODO statements

# Grading Checklist
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Did you complete the code instructed for all of the "TODO" statements?
1. Does the GitHub Website show your latest code updates?
