// examples of overflow/underflow

#include <iostream>
#include <iomanip>

int main()
{
  // TODO#1 update the cout **comment** below explaining why the equality
  // operator says that 1.11 is not equal to 1.11

  float amount = 1.11;

  std::cout << "TODO#1: \"amount\" is " << amount << std::endl;

  if (1.11 == amount) {
    std::cout << "This is equal to 1.11\n";
  }
  else {
    std::cout << "This is NOT equal to 1.11\n";
  }

  std::cout << "**The 1.11 is not equal to 1.11 because 1.11 is floating which would excluded decimal points.**\n"; // TODO: update comment


  // TODO#2 use the same code as above, and this time add more precision to
  // the output until it shows how the 2 values differ from each other
  // hint: try setting a precision of 20 or more
  // also update the cout **comment** below explaining what you see

  std::cout << "\nTODO#2: \"amount\" is " << std::setprecision(20) << std::fixed << amount << std::endl;

  if (1.11 == amount) {
    std::cout << "This is equal to " << 1.11 << std::endl;
  }
  else {
    std::cout << "This is NOT equal to " << 1.11 << std::endl;
  }

  std::cout << "**By using percsion still the number not match because the decimal of the number doesn't match.**\n"; // TODO: update comment


  // TODO#3 update the relational expression in the if statement so that it
  // properly evaluates to true when comparing 1.11 and the variable "amount"
  // also update the cout **comment** explaining why this type of check is
  // necessary
  // hint: the lecture slides from this week have an example showing how to
  // compare two floating-point numbers to check for equality

  std::cout << "\nTODO#3: \"amount\" is " << std::fixed
    << std::setprecision(2) << amount << std::endl;

  if (std::abs(amount - 1.11) < 0.01) { // TODO: update relational expression
    std::cout << "This is equal to " << 1.11 << std::endl;
  }
  else {
    std::cout << "This is NOT equal to " << 1.11 << std::endl;
  }

  std::cout << "**The number is eqaul becasuse of absolute value whereas the double equal was mean that the number has to be exactly the same.**\n"; // TODO: update comment

  return 0;
}
