#  Project Milestone 4 Objectives
1. Usage of C++ loops
1. Output results in different forms
1. Compile and run program

# Business Trip Expenses
In this program, you will be learning to use C++ programming loops.

# Prerequesites
`main.cpp` from Project Milestone 3

## main.cpp
Update Project Milestone 3 in the following ways:
1. Add a *while* loop to continue asking the user for an option until the user selects to exit
1. Add two new options for the user to select from
   - `T` to allow user to print the business expense in table format
   - `P` to allow the user to print the business expense in single format *(see Sample Output below for an example of this)*. Note that this option prints the full location name.
1. Be sure your program handles both uppercase and lowercase for all options
   - If the user enters a lowercase letter for the option, your program should treat it the same as if the user enters an uppercase letter
1. If the user selects to print expenses before entering an expense, display a message indicating no expenses have been entered *(see message in Sample Output below)*
1. Move the display of expenses from the option to enter an expense `E` into the option to print expenses in table format `T`
1. Update the option to enter an expense to display a message after reading all values for the expense *(see message in Sample Output below)*

*Note: for this milestone, we can keep track of only one expense at a time. Therefore, if the user enters multiple expenses, only the last one entered can be displayed. A future milestone will allow printing of all expenses.*

# Hints
1. If your program gets into an infinite loop, type `<Ctrl> C` to stop the program
1. For the single expense output, since you know exactly how many spaces it takes to cause the columns to line up with each other, it is fine to use actual spaces instead of *setw*

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
*Note: the string for location gets cut off at 18 characters in the table format output, but not in the single expense output.*

<pre>
Welcome to the Business Trip Tracker!

What would you like to do?
  E: enter a new expense
  P: print a single expense
  T: print table of all expenses
  X: exit the program
Option: <b>t</b>

No trips have been entered.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  T: print table of all expenses
  X: exit the program
Option: <b>p</b>

No trips have been entered.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  T: print table of all expenses
  X: exit the program
Option: <b>e</b>

What is the business trip location? <b>Albuquerque, New Mexico</b>
How many days will the trip take? <b>5</b>
What is the hotel expense per day? <b>$149.22</b>
What is the total expense for all meals? <b>$222.20</b>

Thank you. This trip has been added.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  T: print table of all expenses
  X: exit the program
Option: <b>P</b>

Location: Albuquerque, New Mexico
Days:     5
Hotel:    $746.10
Meal:     $222.20
Total:    $968.30

What would you like to do?
  E: enter a new expense
  P: print a single expense
  T: print table of all expenses
  X: exit the program
Option: <b>T</b>

Location                  Days       Hotel        Meal       Total
Albuquerque, New M           5      746.10      222.20      968.30

What would you like to do?
  E: enter a new expense
  P: print a single expense
  T: print table of all expenses
  X: exit the program
Option: <b>J</b>

'J' is an invalid option.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  T: print table of all expenses
  X: exit the program
Option: <b>x</b>

Thank you for using the Business Trip Tracker.
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Input**
   - Does your program produce the same results whether the user enters a lowercase or uppercase option?
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure single quotation marks are included around the user input character in the "invalid option" output*
     - *Be sure the location name is cut off if it is greater than 18 characters for table output, but not for single expense output*
1. **Table alignment**
   - For table output, are the columns right-aligned for all columns other than the location?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?

# Code Evaluation
*Note:* the explanations of all commands listed below are detailed in **labex00**. Refer to the README file in labex00, if needed.

1. Get a copy of the project milestone from GitHub, change directory into your repo, and open main.cpp for editing in atom.

   ```
   git clone URL

   cd project01-USERNAME

   atom main.cpp
   ```

1. Compile and run your program.

   ```
   clang++ -std=c++17 main.cpp -o main
   ```
   ```
   ./main
   ```

# Submission
1. To upload your code to GitHub you will run the following 3 commands. You will replace the text *"Description of your code changes"* with an actual description of what you are checking in.

    ```
    git add .
    git commit -m "Description of your code changes"
    git push
    ```

1. If it asks you to configure global variables for an email and name, just copy the commands it provides but replace the dummy text with your email and GitHub username. When you're done, make sure you `git commit` your repository again.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```

1. Once you have pushed your changes to GitHub, double check that your local repository is clean. The following should report: **Your branch is up to date with 'origin/master'**

    ```
    git status
    ```

1. Go back to the GitHub Website and refresh the page to see that your changes are there.
