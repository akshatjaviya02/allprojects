// This program calculates and displays business trip expenses.
#include <iostream>
#include <string>
#include <iomanip>

int main()

{
  std::string location;
  double hotel_cost, meal_cost, total_hotel, total_bill;
  int trip_days = 0;
  const int SIZE = 18; // declearing an constant for set width for location to line up.
  const int COLUMN_WIDTH = 12; // declearing an constant for set width for everything else except location.
  char letter = 'Z';


  //Welcoming to business trip calculator.
  std::cout << "Welcome to the Bussiness Trip Tracker!\n";

  // loop will go on until user inputs small 'x' or captial 'X'.
  while (letter != 'x' && letter != 'X')
  {
    std::cout << "\nWhat would you like to do?\n";
    std::cout << "E: enter a new expense\n";
    std::cout << "P: print a single expense\n";
    std::cout << "T: print table of all expenses\n";
    std::cout << "X: exit the program\n";
    std::cout << "Opition: ";
    std::cin >> letter;
    std::cin.ignore();

    // t or T would print an horizontal table.
    if (letter == 't' || letter == 'T')
    {
      if (trip_days == 0)
      {
        std::cout << "\nNo trips have been entered.\n";
      }
      else
      {
        //calculate total expenses.
        total_hotel = trip_days * hotel_cost;
        total_bill = total_hotel + meal_cost;

        std::cout << std::left << std::setw(SIZE) << "\nLocation" << std::right << std::setw(COLUMN_WIDTH) << "Days"
          << std::setw(COLUMN_WIDTH) << "Hotel" << std::setw(COLUMN_WIDTH) << "Meal" << std::setw(COLUMN_WIDTH)
          << "Total\n";

        // seting the width of columns and setting the answer to be two decimal. Displays the calculations
        std::cout << std::left << std::setw(SIZE) << location.substr(0, SIZE) << std::right
          << std::setw(COLUMN_WIDTH) << trip_days << std::setprecision(2) << std::fixed << std::setw(COLUMN_WIDTH)
          << total_hotel << std::setw(COLUMN_WIDTH) << meal_cost << std::setw(COLUMN_WIDTH) << total_bill
          << std::setw(COLUMN_WIDTH) << '\n';
      }
    }
    // p or P would print veritcal table.
    else if (letter == 'p' || letter == 'P')
    {
      if (trip_days == 0)
      {
        std::cout << "\nNo trips have been entered.\n";
      }
      else
      {
        //calculate total expenses.
        total_hotel = trip_days * hotel_cost;
        total_bill = total_hotel + meal_cost;

        location.substr(0);
        std::cout << std::setprecision(2) << std::fixed;
        std::cout << "\nLocation: " << location << '\n';
        std::cout << "Days:     " << trip_days << '\n';
        std::cout << "Hotel:    $" << total_hotel << '\n';
        std::cout << "Meal:     $" << meal_cost << '\n';
        std::cout << "Total:    $" << total_bill << '\n';
      }
    }
    // e or E would let user input the about trip.
    else if (letter == 'e' || letter == 'E')
    {
      // Bussiness place.
      std::cout << "What is the business trip location? ";
      getline(std::cin, location);
      location.substr(0, 18);

      //days of the Bussiness trip.
      std::cout << "How many days will the trip take? ";
      std::cin >> trip_days;

      //hotel's expenses.
      std::cout << "What is the hotel expense per day? $";
      std::cin >> hotel_cost;

      //total expenses for all meal.
      std::cout << "What is the total expense for all the meals? $";
      std::cin >> meal_cost;

      std::cout << "\nThank you. This trip has been added.\n";
    }
    // if user input other than T,P,X,E,e,p,t,x the program would ask user to input a valid option.
    else if (letter != 'x' && letter != 'X')
    {
      std::cout << '\n' << "\'" << letter << "\'" << "that is an invalid option\n";
    }
  }
  std::cout << "\nThank you for using the Business Trip Tracker.\n";
  return 0;
}
