#ifndef __TYPES_H__
#define __TYPES_H__

#include <string>

//-----------
// Constants
//-----------

const int ARRAY1_SIZE = 5;
const int ARRAY2_SIZE = 8;

const std::string ARRAY1_FILE_NAME = "Array1.txt";
const std::string ARRAY2_FILE_NAME = "Array2.txt";

const std::string COMB_ARRAY_FILE_NAME = "CombinedArray.txt";


//---------------------
// Function prototypes
//---------------------

// This function combines the contents of the 2 input arrays into a single
// final array. Both input arrays must already be sorted. The function then
// writes the final array to a file, and returns to the caller the element
// of the final (combined) array that is the kth smallest.
// Parameters:
//  1. a sorted array of integers
//  2. another sorted array of integers
//  3. the size of array#1
//  4. the size of array#2
//  5. k is the number that represents the kth smallest item to return to
//     the caller
// Return value:
//  1. kth smallest item from the combined array
int getKthSmallest(int arr1[], int arr2[], int size1, int size2, int kth);


#endif
