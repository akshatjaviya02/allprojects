// Combining arrays
// This program combines two sorted arrays into one sorted array, and prints
// that final array to a file. It also gets from the user an item (item k) to
// print to the console, and displays the kth smallest item from the final
// combined array.

#include <fstream>
#include <iostream>
#include <string>
#include "types.hpp"

int main()
{
  int arr1[ARRAY1_SIZE] = {0};
  int arr2[ARRAY2_SIZE] = {0};

  int array1_num_items = 0;
  int array2_num_items = 0;


  // TODO:
  // read in both arrays from their respective files, and set the number of
  // items for each array in variables array1_num_items and array2_num_items
  std::ifstream in_file;
  in_file.open(ARRAY1_FILE_NAME);
  if (in_file)
  {
    while (array1_num_items < ARRAY1_SIZE && in_file >> arr1[array1_num_items])
    {
      array1_num_items++;
    }
  }
  std::ifstream in_file2;
  in_file2.open(ARRAY2_FILE_NAME);
  if (in_file2)
  {
    while (array2_num_items < ARRAY1_SIZE && in_file2 >> arr2[array2_num_items])
    {
      array2_num_items++;
    }
  }
  in_file.close();
  in_file2.close();
  // get user input
  int kth_item, kth_smallest;
  std::cout << "\nWhat \"Kth\" smallest numbered value would you like to return?\n";

  // keep looping till user enters a valid value
  do {
    std::cout << "Enter a number between 1 and "
      << array1_num_items + array2_num_items << ": ";
    std::cin >> kth_item;

  } while (kth_item <= 0 || kth_item > array1_num_items + array2_num_items);

  // TODO:
  // call the function to get the kth smallest item from the 2 arrays
  kth_smallest = getKthSmallest( arr1, arr2, array1_num_items, array2_num_items, kth_item);

  std::cout << "The value of the kth (k = " << kth_item
    << ") smallest item in the array is " << kth_smallest << "\n\n";

  return 0;
}

int getKthSmallest(int arr1[], int arr2[], int size1, int size2, int kth)
{
  int i = 0, j = 0, combined = 0;
  int sorted[size1 + size2];

  // keep looping while there are still elements remaining to be checked
  // in each of the arrays

  while (i < size1 && j < size2)
  {
    if (arr1[i] < arr2[j])
    {
      sorted[combined++] = arr1[i++];
    }
    else
    {
      sorted[combined++] = arr2[j++];
    }
  }

  // TODO:
  // load the remaining elements from whichever array still has any that
  // are remaining to be checked (i.e., if i or j is not at the size)
  for (int x = i; x < size1; x++)
  {
    sorted[combined++] = arr1[x];
  }
  for (int y = j; y < size2; y++)
  {
    sorted[combined++] = arr2[y];
  }

  // TODO:
  // print final array to a file (file name defined in types.hpp)
  std::ofstream out_file;
  out_file.open(COMB_ARRAY_FILE_NAME);
  for (int i = 0; i < combined; i++)
  {
    out_file << sorted[i]  << '\n';
  }
  out_file.close();

  return sorted[kth - 1]; // return the kth element
}
