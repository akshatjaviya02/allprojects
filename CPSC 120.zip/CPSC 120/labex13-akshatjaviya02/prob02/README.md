# Combining Arrays
In this program, you will be using C++ programming constructs, such as functions and arrays.

## main.cpp
Write a program that combines two sorted arrays into one. Both arrays are read from different files, and the final array is written to a third file. The program also prompts the user for an item to display (the kth smallest item), and displays that to the console.

Skeleton code has been provided. Please check for and fix any compiler and runtime errors, and also find all TODO comments and fill in the missing code for each according to the descriptions.

## Input Validation
1. You can assume the user will always input an integer value
1. The program checks to be sure the user input is not greater than the array size declarator *(already provided for you)*
1. Be sure your program checks to be sure it is not writing past the end of the array(s)
   - Use the constants defined in `types.hpp` for the maximum number of elements in the arrays

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
What "Kth" smallest numbered value would you like to return?
Enter a number between 1 and 13: <b>10</b>
The value of the kth (k = 10) smallest item in the array is 14
</pre>

## Sample Output #2
For this sample, first change the contents of Array2 by typing the following:
```
mv Array2.txt temp.txt
cp Array3.txt Array2.txt
```

Now run the program.
<pre>
What "Kth" smallest numbered value would you like to return?
Enter a number between 1 and 8: <b>9</b>
Enter a number between 1 and 8: <b>-1</b>
Enter a number between 1 and 8: <b>0</b>
Enter a number between 1 and 8: <b>8</b>
The value of the kth (k = 8) smallest item in the array is 9
</pre>

After you have run the program, you can move the file back to its original name.
```
mv temp.txt Array2.txt
```

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used a constant instead of a hardcoded literals*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce similar results as the Sample Output?
1. **Error check**
   - Does your program print an error and ask again if the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
