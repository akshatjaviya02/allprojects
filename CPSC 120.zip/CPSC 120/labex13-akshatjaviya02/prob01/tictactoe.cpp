// Tic-Tac-Toe
// This file contains the helper functions for the tic-tac-toe program.

#include <iostream>
#include <ctime>
#include <cstdlib>
#include "tictactoe.hpp"

void displayBoard(TicTacToeBoard tictactoe)
{
  std::cout << std::endl;
  for (int r = 0; r < BOARD_SIZE; r++)
  {
    for (int c = 0; c < BOARD_SIZE; c++)
    {
      // if the cell is unoccupied, display the row/column for the
      // user to potentially select the cell, otherwise, display
      // the contents of the cell (the player who occupies the cell)

      std::cout << ' ';
      if (tictactoe[r][c] == UNOCCUPIED)
      {
        std::cout << (r + 1) * 10 + (c + 1);
      }
      else
      {
        std::cout << ' ' << tictactoe[r][c];
      }
    }
    std::cout << std::endl;
  }
}

bool isValidMove(TicTacToeBoard tictactoe, int move)
{

  // turn row/col from 1-3 that is displayed into 0-2 for the index
  int row_index = (move / 10) - 1;
  int col_index = (move % 10) - 1;

  // TODO:
  // if row/col indices are in range, and if the cell at this row/col is
  // // unoccupied, then set the square to the player (PLAYER_X) and set the
  // return value to true
  bool valid = true;
  if (row_index < 0 || row_index >= BOARD_SIZE)
  {
    valid = false;
  }
  else if (col_index < 0 || col_index >= BOARD_SIZE)
  {
    valid = false;
  }
  else if (tictactoe [row_index][col_index] != UNOCCUPIED)
  {
    valid = false;
  }
  if (valid)
  {
    tictactoe [row_index][col_index] = PLAYER_X;
  }
  return valid;
}

void computerMove(TicTacToeBoard tictactoe)
{
  // static to ensure the seed is set only once
  static bool first_time = true;
  if (first_time)
  {
    std::srand(time(0));
    first_time = false;
  }

  // keep looping till the randomly generated row/column are of an
  // unoccupied cell

  bool computer_moved = false;
  while (!computer_moved)
  {
    int row = rand() % BOARD_SIZE;
    int col = rand() % BOARD_SIZE;

    if (tictactoe[row][col] == UNOCCUPIED)
    {
      tictactoe[row][col] = PLAYER_O;
      std::cout << "Computer chooses: " << row + 1 << col + 1 << std::endl;

      computer_moved = true;
    }
  }
}

bool isWinner(TicTacToeBoard tictactoe, char player)
{
  bool winner = false;

  // check all rows
  for (int r = 0; r < BOARD_SIZE && !winner; r++)
  {
    winner = true;
    for (int c = 0; c < BOARD_SIZE; c++)
    {
      if (tictactoe[r][c] != player)
      {
        winner = false;
      }
    }
  }

  // check all columns
  for (int c = 0; c < BOARD_SIZE && !winner; c++)
  {
    winner = true;
    for (int r = 0; r < BOARD_SIZE; r++)
    {
      if (tictactoe[r][c] != player)
      {
        winner = false;
      }
    }
  }

  // check upper-left to lower-right diagonal (00 11 22)
  for (int r = 0; r < BOARD_SIZE && !winner; r++)
  {
    winner = true;
    for (int c = 0; c < BOARD_SIZE; c++)
    {
      if (tictactoe[c][c] != player)
      {
        winner = false;
      }
    }
  }

  // check lower-left to upper-right diagonal (02 11 20)
  for (int r = 0; r < BOARD_SIZE && !winner; r++)
  {
    winner = true;
    for (int c = 0; c < BOARD_SIZE; c++)
    {
      if (tictactoe[c][BOARD_SIZE - 1 - c] != player)
      {
        winner = false;
      }
    }
  }

  return winner;
}
