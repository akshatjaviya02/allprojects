// Tic-Tac-Toe
// This program allows the user to play tic-tac-toe against the computer.

#include <iostream>
#include "tictactoe.hpp"

int main()
{
  TicTacToeBoard tictactoe;
  int move;
  int curr_play = 0;
  bool winner = false;

  // TODO:
  // initialize the board to all empty squares
  // hint: you will need a nested for loop, and you will set each item in
  // the array to UNOCCUPIED (this constant is defined in tictactoe.hpp)share my s
  for (int rows = 0; rows < BOARD_SIZE; rows++)
  {
    for (int col = 0; col < BOARD_SIZE; col++)
    {
      tictactoe[rows][col] = UNOCCUPIED;
    }
  }

  // display opening message to the user
  std::cout << "\nLet's play tic-tac-toe. You be \'" << PLAYER_X
    << "\' and computer will be \'" << PLAYER_O << "\'\n";
  std::cout << "To select a move, enter the numeric ID of the desired square.\n";

  // keep looping as long as there are plays to be made and no winner
  // has been declared
  while (curr_play < MAX_PLAYS && !winner)
  {
    displayBoard(tictactoe);

    bool valid;
    do
    {
      std::cout << "\nEnter your move: ";
      std::cin >> move;

      valid = isValidMove(tictactoe, move);
      if (!valid)
      {
        std::cout << "That is not a valid move, try again.\n";
      }
    } while (!valid);

    curr_play++;
    winner = isWinner(tictactoe, PLAYER_X);
    if (winner)
    {
      std::cout << "\nYou won!" << std::endl;
    }
    else if (curr_play < MAX_PLAYS)
    {
      // no need to range check curr_play since user gets the first move
      // therefore computer always gets a move after the user does
      curr_play++;
      computerMove(tictactoe);

      winner = isWinner(tictactoe, PLAYER_O);
      if (winner)
      {
        std::cout << "\nI'm sorry, but the computer won." << std::endl;
      }
    }
  }

  // display message if nobody won
  if (!winner)
  {
    std::cout << "\nCat's game!" << std::endl;
  }

  // print final message
  std::cout << "Final board:" << std::endl;
  displayBoard(tictactoe);
  std::cout << std::endl;

  return 0;
}
