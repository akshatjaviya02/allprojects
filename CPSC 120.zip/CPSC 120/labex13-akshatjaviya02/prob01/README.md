# Tic-Tac-Toe
In this program, you will be using C++ programming constructs, such as functions and 2-dimensional arrays. You will find the compiler errors, fill in the TODO code, and test that the code behaves as expected.

## main.cpp
This program plays tic-tac-toe: computer against the user. The program continues till all squares of the tic-tac-toe board have been filled, and it then displays the final results to the user, including a message declaring who won, if there was a winner.

This function has mostly been provided for you, but has bugs and has one "TODO" section of code. Please correct the bugs, and fill in the "TODO" portion of the code.

## isValidMove()
Skeleton code for this function has been created. Please fill in the remaining code according to the description provided in the "TODO" comment.

## Input Validation()
1. You can assume the user will always input an integer value
1. The function `isValidMove()` checks that the integer value is a valid unoccupied cell in the game board and returns `false` if it is not

# Hints
1. Be sure to include the file `tictactoe.hpp` with the preprocessor directives (`#include` files) so that the compiler includes the program constants and function prototypes.

# Compile
Since your program now includes two cpp files, you need to include both in the compile command.
```
clang++ -std=c++17 main.cpp tictactoe.cpp -o main
```

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Let's play tic-tac-toe. You be 'X' and computer will be 'O'
To select a move, enter the numeric ID of the desired square.

 11 12 13
 21 22 23
 31 32 33

Enter your move: <b>22</b>
Computer chooses: 12

 11  O 13
 21  X 23
 31 32 33

Enter your move: <b>11</b>
Computer chooses: 23

  X  O 13
 21  X  O
 31 32 33

Enter your move: <b>33</b>

You won!
Final board:

  X  O 13
 21  X  O
 31 32  X
</pre>

## Sample Output #2
<pre>
Let's play tic-tac-toe. You be 'X' and computer will be 'O'
To select a move, enter the numeric ID of the desired square.

 11 12 13
 21 22 23
 31 32 33

Enter your move: <b>11</b>
Computer chooses: 33

  X 12 13
 21 22 23
 31 32  O

Enter your move: <b>11</b>
That is not a valid move, try again.

Enter your move: <b>23</b>
Computer chooses: 22

  X 12 13
 21  O  X
 31 32  O

Enter your move: <b>32</b>
Computer chooses: 12

  X  O 13
 21  O  X
 31  X  O

Enter your move: <b>31</b>
Computer chooses: 21

  X  O 13
  O  O  X
  X  X  O

Enter your move: <b>13</b>

Cat's game!
Final board:

  X  O  X
  O  O  X
  X  X  O
</pre>

## Sample Output #3
<pre>
Let's play tic-tac-toe. You be 'X' and computer will be 'O'
To select a move, enter the numeric ID of the desired square.

 11 12 13
 21 22 23
 31 32 33

Enter your move: <b>11</b>
Computer chooses: 12

  X  O 13
 21 22 23
 31 32 33

Enter your move: <b>10</b>
That is not a valid move, try again.

Enter your move: <b>44</b>
That is not a valid move, try again.

Enter your move: <b>21</b>
Computer chooses: 22

  X  O 13
  X  O 23
 31 32 33

Enter your move: <b>13</b>
Computer chooses: 32

I'm sorry, but the computer won.
Final board:

  X  O  X
  X  O 23
 31  O 33
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used a constant instead of a hardcoded literals in your expressions*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce similar results as the Sample Output?
     - *Note your results will not be exact due to the randomness of the computer selections*
1. **Error check**
   - Does your program print an error and ask again if the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
