#ifndef __TICTACTOE_H__
#define __TICTACTOE_H__

//-----------
// Constants
//-----------

// size of a tic-tac-toe board is 3x3, allowing up to 9 plays

const int BOARD_SIZE = 3;
const int MAX_PLAYS = BOARD_SIZE * BOARD_SIZE;

// settings for the game board squares, X or O are squares occupied
// by one of the players, and E indicates an available square

const char UNOCCUPIED = 'U';
const char PLAYER_X = 'X';
const char PLAYER_O = 'O';

// type defined for a tic-tac-toe board (3x3 game board)

typedef char TicTacToeBoard[BOARD_SIZE][BOARD_SIZE];


//---------------------
// Function prototypes
//---------------------

// this function prints out the game board, including whether each
// of the squares is occupied by a player
// Parameters:
//  1. a two-dimensional array containing the tic-tac-toe game board
// Return value:
//  1. none
void displayBoard(TicTacToeBoard tictactoe);


// this function determines whether the move selected by the player
// is valid (valid moves are those where the player selects a square
// that is part of the game board and is not already occupied)
// Parameters:
//  1. a two-dimensional array containing the tic-tac-toe game board
//  2. an integer indicating the desired move (this int represents a
//     row and column (both 1 to 3) of the game board)
// Return value:
//  1. true/false whether the move is valid
bool isValidMove(TicTacToeBoard tictactoe, int move);


// this function checks the game board to determine whether a winner
// can be declared (one player occupying 3 squares in-a-row)
// Parameters:
//  1. a two-dimensional array containing the tic-tac-toe game board
//  2. a character representing the player to check for whether this
//     char has 3 in a row
// Return value:
//  1. true/false whether the player has won
bool isWinner(TicTacToeBoard tictactoe, char player);


// this function selects a move for the computer to make
// Parameters:
//  1. a two-dimensional array containing the tic-tac-toe game board
// Return value:
//  1. none
void computerMove(TicTacToeBoard tictactoe);


#endif
