// Is Equal
// This program tests arrays of structs to determine whether they are
// equal to each other.

#include <iostream>
#include "types.hpp"

int main()
{
  // hardcoded arrays of structs (to be tested for equality)
  // comparisons will be made using ary1 against the other 3 arrays

  TeamMembers ary1 = {
    { "Titan", "Tuffy", { 2000,  1,  1 } },
    { "Doe",   "Jane",  { 1996,  7, 15 } },
    { "Smith", "Larry", { 1999, 12, 21 } }
  };

  TeamMembers ary2 = {
    { "Titan", "Tuffy", { 2000,  1,  1 } }, // no diffs from ary1
    { "Doe",   "Jane",  { 1996,  7, 15 } },
    { "Smith", "Larry", { 1999, 12, 21 } }
  };

  TeamMembers ary3 = {
    { "Titan", "Tuffy", { 2000,  1,  1 } }, // only diff is one first name
    { "Doe",   "Sue",   { 1996,  7, 15 } },
    { "Smith", "Larry", { 1999, 12, 21 } }
  };

  TeamMembers ary4 = {
    { "Titan", "Tuffy", { 2000,  1,  1 } }, // only diff is one birtdate
    { "Doe",   "Jane",  { 1996,  7, 15 } },
    { "Smith", "Larry", { 1999, 11,  8 } }
  };

  std::cout << "\nThe following arrays were compared against ary1:\n";

  // one at a time, compare each of the arrays (ary2, ary3, ary4) against ary1
  bool eq = isEqual(ary1, ary2, MAX_TEAM_SIZE);
  std::cout << " - ary2 " << (eq ? "is" : "is not") << " equal to ary1\n";

  // TODO:
  // compare ary3 against ary1
  // compare ary4 against ary1
  eq = isEqual(ary3, ary1, MAX_TEAM_SIZE);
  std::cout << " - ary3 " << (eq ? "is" : "is not") << " equal to ary1\n";
  eq = isEqual(ary4, ary1, MAX_TEAM_SIZE);
  std::cout << " - ary4 " << (eq ? "is" : "is not") << " equal to ary1\n";

  return 0;
}

// TODO:
// add the function definition for isEqual

bool isEqual(TeamMembers ary1, TeamMembers ary2, int size)
{
  bool Equal = true;
  for (int count = 0; count < size; count++)
  {
    if (ary1[count].frist_name != ary2[count].frist_name)
    {
      return false;
    }
    else if (ary1[count].last_name != ary2[count].last_name)
    {
      return false;
    }
    else if (ary1[count].date.year != ary2[count].date.year)
    {
      return false;
    }
    else if (ary1[count].date.day != ary2[count].date.day)
    {
      return false;
    }
    else if (ary1[count].date.month != ary2[count].date.month)
    {
      return false;
    }
  }
  return true;
}
