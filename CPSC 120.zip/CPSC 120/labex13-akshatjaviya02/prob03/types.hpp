#ifndef __TYPES_H__
#define __TYPES_H__

#include <string>


//-----------
// Constants
//-----------

// maximum number of team members allowed

const int MAX_TEAM_SIZE = 3;


//---------------------
// Type definitions
//---------------------

// struct to hold a date
// note: the member for "year" is the 4 digit year

struct Date
{
  int year;
  int month;
  int day;
};

// TODO:
// define a struct named Person containing 3 members:
// 2 strings for the person's last name and first name,
// and 1 Date type for the person's birthdate
struct Person
{
  std::string frist_name;
  std::string last_name;
  Date date;
};

// TODO:
// define a type named TeamMembers that is an array of Person structs,
// the size of the array is defined by the constant MAX_TEAM_SIZE
// hint: use the "typedef" key word
typedef Person TeamMembers[MAX_TEAM_SIZE];

//---------------------
// Function prototypes
//---------------------

// This function compares 2 arrays to determine whether they are
// equal to each other.
// Parameters:
//  1. an array of Person structs
//  2. another array of Person structs
//  3. the size of the arrays (both arrays are the same size)
// Return value:
//  1. true/false whether the two arrays are the same

bool isEqual(TeamMembers ary1, TeamMembers ary2, int size);

#endif
