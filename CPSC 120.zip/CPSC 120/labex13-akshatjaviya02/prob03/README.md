# Array Statistics
In this program, you will be using C++ programming constructs, such as functions, structs, and arrays.

## main.cpp
Write a program that compares arrays of structs against each other to determine whether they are equal and outputs the results to the console.

Skeleton code has been provided. Please find the TODO comments and fill in the missing code for each according to the descriptions.

## types.hpp
The struct for Date has been defined. Please define the struct for Person as well as the type definition for the array.

## isEqual()
The function prototype for `isEqual()` is found in `types.hpp` along with a description of the function and function parameters. Please add the function definition for `isEqual()` to the end of the file `main.cpp`

This function receives 2 array parameters, and loops through all elements of the arrays, comparing one array to the other, including comparing all members of the structs for each array element.
This function returns true/false to the caller, indicating whether any difference was found.

# Hints
1. The compiler doesn't know how to compare 2 arrays or 2 structs
   - You will need to compare these data types one element at a time
1. If a struct has an element that is also a struct, you will use the period twice in order to get to the inner struct

# Sample Output
```
The following arrays were compared against ary1:
 - ary2 is equal to ary1
 - ary3 is not equal to ary1
 - ary4 is not equal to ary1
```

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used a constant instead of a hardcoded literals*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce similar results as the Sample Output?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
