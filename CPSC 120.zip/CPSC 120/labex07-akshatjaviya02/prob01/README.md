# Relational Expressions
In this program, you will use the conditional operator, logical operators, and calls to test characters.

## main.cpp
Find the statements marked "TODO" in the program, and follow the instructions found there.

# Hints
1. You are welcome to check through the lecture slides to help you answer the TODO statements

# Grading Checklist
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **TODO**
   - Did you complete the code instructed for all of the "TODO" statements?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
