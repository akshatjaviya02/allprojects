// working with logical operators, the conditional operator, and
// character tests

#include <iostream>
#include <cctype>

int main()
{
  // TODO#1 add code to write the following if/else statement
  // using the conditional operator instead of an if/else block
  std::cout << "TODO#1\n";

  double amount = 1.11;
  double factor;

  amount < 20 ? factor = 1.4 : factor = 1.3;

  std::cout << "The variable \"factor\" is now " << factor << std::endl;

  // TODO#2 write a single if statement that will be entered if x falls in
  // the following range:  0 <= x <= 100
  // hint: you will need a logical operator in the conditional expression
  std::cout << "\nTODO#2\n";

  int x = 100;

  if (x >= 0 && x <= 100) // TODO: add conditional expression
  {
    std::cout << "x falls within the range 0 to 100\n";
  }
  else
  {
    std::cout << "*** try again ***\n";
  }

  // TODO#3 write a single if statement that will be entered if x falls outside
  // the range of 0 to 100
  // note: you will need a logical operator in the conditional expression
  std::cout << "\nTODO#3\n";

  x = -1;

  if (x < 0 || x > 100) // TODO: add conditional expression
  {
    std::cout << "x falls outside the range 0 to 100\n";
  }
  else
  {
    std::cout << "*** try again ***\n";
  }

  // TODO#4 set the value for the character ch for each of the calls below
  // so that it will cause "true" to be printed
  // note: choose a different character for each
  std::cout << "\nTODO#4\n";

  char ch;
  bool ret;

  ch = 'A';
  ret = isalpha(ch);
  std::cout << "isalpha for char " << ch << " is " << (ret ? "true" : "false") << std::endl;

  ch = 'K';
  ret = isalnum(ch);
  std::cout << "isalnum for char " << ch << " is " << (ret ? "true" : "false") << std::endl;

  ch = '2';
  ret = isdigit(ch);
  std::cout << "isdigit for char " << ch << " is " << (ret ? "true" : "false") << std::endl;

  ch = 's';
  ret = islower(ch);
  std::cout << "islower for char " << ch << " is " << (ret ? "true" : "false") << std::endl;

  ch = 'h';
  ret = isprint(ch);
  std::cout << "isprint for char " << ch << " is " << (ret ? "true" : "false") << std::endl;

  ch = ';';
  ret = ispunct(ch);
  std::cout << "ispunct for char " << ch << " is " << (ret ? "true" : "false") << std::endl;

  ch = 'T';
  ret = isupper(ch);
  std::cout << "isupper for char " << ch << " is " << (ret ? "true" : "false") << std::endl;

  ch = ' ';
  ret = isspace(ch);
  std::cout << "isspace for char " << ch << " is " << (ret ? "true" : "false") << std::endl;

  return 0;
}
