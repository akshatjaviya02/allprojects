// This program calculates the amount due for a vehicle driving the toll road.

#include <iostream>
#include "types.hpp"
#include <iomanip>

int main()
{
  // user input variables
  int number_toll_sites;
  int tag_type_int;
  int tag_state_int;

  // enum representation of the input data
  TagState tag_state;
  TagType tag_type;

  // variables used for calculating the amount due
  double amount_due = 0;
  double fee_factor = 1;

  std::cout << "Enter the number of toll sites the vehicle drove through: ";
  std::cin >> number_toll_sites;

  std::cout << "\nEnter the transponder type" << std::endl;
  std::cout << "  0: standard" << std::endl;
  std::cout << "  1: large truck" << std::endl;
  std::cout << "  2: exempt" << std::endl;
  std::cout << "Option: ";
  std::cin >> tag_type_int;

  std::cout << "\nEnter the transponder status" << std::endl;
  std::cout << "  0: active" << std::endl;
  std::cout << "  1: low balance" << std::endl;
  std::cout << "  2: negative balance" << std::endl;
  std::cout << "  3: lost" << std::endl;
  std::cout << "  4: stolen" << std::endl;
  std::cout << "  5: terminated" << std::endl;
  std::cout << "  6: unknown" << std::endl;
  std::cout << "Option: ";
  std::cin >> tag_state_int;

  // convert the input to enumerated values
  tag_type  = static_cast<TagType>(tag_type_int);
  tag_state = static_cast<TagState>(tag_state_int);

  // set the factor that will be applied to the fee
  if (tag_state == NEGATIVE_BALANCE)
  {
    fee_factor *= NEGATIVE_BALANCE_FACTOR;
  }

  // apply an additional factor for large trucks
  if (tag_type == LARGE_TRUCK)
  {
    fee_factor *= LARGE_TRUCK_FACTOR;
  }

  // initialize the state of whether the transponder is valid
  bool invalid = false;

  // calculate the amount due
  switch (tag_state)
  {
    case ACTIVE:
    case LOW_BALANCE:
    case NEGATIVE_BALANCE:
    case UNKNOWN:
      // set amount due based on how many toll gates were crossed
      // and the fee factor to be applied
      amount_due = BASE_RATE * number_toll_sites * fee_factor;
      break;

      case REPORTED_LOST:
      case REPORTED_STOLEN:
      case TERMINATED:
    default:
      // mark the transaction as invalid
      invalid = true;
      break;
  }

  // print message to the user telling how much they owe
  std::cout << "\n=====>> ";

  if (invalid)
  {
    std::cout << "You have an invalid tag.\n\n";
  }
  else if (tag_type == EXEMPT)
  {
    std::cout << "You have an exempt tag. You owe nothing.\n\n";
  }
  else
  {
    std::cout << "$" << std::setprecision(2) << std::fixed
      << amount_due << " will be charged to your account.\n\n";
  }

  return 0;
}
