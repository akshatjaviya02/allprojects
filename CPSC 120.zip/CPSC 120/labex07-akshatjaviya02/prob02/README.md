# Find the Errors
In this program, you will debug a program that contains the following errors:
1. Compile time bugs
1. Run time bugs (these compile but produce error output values)

## main.cpp
1. Try compiling the program to find out what errors the compiler finds
1. Find and fix the compile time bug(s)
1. Once the program compiles, try running it to see whether it outputs the expected results
1. Find and fix any bug(s) in the program that are causing incorrect results to be output

# Hints
1. Purposefully enter an incorrect answer to see how your program handles it
1. Make sure the values output from the test.sh script match those in the Test Script Output below
1. The compiler outputs the line number and column of the error if a compile time error is encountered
   e.g., `main.cpp:27:37` indicates an error in your code on line 27, column 37
1. Be sure to include the necessary libraries
   e.g. `main.cpp:14:3: error: ‘TagState’ was not declared in this scope` indicates the library is missing
   - For this lab, we have a user defined library named "types.hpp"
1. Keep in mind you cannot read user input into an `enum` data type
   - Instead, read the user input into an `int` and then copy the value to the `enum` by type casting it to the `enum` data type
1. Be sure all cases in the switch statement are valid for the data type of the `IntExpression`
   - Look in `types.hpp` to see what valid enumerated values are allowed for each of the `enum` data types
1. Watch out for assignment (=) versus the equality operator (==)
1. Watch out for variables defined with local or block scope

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Enter the number of toll sites the vehicle drove through: <b>3</b>

Enter the transponder type
  0: standard
  1: large truck
  2: exempt
Option: <b>1</b>

Enter the transponder status
  0: active
  1: low balance
  2: negative balance
  3: lost
  4: stolen
  5: terminated
  6: unknown
Option: <b>2</b>

=====>> $3.98 will be charged to your account.
</pre>

## Sample Output #2
<pre>
Enter the number of toll sites the vehicle drove through: <b>7</b>

Enter the transponder type
  0: standard
  1: large truck
  2: exempt
Option: <b>2</b>

Enter the transponder status
  0: active
  1: low balance
  2: negative balance
  3: lost
  4: stolen
  5: terminated
  6: unknown
Option: <b>4</b>

=====>> You have an invalid tag.
</pre>

## Sample Output #3
<pre>
Enter the number of toll sites the vehicle drove through: <b>5</b>

Enter the transponder type
  0: standard
  1: large truck
  2: exempt
Option: <b>2</b>

Enter the transponder status
  0: active
  1: low balance
  2: negative balance
  3: lost
  4: stolen
  5: terminated
  6: unknown
Option: <b>0</b>

=====>> You have an exempt tag. You owe nothing.
</pre>

# Grading Checklist
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `==` `&&` `||`, etc.)
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Sample Output**
   - Does your program produce the same results as the Sample Output?
     - Valid tag prints the charge
     - Invalid tag (lost, stolen, or terminated) prints an error message
     - Exempt tag prints no charge owed
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
