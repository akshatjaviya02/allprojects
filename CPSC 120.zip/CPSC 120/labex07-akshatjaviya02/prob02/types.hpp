
// factor applied to the amount due for fleet vehicles

const double LARGE_TRUCK_FACTOR      = 1.2;
const double NEGATIVE_BALANCE_FACTOR = 1.3;

// base rate applied to each toll gate crossing

const double BASE_RATE = 0.85;

// the following enum stores the possible states assigned
// to a customer transponder or in-vehicle-unit

enum TagState
{
  ACTIVE,
  LOW_BALANCE,
  NEGATIVE_BALANCE,
  REPORTED_LOST,
  REPORTED_STOLEN,
  TERMINATED,
  UNKNOWN
};

// the following enum stores the possible types of
// transponders or in-vehicle-units

enum TagType
{
  STANDARD,
  LARGE_TRUCK,
  EXEMPT
};
