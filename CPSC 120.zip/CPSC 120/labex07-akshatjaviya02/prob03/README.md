# Convert to Roman Numeral
In this program, you will be using C++ programming constructs, such as the relational operator, enums, and a switch statement.

## main.cpp
Write a program that asks the user to enter a number within the range of 1 through 10. Use a *switch* statement to display the Roman Numeral representation of that number. If the number entered is not in range, print an error message, as shown in the Sample Output below.

## Enumerated data type
Please create an *enum* for the roman numerals
- I = 1, II = 2, and so on down to X = 10
- Your *switch* statement will use a variable of this data type (e.g., `switch (your_enum_variable)`), and will use the enumerated values as the cases (e.g., `case I:`)

# Hints
1. Don't forget to add *input validation* to ensure the user input is in range
   - Print an error message if it is not
1. Keep in mind you cannot read user input into an *enum*
   - Instead, read the user input into an `int` and type cast that variable to set the value of your *enum*

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Enter an integer in the range of 1 - 10: <b>3</b>
The Roman Numeral for 3 is III
</pre>

## Sample Output #2
<pre>
Enter an integer in the range of 1 - 10: <b>100</b>
The number 100 is out of range
</pre>

## Sample Output #3
<pre>
Enter an integer in the range of 1 - 10: <b>-5</b>
The number -5 is out of range
</pre>

## Test Script
*Note: if you work in Repl.it or another online compiler, you do not need to run the test script. However, be sure your program produces the correct results with all valid values as well as some invalid values.*

We have something new with this lab. There is a test script called `test.sh` that will run your program using multiple different values in order to test more of the program. It tests all possible values for the *enum* as well as a few error conditions as well.

You can run the test script by typing:
   ```
   ./test.sh
   ```
If you receive an error when you try to run the script, you might need to change permissions on the file by typing the following. *Note: this needs to be done only once:*
   ```
   chmod 744 test.sh
   ```

# Test Script Output
```
Enter an integer in the range of 1 - 10: The Roman Numeral for 1 is I
Enter an integer in the range of 1 - 10: The Roman Numeral for 2 is II
Enter an integer in the range of 1 - 10: The Roman Numeral for 3 is III
Enter an integer in the range of 1 - 10: The Roman Numeral for 4 is IV
Enter an integer in the range of 1 - 10: The Roman Numeral for 5 is V
Enter an integer in the range of 1 - 10: The Roman Numeral for 6 is VI
Enter an integer in the range of 1 - 10: The Roman Numeral for 7 is VII
Enter an integer in the range of 1 - 10: The Roman Numeral for 8 is VIII
Enter an integer in the range of 1 - 10: The Roman Numeral for 9 is IX
Enter an integer in the range of 1 - 10: The Roman Numeral for 10 is X
Enter an integer in the range of 1 - 10: The number -5 is out of range
Enter an integer in the range of 1 - 10: The number 0 is out of range
Enter an integer in the range of 1 - 10: The number 11 is out of range
Enter an integer in the range of 1 - 10: The number 100 is out of range
```

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `+` `-` `*` `/` `%` `=` `<<` `>>`)
1. **Variables**
   - Did you use variable names appropriate for the purpose/usage of the variable?
1. **Switch/Case statement**
   - Did you use an `enum` data type in the `switch` as well as each `case` of your switch statement?
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
1. **Test script**
   - Does your program produce the same results as the Test Script Output?
     - *If you are unable to run the Test Script, be sure to run your program multiple times with both valid and invalid input values* (e.g. invalid: `-3` `0` `11`) (e.g. valid: `1` through `10`)
1. **Error check**
   - Does your program output an error message when the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
