// Convert an integer to a Roman Numeral
#include <iostream>
enum RomanNumber
{
  I = 1, II, III, IV, V, VI, VII, VIII, IX, X
};
int main ()
{
  int number;
  RomanNumber roman;
  std::cout << "Enter an integer in the range of 1 - 10: ";
  std::cin >> number;

  roman = static_cast<RomanNumber>(number);
  switch (roman)
  {
    case I:
     std::cout << "The Roman Numeral for 1 is I\n";
     break;

    case II:
      std::cout << "The Roman Numeral for 2 is II\n";
      break;

    case III:
      std::cout << "The Roman Numeral for 3 is III\n";
      break;
    case IV:
      std::cout << "The Roman Numeral for 4 is IV\n";
      break;
    case V:
      std::cout << "The Roman Numeral for 5 is V\n";
      break;
    case VI:
      std::cout << "The Roman Numeral for 6 is VI\n";
      break;
    case VII:
      std::cout << "The Roman Numeral for 7 is VII\n";
      break;
    case VIII:
      std::cout << "The Roman Numeral for 8 is VIII\n";
      break;
    case IX:
      std::cout << "The Roman Numeral for 9 is IX\n";
      break;
    case X:
      std::cout << "The Roman Numeral for 10 is X\n";
      break;

    default:
      std::cout << "The number " << number << " is out of range\n";
  }
  return 0;
}
