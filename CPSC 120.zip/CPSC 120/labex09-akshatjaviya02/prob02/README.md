# Find the Errors
In this program, you will debug a program that contains the following:
1. Compile time bugs
1. Run time bugs (these compile but produce error output values)

## main.cpp
1. Try compiling the program to find out what errors the compiler finds
1. Find and fix the compile time bug(s)
1. Once the program compiles, try running it to see whether it outputs the expected results
1. Find and fix any bug(s) in the program that are causing incorrect results to be output

# Hints
1. Purposefully enter an incorrect answer to see how your program handles it
1. If your program keeps choosing the same "random" value each time you run it, double check that you are setting the seed properly
1. If your program gets into an infinite loop, type `<Ctrl> c` to stop the program
1. The compiler outputs the line number and column of the error if a compile time error is encountered
   e.g., `main.cpp:15:37` indicates an error in your code on line 15, column 37

# Sample Output
Please run your program multiple times to see that the random number changes each time you run the program. You do not need to recompile between runs.

***Note: your program output will not necessarily match the samples below due to the randomness of the problems displayed to the user***

Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Please select an option
1. Addition problem
2. Subtraction problem
3. Multiplication problem
4. Quit this program
Option: <b>1</b>

    27
 +  38
   ---
    <b>33</b>

Sorry, the correct answer is 65.

Please select an option
1. Addition problem
2. Subtraction problem
3. Multiplication problem
4. Quit this program
Option: <b>2</b>

    28
 -  12
   ---
    <b>16</b>

Congratulations! That's right.

Please select an option
1. Addition problem
2. Subtraction problem
3. Multiplication problem
4. Quit this program
Option: <b>3</b>

     5
 *   6
   ---
    <b>30</b>

Congratulations! That's right.

Please select an option
1. Addition problem
2. Subtraction problem
3. Multiplication problem
4. Quit this program
Option: <b>9</b>

Invalid option.

Please select an option
1. Addition problem
2. Subtraction problem
3. Multiplication problem
4. Quit this program
Option: <b>4</b>

Thank you for using Math Tutor.
</pre>

# Grading Checklist
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Random**
   - Does your program produce a different set of problems every time you run it?
1. **Output**
   - Does your program output the proper message for each of the following?
     - *User chooses an invalid option*
     - *User answer is right*
     - *User answer is wrong*
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
