// This menu-driven program creates a random arithmetic problem
// for different types of arithmetic requested by the user.

#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
#include <iomanip>

int main()
{
  // problem values will be between 1 and 50
  const int MAX_NUM = 50;
  const int COLUMN_WIDTH = 6;
  const int TWO_DIGITS_MIN = 10;
  const int THREE_DIGITS_MIN = 100;
  unsigned seed = time (0);
  srand (seed);

  int choice, number1, number2;
  int correct_answer, student_answer;

  std::string sign; // will be assigned +, -, or *

  do
  {
    // display menu and get user's menu choice
    std::cout << "\nPlease select an option\n";
    std::cout << "1. Addition problem\n";
    std::cout << "2. Subtraction problem\n";
    std::cout << "3. Multiplication problem\n";
    std::cout << "4. Quit this program\n";
    std::cout << "Option: ";
    std::cin >> choice;

    // carry out the user's choice
    switch (choice)
    {
      case 1:  // addition problem
        number1 = 1 + rand() % MAX_NUM;
        number2 = 1 + rand() % MAX_NUM;
        sign = " + ";
        correct_answer = number1 + number2;
        break;

      case 2:  // subtraction problem
        number1 = 1 + rand() % MAX_NUM;
        number2 = 1 + rand() % number1; // make sure num2 is <= num1
        sign = " - ";
        correct_answer = number1 - number2;
        break;

      case 3:  // multiplication problem, multipliers only up to 10
        number1 = 1 + rand() % TWO_DIGITS_MIN;
        number2 = 1 + rand() % TWO_DIGITS_MIN;
        sign = " * ";
        correct_answer = number1 * number2;
        break;

      case 4:  // exit
        std::cout << "\nThank you for using Math Tutor.\n";
        continue;

      default: // invalid menu selection, ask user again for an option
        std::cout << "\nInvalid option.\n";
        continue;
    }

    // display it
    std::cout << std::endl
      << std::setw(COLUMN_WIDTH) << number1 << std::endl
      << sign << std::setw(COLUMN_WIDTH - sign.length()) << number2 << std::endl
      << "   ---"  << std::endl;

    // position the output cursor for the user's input
    std::cout << "   ";
    if (correct_answer < TWO_DIGITS_MIN)
    {
      std::cout << "  ";
    }
    else if (correct_answer < THREE_DIGITS_MIN)
    {
      std::cout << " ";
    }

    // get and evaluate student answer
    std::cin >> student_answer;

    if (student_answer == correct_answer)
    {
        std::cout << "\nCongratulations! That's right.\n";
    }
    else
    {
        std::cout << "\nSorry, the correct answer is " << correct_answer << ".\n";
    }

  } while (choice != 4);  // loop again if student did not choose to quit

  return 0;
}
