# Rainfall Report
In this program, you will be using C++ programming constructs, such as files, loops and relational operators.

## main.cpp
Write a program that asks the user to give a file name, and then reads from the file to get a list of months and the rainfall for each of the months.

The program will then calculate and display the following statistics to the console:
1. Total number of months
1. Total rainfall
1. Average rainfall per month
1. Name of the month with the most rainfall
1. Name of the month with the least rainfall

## Input Validation
1. Your program should output an error message if the input file is not found
1. Your program should also output a meaningful message if the input file is empty
1. You can assume the file name will never have spaces in it

# Hints
1. Because the program does not know how many months of data is in the file, it must read and process data values until the end of file is encountered
   - *See lecture slide on reading from a file until the end of file (EOF) is hit*
1. For the largest and smallest months of rainfall, set variables to keep track of the rainfall amount for the month as well as the name of the month with that rainfall value
1. If your program gets into an infinite loop, type `<Ctrl> c` to stop the program

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Please enter the file name: <b>rainfall.txt</b>

Rainfall Report
Number of months:  6
Total rainfall:    7.54
Average per month: 1.25667
Highest rainfall:  April
Lowest rainfall:   July
</pre>

## Sample Output #2
<pre>
Please enter the file name: <b>onemonth.txt</b>

Rainfall Report
Number of months:  1
Total rainfall:    2.17
Average per month: 2.17
Highest rainfall:  February
Lowest rainfall:   February
</pre>

## Sample Output #3
<pre>
Please enter the file name: <b>rainfall.dat</b>

File "rainfall.dat" not found
</pre>

## Sample Output #4
<pre>
Please enter the file name: <b>empty.txt</b>

File "empty.txt" is empty
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure the error messages include quotation marks around the file name*
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
