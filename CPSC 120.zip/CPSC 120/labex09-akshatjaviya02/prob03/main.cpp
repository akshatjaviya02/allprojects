// This program reads in from a file a list of month names followed by the
// rainfall amounts for each month. The program then displays statistics
// on the rainfall amounts.

#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>

int main ()
{
  //variables
  int month = 0;
  double total_month = 0.0;
  double average = 0.0;
  double rain = 0.0;
  double high, low;
  std::string hmonth, lmonth, months;
  double total;


  // reading the files and writing the files
  std::ifstream in_file;
  std::string file_name;

  std::cout << "Please enter the file name: ";
  std::cin >> file_name;

  //checks for the file
  in_file.open(file_name);
  if (in_file) // check the file
  {
    while (in_file >> months >> rain)
    {
      if (rain > high || month == 0)
      {
        high = rain;
        hmonth = months;
      }
      if (rain < low || month == 0)
      {
        low = rain;
        lmonth = months;
      }
      total += rain;
      month++;
    }
    if (month == 0)
    {
      std::cout << "File \"" << file_name << "\" is empty\n";
    }
    else
    {
      //calculations
      average = (total / month);
      //displacy
      std::cout << "Rainfall Report\n";
      std::cout << "Number of months:  " << month << std::endl;
      std::cout << "Total rainfall:    " << total << std::endl;
      std::cout << "Average per month: " << average << std::endl;
      std::cout << "Highest Rainfall:  " << hmonth << std::endl;
      std::cout << "lowest Rainfall:   " << lmonth << std::endl;
    }
    // file is being close
    in_file.close();
  }
else
{
  std::cout << "File \"" << file_name << "\" not found\n";
}

return 0;
}
