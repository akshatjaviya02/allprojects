// This program creates a table displaying the number of calories
// burned running on a treadmill for various numbers of minutes
// and writes that table to a file.

#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

int main()
{
  // constants
  const int COLUMN_WIDTH = 10;
  const int INTERVAL_MIN = 1;
  const int INTERVAL_MAX = 60;
  const double CALORIES_PER_MINUTE = 3.9;
  const std::string FILE_NAME = "calories.txt";
  int num;
  double total_calories;

  // local variables
  int minutes;
  std::ofstream out_file;

  // ** TODO: open the output file **
  out_file.open (FILE_NAME);

  // ask user for the interval, keep looping till valid value entered
  // ** TODO: create a "do/while" loop for this **

  do
  {
    std::cout << "Enter number of minutes for each inteval (1-60): ";
    std::cin >> num;
  } while (num <= INTERVAL_MIN || num >= INTERVAL_MAX);

  // print table column headers
  out_file << std::setw(COLUMN_WIDTH) << "Minutes"
    << std::setw(COLUMN_WIDTH) << "Calories" << std::endl;

  // loop through intervals and write to file the intervals and calories
  // ** TODO: create a "for" loop for this **
  for (int num1 = num; num1 <= INTERVAL_MAX; num1 += num)
  {

    total_calories = num1 * CALORIES_PER_MINUTE;
    out_file << std::setw(COLUMN_WIDTH) <<num1 << std::setw(COLUMN_WIDTH)
      << std::setprecision(1) << std::fixed << total_calories << std::endl;
  }

  // ** TODO: close the output file **
  out_file.close();

  return 0;
}
