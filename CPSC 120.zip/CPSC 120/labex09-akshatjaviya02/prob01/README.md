# Calories Burned on a Treadmill
In this program, you will be using C++ programming constructs, such as the *do/while* loop and the *for* loop.

## main.cpp
Write a program that asks the user to enter the frequency (in minutes) for which the user wants to display total calories burned. For instance, if the user enters 3, then the total calories burned will be displayed for 3 minute increments (3, 6, 9, 12, etc.)

The total calories burned should be displayed with a precision of 1 digit past the decimal.

**All output should be written to a file rather than the console.**

Your program should use the following loops
1. a *do/while* loop to continue asking the user for a the frequency
   - this loop will continue looping if the frequency doesn't fall between 1 and 60 *(use constants for these values)*
   - *be sure to use the constants in the cout statement as well*
1. a *for* loop to display the output
   - *Hint: the initial value for the loop control variable as well as the increment value can both be set to the user input value.*

## Constants
The following constants have been defined for you
1. The width of the output columns, set to 10
1. The minimum frequency interval the user can select, set to 1
1. The maximum frequency interval the user can select, set to 60
1. The number of calories burned per minute, set to 3.9
1. The name of the output file, set to "calories.txt"

## Input Validation
1. Your program should display an error message and ask the user to try again if the user enters an invalid value for the frequency interval
   - *Hint: use a do/while loop for this*

# Hints
1. To display the contents of the output file, you can open it in Atom or another editor
   - You can also type `cat calories.txt` at the *Terminal* window command prompt
1. If your program gets into an infinite loop, type `<Ctrl> c` to stop the program
1. Try different input values for the interval minutes, and make sure the program responds appropriately

# Sample Output
The following shows the user input as well as the contents of the output file.

## Sample Output #1
<pre>
Enter number of minutes for each interval (1-60): <b>7</b>
</pre>
*Note: nothing will be displayed in the Terminal window. However, the file "calories.txt" will contain the following.*
```
   Minutes  Calories
         7      27.3
        14      54.6
        21      81.9
        28     109.2
        35     136.5
        42     163.8
        49     191.1
        56     218.4
```
## Sample #2 Output
<pre>
Enter number of minutes for each interval (1-60): <b>88</b>
Enter number of minutes for each interval (1-60): <b>0</b>
Enter number of minutes for each interval (1-60): <b>3</b>
</pre>
*Note: nothing will be displayed in the Terminal window. However, the file "calories.txt" will contain the following.*
```
   Minutes  Calories
         3      11.7
         6      23.4
         9      35.1
        12      46.8
        15      58.5
        18      70.2
        21      81.9
        24      93.6
        27     105.3
        30     117.0
        33     128.7
        36     140.4
        39     152.1
        42     163.8
        45     175.5
        48     187.2
        51     198.9
        54     210.6
        57     222.3
        60     234.0
```

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used constants instead of hardcoded integer literals, including in the* `std::cout` *statements*
     - *Be sure you used all UPPERCASE for the name of your constant*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure the results are written to a file, not the Terminal window*
     - *Be sure to include one digit past the decimal*
1. **Error check**
   - Does your program continue prompting the user for a value that is in range when the user enters an invalid value?
1. **Test**
   - Did you test the boundary conditions?
     - *Be sure to check values that are on the boundary of your conditional expressions* (e.g. `-1` `0` `1` `59` `60` `61`)?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
