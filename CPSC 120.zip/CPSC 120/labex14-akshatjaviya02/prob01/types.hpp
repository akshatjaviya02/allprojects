#ifndef __TYPES_H__
#define __TYPES_H__

//-----------
// Constants
//-----------

// TODO
// add a constant for the maximum grid size, set to 3
const int MAX_GRID_SIZE = 3;

// files containing grids for testing the program
const std::string LO_SHU_FILE = "lo_shu_square.txt";
const std::string OTHER_FILE = "lo_shu_not.txt";
const std::string MISSING_FILE = "lo_shu_missing.txt";
const std::string CUTOFF_FILE = "lo_shu_cutoff.txt";

//---------------------
// Function prototypes
//---------------------

// This function reads in a two dimensional array from a file and checks
// whether it is a lo shu magic square
// Parameters:
//   1. a two-dimensional array for the lo shu game board
//   2. grid size (i.e., number of elements in one dimension of the array)
//   3. name of the input file that contains the lo shu grid
// Return value:
//   None
void checkMagicSquare(int grid[][MAX_GRID_SIZE], int grid_size, std::string file_name);

// This function checks the two dimensional array to see if all rows,
// columns, and diagonals add up to the same value
// Parameters:
//   1. a two-dimensional array for the lo shu game board
//   2. grid size (i.e., number of elements in one dimension of the array)
// Return value:
//   zero if the grid is not a magic square, or the sum that each of the
//   rows, columns and diagonals add up to if it is
int magicSquareValue(int grid[][MAX_GRID_SIZE], int grid_size);

#endif
