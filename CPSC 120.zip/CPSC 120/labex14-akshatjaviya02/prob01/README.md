# Lo Shu Magic Square
In this program, you will be using C++ programming constructs, such as functions and 2-dimensional arrays.

## main.cpp
This program checks a 2-dimensional array to see if it is a Lo Shu Magic Square.

A Lo Shu Magic Square is a 3x3 grid where the sum of each row, each column, and each diagonal adds up to the same value.

Skeleton code has been provided. Please fill in the remaining code according to the descriptions provided in the "TODO" comments.

## types.hpp
1. Define a constant for the maximum grid size, set to 3

# Input Validation
1. Make sure the input file exists and contains enough values to fill up the 2-dimensional array

# Hints
1. Use a nested loop to read from the file, and be sure to handle the error condition if you get to the end of the file before you have filled the array
1. To add the check for column, you could use the check for row as a model, but make sure you update it to be adding column values, not row values.
1. Be sure to include the file `types.hpp` with the preprocessor directives (`#include` files) so that the compiler includes the program constants and function prototypes.

# Sample Output
```
The grid in file "lo_shu_square.txt" is a Lo Shu Magic Square. Its sums are 15.
The grid in file "lo_shu_not.txt" is not a Lo Shu Magic Square.
Error opening file "lo_shu_missing.txt"
File "lo_shu_cutoff.txt" does not contain enough values for the Lo Shu grid.
```

# Grading Checklist
1. **TODO**
   - Did you complete every TODO section of the code?
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used constants instead of a hardcoded literals in your expressions and calculations*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
