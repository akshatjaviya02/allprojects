// Lo Shu Magic Square
// The Lo Shu Magic Square is a grid with three rows and three columns
// where every cell contains a value 1 through 9, and the sum of any
// given row, column, or diagonal add up to the same number.

#include <iostream>
#include <fstream>
#include "types.hpp"

int main()
{
  int lo_shu_grid[MAX_GRID_SIZE][MAX_GRID_SIZE];


  // call to check whether the test grids are magic squares
  checkMagicSquare(lo_shu_grid, MAX_GRID_SIZE, LO_SHU_FILE);
  checkMagicSquare(lo_shu_grid, MAX_GRID_SIZE, OTHER_FILE);
  checkMagicSquare(lo_shu_grid, MAX_GRID_SIZE, MISSING_FILE);
  checkMagicSquare(lo_shu_grid, MAX_GRID_SIZE, CUTOFF_FILE);

  return 0;
}

void checkMagicSquare(int grid[][MAX_GRID_SIZE], int grid_size, std::string file_name)
{
  // open the file containing the lo shu grid
  std::ifstream infile;
  infile.open(file_name);
  bool error_size = false;

  if (!infile)
  {
    std::cout << "Error opening file \"" << file_name << "\"\n";
  }
  else
  {
    // TODO
    // read the grid from the file into the 2 dimensional array
    // check to be sure the file contains enough values to fill the array
    // and if it does not, then set the error_size boolean flag to true
    for (int row = 0; row < MAX_GRID_SIZE; row++)
    {
      for (int columns = 0; columns < MAX_GRID_SIZE; columns++)
      {
        if(!(infile >> grid[row][columns]))
        {
          error_size = true;
        }
      }
    }

    // output message to the user if file does not contains a valid grid
    if (error_size)
    {
      std::cout << "File \"" << file_name
        << "\" does not contain enough values for the Lo Shu grid.\n";
    }
    else
    {
      // TODO
      // call the function to get the magic square value

      int value = magicSquareValue(grid, grid_size);
      // let the user know whether the grid is a lo shu magic square
      // and if so then print the grid's value (the number that each
      // row, column and diagonal adds up to)
      std::cout << "The grid in file \"" << file_name << "\"";
      if (value == 0)
      {
        std::cout << " is not a Lo Shu Magic Square.\n";
      }
      else
      {
        std::cout << " is a Lo Shu Magic Square. Its sums are " << value << ".\n";
      }
    }
    infile.close();
  }
}

int magicSquareValue(int grid[][MAX_GRID_SIZE], int grid_size)
{
  int sum = 0, grid_value = 0;
  bool match;

  // initialize the grid value to the sum of the upper-left to
  // lower-right diagonal (00 11 22)
  for (int i = 0; i < grid_size; i++)
  {
    grid_value += grid[i][grid_size - 1 - i];
  }

  // check the other diagonal lower-left to upper-right (02 11 20)
  for (int i = 0; i < grid_size; i++)
  {
    sum += grid[i][i];
  }
  match = (sum == grid_value);

  // if the sums of the diagonals match, then check all rows
  for (int r = 0; r < grid_size && match; r++)
  {
    sum = 0;
    for (int c = 0; c < grid_size; c++)
    {
      sum += grid[r][c];
    }
    match = (sum == grid_value);
  }

  // TODO
  // if the sums all still match, then check the sums for each column
  // hint: check out how this was done for all rows above
  for (int c = 0; c < grid_size && match; c++)
  {
    sum = 0;
    for (int r = 0; r < grid_size; r++)
    {
      sum += grid[r][c];
    }
    match = (sum == grid_value);
  }

  // if all sums match, return that value, otherwise return zero
  return (match ? grid_value : 0);
}
