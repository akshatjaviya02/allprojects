// Walk Array
// This program walks an array "sidewalk", moving either left or right, depending
// on the flip of a coin: heads = move right, and tails = move left. The program
// asks the user how large the array is, and outputs the number of moves it took
// to get to one side of the array.

#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include "types.hpp"
int main()
{
  // get number of elements in the array from the user
  int num_items = getUserInput(MIN_ARRAY_SIZE, MAX_ARRAY_SIZE);

  int sidewalk[num_items];

  // TODO
  // initialize all values in the array to 0
  // note that variable length arrays cannot be initialized using an
  // initialization list
  for (int x = 0; x < num_items; x++)
  {
    sidewalk[x] = 0;
  }

  // TODO
  // call the walkSidewalk function, and output the results to the user
  // informing of how many moves it took to get to the end of the sidewalk
  int moves = walkSidewalk(sidewalk, num_items);
  std::cout << "It took " << moves << " move" << (moves == 1 ? "" : "s") << " to get get to the end of the sidewalk.\n";

  // TODO
  // call the saveSidewalk to print the final counts stored in the array

  saveSidewalk(sidewalk, num_items);

  return 0;
}

int getUserInput(int min, int max)
{
  int num;
  bool valid = false;
  std::string temp;

  // get a valid integer from the user
  do
  {
    std::cout << "Enter the length of the sidewalk: ";
    getline(std::cin, temp);

    // this converts the user input into a string stream
    std::stringstream ss(temp);

    // verify that the user input is a positive integer
    // note that if this is the case then "ss >> num" will successfully read
    // an integer, and "ss >> temp" will not successfully read a string
    // note: the "ss >> temp" call is rewriting to the temp string which is
    // fine since we don't need its value any longer
    if (ss >> num && !(ss >> temp) && num >= min && num <= max)
    {
      valid = true;
    }
    else
    {
      std::cin.clear(); // just in case an error occurs with cin (eof, etc)
      std::cout << "Value must be between " << min << " and " << max << ".\n";
    }
  } while (!valid);

  return num;
}

int walkSidewalk(int sidewalk[], int num_items)
{
  // game ends when we get to one end of the sidewalk
  bool game_over = false;
  int num_moves = 0;

  // TODO
  // set the seed for the random number generator

  int seed = time(0);
  srand(seed);
  int number = rand() % (1 + 1);

  // TODO
  // initialize current location on the sidewalk to the mid-point of the array
  // and increment the value of the element at that location of the array
  int curr_loc;
  curr_loc = (num_items / 2);
  sidewalk[curr_loc]++;

  // keep walking the sidewalk till one end is hit
  while (!game_over)
  {
    // flip a coin, heads (1) = move right, tails (0) = move left
    bool walk_dir = rand() % 2;

    curr_loc += (walk_dir == 1) ? 1 : -1;

    // increment number of times we've hit this sidewalk location
    sidewalk[curr_loc]++;
    num_moves++;

    // check whether we've hit one end or the other of the array
    if (curr_loc == 0 || curr_loc == (num_items - 1))
    {
      game_over = true;
    }
  }

  return num_moves;
}

// TODO
// add the function definition for "saveSidewalk" according to its function
// description found in types.hpp
void saveSidewalk(int sidewalk[], int num_items)
{
  std::ofstream out_file;
  out_file.open(RESULTS_FILE);
  if (out_file)
  {
    for(int x = 0; x < num_items; x++)
    {
      out_file << sidewalk[x] << " ";
    }
    out_file.close();
  }
}
