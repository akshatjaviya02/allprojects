#ifndef __TYPES_H__
#define __TYPES_H__

//-----------
// Constants
//-----------

// TODO
// add constants for the minimum and maximum array lengths allowed
const int MIN_ARRAY_SIZE = 3;
const int MAX_ARRAY_SIZE = 100;

// file to write the final array results to
const std::string RESULTS_FILE = "walk_sidewalk.txt";

//---------------------
// Function prototypes
//---------------------

// This function requests input from the user, and validates that the user
// input falls between min and max, inclusive. If it does not, then this
// function outputs an error message letting the user know what the valid
// range is, and asks again for input.
// Parameters:
//   1. minimum value allowed for the array length
//   2. maximum value allowed for the array length
// Return value:
//   value input by the user
int getUserInput(int min, int max);

// This function "flips a coin"
// If the coin comes up heads (1) then walk one step to the right.
// If it comes up tails (0) then walk one step to the left.
// The play begins at the mid-point of the array, and moves either left or
// right from there, one move at a time, till the end of the array is hit.
// Every time a cell in the array is stepped into (walked) then the value
// in that cell is incremented by 1.
// Parameters:
//   1. an array of integers representing the "sidewalk"
//   2. array length (number of elements in the array)
// Return value:
//   total number of moves it took to get to one side of the "sidewalk"
int walkSidewalk(int sidewalk[], int num_items);

// This function prints the contents of the array to a file, defined by a
// constant.
// Parameters:
//   1. an array of integers representing the "sidewalk"
//   2. array length (number of elements in the array)
// Return value:
//   None
void saveSidewalk(int sidewalk[], int num_items);

#endif
