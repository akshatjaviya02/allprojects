# Walk Array
In this program, you will be using C++ programming constructs, such as functions and arrays.

## main.cpp
Write a program that walks an array (the sidewalk), starting at the mid-point of the array, and moving either left or right based on the flip of a coin: heads (1) = move right, and tails (0) = move left. The "coin" should be implemented using a random number generator along with the modulus operator to ensure you get only 2 values.

The program should ask the user how large the sidewalk is, and create the array based on the user's input. After "walking the array" the program will output a message to the user telling how many moves it took to get to one side of the array. In addition, the program will output the final contents of the array to a file.

Skeleton code has been provided in `main.cpp`. Please fill in the "TODO" statements, and in addition, find and fix any bugs in the code.

## types.hpp
1. Define 2 constants to represent the minimum and maximum number of elements allowed in the array, set to 3 and 100 respectively

## Input Validation
1. The program should check to be sure the user input is valid according to the min/max constants
1. Make sure your program protects against writing past the end of the array

# Sample Output
Please run your program multiple times to see that the random number changes each time you run the program. You do not need to recompile between runs.

***Note: your program output will not necessarily match the samples below due to the randomness of the "coin flips"***

Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Enter the length of the sidewalk: <b>2</b>
Value must be between 3 and 100.
Enter the length of the sidewalk: <b>101</b>
Invalid. Value must be between 3 and 100.
Enter the length of the sidewalk: <b>3</b>
It took 1 move to get to the end of the sidewalk.
</pre>

After you have run your program, the file *walk_sidewalk.txt* should now contain the contents of your "sidewalk"

You can view the file contents in Atom or by using the `cat` command in a Terminal window.
```
cat walk_sidewalk.txt
```
```
1 1 0
```
***Note: your file output will not necessarily match the sample due to the randomness of the "coin flips"***

## Sample Output #2
<pre>
Enter the length of the sidewalk: <b>30</b>
It took 211 moves to get to the end of the sidewalk.
</pre>

```
cat walk_sidewalk.txt
```
```
1 1 1 1 2 4 4 4 7 8 10 18 18 15 21 25 21 14 12 14 8 2 1 0 0 0 0 0 0 0
```

# Grading Checklist
1. **TODO**
   - Did you complete every TODO section of the code?
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used constants instead of a hardcoded literals in your expressions and calculations*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce similar results as the Sample Output?
     - *Be sure and check whether your program properly chose whether to print "move" versus "moves" when more than one move was made on the sidewalk*
1. **Error check**
   - Does your program print an error and ask again if the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
