# Array Statistics
In this program, you will be using C++ programming constructs, such as functions and arrays.

## main.cpp
Write a program that asks the user to enter a number between 1 and 100. Your program will then output a message indicating how many numbers in a pre-defined array of numbers are larger than the number entered by the user.

If the user enters a number that is out of range, the program outputs an error message and prompts the user to try again.

The program has partially been filled in for you. You need to complete the code in `main()` and write the function.

## countLarger()
Create a function called `countLarger()` that contains 3 parameters
1. An array of integers
1. An integer indicating how many items are in the array
1. An integer that will be compared against all integers in the array to find how many are larger than this value

This function returns an integer representing how many integers in the array are larger than the third parameter of the function.

## Constants
Constants have been defined for you at the top of the `main()` function. You do not need to move these, but please be sure and use them in the body of `main()` rather than integer literals.

## Input Validation
1. You can assume the user will always input an integer value
1. If the integer input is out of range, output an error message and prompt the user to try again

# Hints
1. You can use the function prototype to create a the function header
   - *Don't forget to add parameter names for the function header*
1. Notice when only one integer is larger, the output prints "is" instead of "are"
   - *You could use the conditional operator as shown in prob02 where an 's' is being added - use a similar model for this problem*

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Please enter an integer between 1 and 100: <b>80</b>

4 of the integers in my array are larger than 80.
</pre>

## Sample Output #2
<pre>
Please enter an integer between 1 and 100: <b>94</b>

1 of the integers in my array is larger than 94.
</pre>

## Sample Output #3
<pre>
Please enter an integer between 1 and 100: <b>111</b>
111 is not between 1 and 100. Please try again: <b>73</b>

6 of the integers in my array are larger than 73.
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used a constant instead of a hardcoded literals in your expressions and calculations*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure and check whether your program printed "are" versus "is" when outputting the number of values greater than the input*
1. **Error check**
   - Does your program print an error and ask again if the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
