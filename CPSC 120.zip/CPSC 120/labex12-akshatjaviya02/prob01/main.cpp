// Array Statistics
// This program determines how many numbers in an integer array are larger
// than a user-entered value.

#include <iostream>

// This function returns the number of values in the array that
// are larger than the value passed as the third parameter.
int countLarger(int[], int, int);

int main()
{
  // constants
  const int SIZE = 30;
  const int MIN  = 1;
  const int MAX  = 100;
  int integer, num;
  // array of integers to be used in the comparison
  int array[SIZE] =
    {  2, 33, 85,  7, 11, 21, 17,  1, 23, 29, 31, 37, 55, 44, 22,
      43, 47, 95, 59, 61, 33, 71, 73, 79, 88, 89,  7, 43, 77, 60 };

  std::cout << "Please enter an integer between " << MIN << " and " << MAX << ": ";
  std::cin >> integer;
  // TODO: fill in the rest of the body of main according to the README instructions
  while (integer > MAX)
  {
    std::cout << integer << " is not between " << MIN << " and " << MAX << ". Please try again: ";
    std::cin >> integer;
  }
  num = countLarger(array, SIZE, integer);
  std::cout << num << " of the integers in my array " << (num == 1 ? "is" : "are") << " larger than " << integer << '.' << std::endl;

  return 0;
}

// TODO: create function definition for countLarger
int countLarger(int array [], int size, int i)
{
  int count = 0;
  for (int r = 0; r < size; r++)
  {
    if (array[r] > i)
    {
      count++;
    }
  }
  return count;
}
