// Baseball Champions
// This program reads in the names of Major League baseball teams that have
// won the World Series at least once (Teams.txt). It also reads in a list
// showing the team that won each year from 1950-2014 (WorldSeriesWinners.txt).
// The program then allows the user to select a team from the list of teams
// it displays and reports to the user how many times that team has won.

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "types.hpp"

int main()
{
  std::ifstream input_file;

  int num_teams = 0;
  int num_games = 0;
  int user_choice = 0;
  int times_won = 0;

  std::string teams[MAX_TEAMS];
  std::string winners[MAX_TEAMS];
  std::string team_name;

  // get the data from the file of teams and store it in an array
  input_file.open(TEAMS_FILE);

  if (input_file)
  {
    num_teams = getInput(teams, input_file);
    input_file.close();
  }
  else
  {
    std::cout << "Error opening file " << TEAMS_FILE << std::endl;
  }

  // get the data from the file of winners and store it in an array
  input_file.open(WINNERS_FILE);

  if (input_file)
  {
    num_games = getInput(winners, input_file);
    input_file.close();
  }
  else
  {
    std::cout << "Error opening file " << WINNERS_FILE << std::endl;
  }

  // display the teams to choose from
  std::cout << "Major League Baseball Teams:\n\n";

  for (int i = 0; i < num_teams; i++)
  {
    std::cout << std::setw(2) << i + 1 << ". " << teams[i] << std::endl;
  }

  std::cout << "\nEnter the number of a team to learn how many"
    << "\nWorld Series they have won between 1950 and 2014: ";
  user_choice = getChoice(1, num_teams);

  // get the team located at the array position
  team_name = teams[user_choice - 1];

  // Get and report the results
  times_won = countOccurrences(winners, num_games, team_name);

  std::cout << "\nThe " << team_name << " have won the World Series "
    << times_won << " time" << (times_won == 1 ? "" : "s") << ". \n";

  return 0;
}
int getInput(std::string ary[], std::ifstream& file)
{
  int total = 0;
  while (total < MAX_TEAMS && getline(file, ary[total]))
  {
    total++;
  }
  return total;
}
int getChoice(int min, int max)
{

  int user_input;
  int choice;
  do{
    std::cin >> user_input;
    if (user_input >= min && user_input <= max)
    {
      choice = user_input;

    }
    else
    {
      std::cout << '\n';
      std::cout << "Valid values are " << min << '-' << max << ". Please re-enter your choice: ";
    }
  }while (user_input < min || user_input > max);
  return choice;
}
int countOccurrences(std::string ary[], int size, std::string name)
{
  int occurance = 0;
  for (int i = 0; i < size; i++)
  {
    if (name == ary[i])
    {
      occurance++;
    }
  }
  return occurance;
}
