#include <string>

//-----------
// Constants
//-----------

const int MAX_TEAMS = 100;

const std::string TEAMS_FILE   = "Teams.txt";
const std::string WINNERS_FILE = "WorldSeriesWinners.txt";

//---------------------
// Function prototypes
//---------------------

// This function reads strings from the file stream and stores them in the
// array of strings, up to the maximum size allowed for the array. This
// function also returns the number of records read and stored.

// Parameters:
//  1. an array of strings read from the input file
//  2. an input file stream to the file containing strings
// Return value:
//  1. number of items that were stored in the array

int getInput(std::string ary[], std::ifstream& file);


// This function gets user input, validates that it falls between the
// min and max values received as parameters, and returns the user input
// value to the caller.

// Parameters:
//  1. minimum value allowed
//  2. maximum value allowed
// Return value:
//  1. user input value

int getChoice(int min, int max);


// This function counts the number of times the string occurs in the array

// Parameters:
//  1. an array of strings
//  2. the size of the array
//  3. a string that will be compared against every value in the array to
//     determine how many times that string occurs in the array
// Return value:
//  1. Number of times the string occurs in the array

int countOccurrences(std::string ary[], int size, std::string name);
