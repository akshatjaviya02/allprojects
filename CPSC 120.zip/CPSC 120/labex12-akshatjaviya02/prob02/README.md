# Baseball Champions
In this program, you will be using C++ programming constructs, such as functions and arrays.

This program will display the names of major league baseball teams and asks the user to enter the number of a team. The program will count how many times that team has won the World Series and output that to the user.

The program gets the list of teams from the file Teams.txt and the list of World Series champions from 1950-2014 from the file WorldSeriesWinners.txt. These file names should be defined as constants in your program.

## main.cpp
The function `main()` has been filled in for you.

After the function `main()` please add 3 new functions. Please see the function prototypes and descriptions for each in the `types.hpp` file. You need to create the functions at the end of the file `main.cpp` and fill in the bodies of these functions.

## types.hpp
You do not need to modify this file. All constants and function prototypes have already been defined for you in this file.

## Constants
Constants have been defined for you in `types.hpp`. These constants are already being used in the body of `main()`.

**You should not use these in the functions that you create. The functions should use their parameters rather than constants.** These constants are already being passed to the functions where appropriate.

## Input Validation
1. You can assume the user will always input valid data types
1. Be sure your program checks that it is not writing past the end of the array
   - *There is already a constant defined for the maximum number of elements in the array*

# Hints
1. Be sure to include the file `types.hpp` with the `#include` files in `main.cpp`
1. To get each of the functions started, you could copy the function prototypes from `types.hpp` to create function headers, and place these at the end of the `main.cpp` file, after the `main()` function

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Major League Baseball Teams

 1. Anaheim Angels
 2. Arizona Diamondbacks
 3. Atlanta Braves
 4. Baltimore Orioles
 5. Boston Americans
 6. Boston Braves
 7. Boston Red Sox
 8. Brooklyn Dodgers
 9. Chicago Cubs
10. Chicago White Sox
11. Cincinnati Reds
12. Cleveland Indians
13. Detroit Tigers
14. Florida Marlins
15. Kansas City Royals
16. Los Angeles Dodgers
17. Milwaukee Braves
18. Minnesota Twins
19. New York Giants
20. New York Mets
21. New York Yankees
22. Oakland Athletics
23. Philadelphia Athletics
24. Philadelphia Phillies
25. Pittsburgh Pirates
26. San Francisco Giants
27. St. Louis Cardinals
28. Toronto Blue Jays
29. Washington Senators

Enter the number of a team to learn how many
World Series they have won between 1950 and 2014: <b>21</b>

The New York Yankees have won the World Series 15 times.
</pre>

## Sample Output #2
<pre>
Major League Baseball Teams

 1. Anaheim Angels
 2. Arizona Diamondbacks
 3. Atlanta Braves
 4. Baltimore Orioles
 5. Boston Americans
 6. Boston Braves
 7. Boston Red Sox
 8. Brooklyn Dodgers
 9. Chicago Cubs
10. Chicago White Sox
11. Cincinnati Reds
12. Cleveland Indians
13. Detroit Tigers
14. Florida Marlins
15. Kansas City Royals
16. Los Angeles Dodgers
17. Milwaukee Braves
18. Minnesota Twins
19. New York Giants
20. New York Mets
21. New York Yankees
22. Oakland Athletics
23. Philadelphia Athletics
24. Philadelphia Phillies
25. Pittsburgh Pirates
26. San Francisco Giants
27. St. Louis Cardinals
28. Toronto Blue Jays
29. Washington Senators

Enter the number of a team to learn how many
World Series they have won between 1950 and 2014: <b>0</b>

Valid values are 1-29. Please re-enter your team choice: <b>1</b>

The Anaheim Angels have won the World Series 1 time.
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used a constant instead of a hardcoded literals in your expressions and calculations*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
1. **Error check**
   - Does your program print an error and ask again if the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
