// This program calculates and displays business trip expenses.
#include <iostream>
#include <string>

int main()

{
  std::string location;
  double trip_days, hotel_cost, meal_cost, total_hotel, total_bill;

  //business trip
  std::cout << "Welcome to the Bussiness Trip Tracker!" << std::endl;

  // Bussiness place
  std::cout << "what is the business trip location? ";
  std::cin >> location;

  //days of the Bussiness trip
  std::cout << "How many days will the trip take? ";
  std::cin >> trip_days;

  //hotel's expenses
  std::cout << "What is the hotel expense per day? ";
  std::cin >> hotel_cost;

  //total expenses for all meal
  std::cout << "What is the total expense for all the meals? ";
  std::cin >> meal_cost;

  //calculate total expenses
  total_hotel = trip_days * hotel_cost;
  total_bill = total_hotel + meal_cost;

  //displays the calculations
  std::cout << "Location\tDays\tHotel\tMeal\tTotal\n";
  std::cout << location << "\t" << trip_days << "\t" << total_hotel << "\t" << meal_cost << "\t" << total_bill << "\t" << std::endl;

return 0;
}
