#  Project Milestone 1 Objectives
1. Learn to use variables
1. Output results in different forms
1. Compile and run program

# Business Trip Expenses
In this program, you will be learning to use the basic C++ programming constructs, such as cout, cin, and string variables.

## main.cpp
Write a program that asks the user for the following information:
1. Business trip location *(Note: location must be a single word with no spaces for this milestone)*
1. Trip number of days
1. Hotel expenses per day
1. Meal expense total

The program then calculates the total hotel expense based on the daily rate and number of days. It also calculates the total for the trip based on total hotel expense and total meal expense. And lastly, it outputs all information for the trip in table format. See Sample Output below for format.

# Hints
1. Feel free to use labex02 prob02 as an example for cin/cout
1. Try using the `\t` <tab> escape character to line the results up

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Welcome to the Business Trip Tracker!

What is the business trip location? <b>Sacramento</b>
How many days will the trip take? <b>3</b>
What is the hotel expense per day? $<b>207.11</b>
What is the total expense for all meals? $<b>186.59</b>

Location        Days    Hotel   Meal    Total
Sacramento      3       621.33  186.59  807.92
</pre>

## Sample Output #2
<pre>
Welcome to the Business Trip Tracker!

What is the business trip location? <b>Philadelphia</b>
How many days will the trip take? <b>5</b>
What is the hotel expense per day? $<b>179.89</b>
What is the total expense for all meals? $<b>310.48</b>

Location        Days    Hotel   Meal    Total
Philadelphia    5       899.45  310.48  1209.93
</pre>

# Completion Checklist
1. Did you comment your code where appropriate?
1. Did you use variable names appropriate for the purpose/usage of the variable?
1. Does your program compile? (i.e. no errors when you run clang++)
1. Does your program produce the desired results?
1. Does the GitHub Website show your latest code updates?

# Code Evaluation
1. Get a copy of the lab exercise from GitHub, and change directory into prob01, and open main.cpp for editing in atom. See labex00 for details if needed.

   ```
   git clone URL
   cd project01-tuffy
   atom main.cpp
   ```

1. Compile and run your program.

   ```
   clang++ -std=c++17 main.cpp -o main
   ./main
   ```

# Submission
1. To upload your code to GitHub you will run the following 3 commands.

    ```
    git add .
    git commit -m "Description of your code changes"
    git push
    ```

1. If it asks you to configure global variables for an email and name, just copy the commands it provides but replace the dummy text with your email and GitHub username. When you're done, make sure you `git commit` your repository again.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```

1. Once you have pushed your changes to GitHub, double check that your local repository is clean. The following should report: **Your branch is up to date with 'origin/master'**

    ```
    git status
    ```

1. Go back to the GitHub Website and refresh the page to see that your changes are there.
