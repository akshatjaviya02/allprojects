// This program calculates the number of soccer teams a
// youth league can create from the number of available
// players. It performs input validation using while loops.

#include <iostream>

int main()
{
  // initialize var to indicate no user input
  int players_available, players, total_team, leftover_players;
  int const MAX = 15;
  int const MIN = 9;

  std::cout << "how many players do you wish per team? ";
  std::cin >> players;

  while (players < 9 || players > 15)
  {
    std::cout << "Team size should be " << MIN << " to " << MAX << " players.\n";
    std::cout << "how many players do you wish per team? ";
    std::cin >> players;
  }

  std::cout << "How many players are available? ";
  std::cin >> players_available;

  // get user input for total number of players available
  while (players_available < 0)
  {
    std::cout << "\nPlayers available cannot be negative.\n";

    std::cout << "How many players are available? ";
    std::cin >> players_available;
  }
  total_team = players_available / players;
  leftover_players = players_available % players;

  std::cout << " There will be " << total_team <<  " team" << (total_team == 1 ? "" : "s") << " with " << leftover_players
    << " player" << (leftover_players == 1 ? "" : "s") << " left over.\n";
    
  return 0;
}
