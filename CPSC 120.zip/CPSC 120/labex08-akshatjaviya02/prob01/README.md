# Soccer Teams
In this program, you will be using C++ programming constructs, such as the while loop and relational operators.

## main.cpp
Write a program that asks the user to enter the number of players per soccer team, as well as the number of players available to be placed on a team. The program will then calculate the number of soccer teams that can be formed, and the number of players left over after those teams have been formed.

*Note: the loop to get the number of players available has been provided for you. Please fill in the code for the rest of the program.*

## Constants
Define the following constants in your program:
1. The minimum number of players per team, set to 9
1. The maximum number of players per team, set to 15

## Input Validation
Your program should validate the user input in the following ways:
1. The number of players per team must be between 9 and 15 *(use constants in your program)*
1. The number of players available can be zero or any positive integer
1. If the user enters an invalid value, use *while* loops to continue asking for a value until the user enters a valid value, as shown in the Sample Output below

# Hints
1. An easy way to get the output to appropriately display "players" versus "player" is to use the conditional operator *(see Week 7 lecture)* in the `std::cout` statement
   - The same logic can be used for "teams" versus "team"
   - Check *prob02* to see how this was done in that program
1. Try different input values and make sure the program responds appropriately
1. If your program gets into an infinite loop, type `<Ctrl> C` to stop the program

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
How many players do you wish per team? <b>9</b>
How many players are available? <b>37</b>

There will be 4 teams with 1 player left over.
</pre>

## Sample Output #2
<pre>
How many players do you wish per team? <b>77</b>

Team size should be 9 to 15 players.
How many players do you wish per team? <b>7</b>

Team size should be 9 to 15 players.
How many players do you wish per team? <b>11</b>
How many players are available? <b>11</b>

There will be 1 team with 0 players left over.
</pre>

## Sample Output #3
<pre>
How many players do you wish per team? <b>15</b>
How many players are available? <b>-15</b>

Players available cannot be negative.
How many players are available? <b>-3</b>

Players available cannot be negative.
How many players are available? <b>0</b>

There will be 0 teams with 0 players left over.
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used constants instead of hardcoded integer literals, including in the* `std::cout` *statements*
     - *Be sure you used all UPPERCASE for the name of your constant*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
1. **Error check**
   - Does your program continue prompting the user for a value that is in range when the user enters an invalid value?
1. **Test**
   - Did you test the boundary conditions?
     - *Be sure to check values that are on the boundary of your conditional expressions* (e.g. `-1` `0` `9` `15`)?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
