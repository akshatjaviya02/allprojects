// This program uses a sentinel controlled loop to allow the
// user to enter a series of numbers, and then calculates and
// displays statistics about the numbers that were entered.
#include <iostream>
#include <iomanip>

int main ()
{
  const int SENTITAL = -99;
  int integer, count, small, large, sum;
  double average;
  count = 0;
  sum = 0;

  std::cout << "Enter an integer (or -99 to quit): ";
  std::cin >> integer;

  if (integer == SENTITAL)
  {
    std::cout << "\n You did not enter any numbers.\n";
  }
  else
  {
    small = integer;
    large = integer;

    while (integer != SENTITAL)
    {
      ++count;
      //calculate sum
      sum += integer;
      if (integer > large)
      {
        large = integer;
      }
      else if (integer < small)
      {
        small = integer;
      }
        // enter another number
        std::cout << "Enter another integer (or -99 to quit): ";
        std::cin >> integer;

      }
    // calculate average
    average = (float) sum / count;

    //display
    std::cout << "You entered " << count << " number" << (count == 1 ? "" : "s") << '\n';
    std::cout << "Largest: " << large << '\n';
    std::cout << "Smallest: " << small << '\n';
    std::cout << "Sum: " << sum << '\n';
    std::cout << "Average: " << std::setprecision(3) << std::fixed << average << '\n';
  }
  return 0;
}
