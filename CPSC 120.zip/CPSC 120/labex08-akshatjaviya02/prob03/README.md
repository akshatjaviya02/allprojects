# The Greatest and Least of These
In this program, you will be using C++ programming constructs, such as the while loop and relational operators.

## main.cpp
Write a program that asks the user to enter a series of numbers, ending with the entry of a sentinel value of -99. *Use a constant to represent this value.*

The program will then calculate and display statistics on the numbers that were entered. Be sure to print exactly 3 digits past the decimal for the average of the numbers.

## Constants
Define the following constant in your program:
1. The sentinel value, set to -99

## Input Validation
1. Include a check of the divisor to ensure your program doesn't try to divide by zero
1. Your program can assume the user always enters an integer value *(no input validation needed to check for an integer input value)*

# Hints
1. If your program gets into an infinite loop, type `<Ctrl> C` to stop the program
1. The body of the *while* loop needs to keep track of the running totals for the statistics *(these should be recalculated each time through the loop)*
   - How many numbers have been entered
   - The running sum of the numbers
   - The largest number received so far
   - The smallest number received so far
1. Be sure the sentinel value does not get included in the statistics

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Enter an integer (or -99 to quit): <b>43</b>
Enter another integer (or -99 to quit): <b>-22</b>
Enter another integer (or -99 to quit): <b>88</b>
Enter another integer (or -99 to quit): <b>71</b>
Enter another integer (or -99 to quit): <b>-20</b>
Enter another integer (or -99 to quit): <b>0</b>
Enter another integer (or -99 to quit): <b>67</b>
Enter another integer (or -99 to quit): <b>88</b>
Enter another integer (or -99 to quit): <b>-99</b>

You entered 8 numbers.
Largest:  88
Smallest: -22
Sum:      315
Average:  39.375
</pre>

## Sample Output #2
<pre>
Enter an integer (or -99 to quit): <b>-99</b>

You did not enter any numbers.
</pre>

## Sample Output #3
<pre>
Enter an integer (or -99 to quit): <b>3</b>
Enter another integer (or -99 to quit): <b>-99</b>

You entered 1 number.
Largest:  3
Smallest: 3
Sum:      3
Average:  3.000
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use constants in your code?
     - *Be sure you used constants instead of hardcoded integer literals, including in the* `std::cout` *statements*
     - *Be sure you used all UPPERCASE for the name of your constant*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure your program prints the 's' on the word "numbers" only when the user has entered more than one number*
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
