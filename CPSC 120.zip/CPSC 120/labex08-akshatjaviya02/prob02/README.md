# Find the Errors
In this program, you will debug a program that contains the following:
1. Compile time bugs
1. Run time bugs (these compile but produce error output values)

## main.cpp
1. Try compiling the program to find out what errors the compiler finds
1. Find and fix the compile time bug(s)
1. Once the program compiles, try running it to see whether it outputs the expected results
1. Find and fix any bug(s) in the program that are causing incorrect results to be output

# Hints
1. If your program keeps choosing the same "random" value each time you run it, double check that you are setting the seed properly
1. If your program gets into an infinite loop, type `<Ctrl> C` to stop the program
1. The compiler outputs the line number and column of the error if a compile time error is encountered
   e.g., `main.cpp:15:37` indicates an error in your code on line 15, column 37

# Sample Output
Please run your program multiple times to see that the random number changes each time you run the program. You do not need to recompile between runs.

*Note: your program output will not necessarily match the samples below due to the randomness of the "secret number"*

Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
I am thinking of a number between 1 and 100.
Can you guess what it is?

Enter your guess: <b>50</b>
50 is too high. Try a smaller number: <b>35</b>
35 is too high. Try a smaller number: <b>15</b>
15 is too low.  Try a larger number:  <b>25</b>

Congratulations! My number was 25. You got it in 4 guesses.
</pre>

## Sample Output #2
<pre>
I am thinking of a number between 1 and 100.
Can you guess what it is?

Enter your guess: <b>84</b>

Congratulations! My number was 84. You got it in 1 guess.
</pre>

## Sample Output #3
<pre>
I am thinking of a number between 1 and 100.
Can you guess what it is?

Enter your guess: <b>-1</b>
-1 is not between 1 and 100. Try again: <b>0</b>
0 is not between 1 and 100. Try again: <b>100</b>
100 is too high. Try a smaller number: <b>200</b>
200 is not between 1 and 100. Try again: <b>50</b>
50 is too low. Try a larger number: <b>88</b>
88 is too high. Try a smaller number: <b>77</b>
77 is too high. Try a smaller number: <b>66</b>
66 is too high. Try a smaller number: <b>55</b>

Congratulations! My number was 55. You got it in 9 guesses.
</pre>

# Grading Checklist
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Random**
   - Does your program produce a different "secret number" every time you run it?
1. **Output**
   - Does your program output the proper message for each of the following?
     - *User guess is too low*
     - *User guess is too high*
     - *User guess is out of range*
   - Does your program output the correct number of guesses it took?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
