// Random Number Guessing Game
// This program uses a loop to let the user make guesses until a
// randomly generated integer between 1 and 100 is correctly guessed.

#include <cstdlib>
#include <ctime>
#include <iostream>

int main()
{
  // minimum and maximum range of values for the random number
  const int MIN_NUM = 1;
  const int MAX_NUM = 100;
  int guess;
  int count;

  unsigned seed = time (0);
  srand(seed);
  // get a random number between 1 and MAX
  int number = 1 + rand() % (MAX_NUM - MIN_NUM + 1);

  // explain the game and get the user's first guess
  std::cout << "I am thinking of a number between "
    << MIN_NUM << " and " << MAX_NUM << ".\n";
  std::cout << "Can you guess what it is?\n\n";
  std::cout << "Enter your guess: ";
  std::cin  >> guess;

  ++count;
  // loop to accept additional guesses until the right number is entered

  while (guess != number)
  {
    if ((guess < MIN_NUM) || (guess > MAX_NUM))
    {
      std::cout << guess << " is not between " << MIN_NUM << " and "
        << MAX_NUM << ". Try again: ";

    }
    else if (guess > number)
    {
      std::cout << guess << " is too high. Try a smaller number: ";

    }
    else
    {
      std::cout << guess << " is too low.  Try a larger number:  ";
    }
    std::cin >> guess;
    ++count;
  }

  // the only way the loop is exited is when the user has
  // guessed correctly, so display a congratulatory message
  if (number == guess)
  std::cout << "\nCongratulations! My number was " << number
    << ". You got it in " << count << " guess" << (count == 1 ? "" : "es")
    << ".\n";

  return 0;
}
