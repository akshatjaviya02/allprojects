// This program prompts the user for a date, and lets the user know whether
// the date entered was special if the month times the day equals the two
// digit year.

#include <iostream>

enum Month
{
  JAN = 1,
  FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC
};

int main()
{
  int year, month, day, yr2;
  bool valid = true;

  std::cout << "Enter a 4 digit year: ";
  std::cin >> year;
  std::cout << "Enter the month (1-12): ";
  std::cin >> month;
  std::cout << "Enter the day (1-31): ";
  std::cin >> day;

  // check that the date is valid
  // ** NOTE! ** THE INDENTATION HERE NEEDS TO BE FIXED **
  if (year <= 0 || month <= 0 || day <= 0 || month > DEC || day > 31 || year > 9999 || year < 1000)
  {
    valid = false;
  }
  else if (month == APR || month == JUN || month == SEP || month == NOV)
  {
    if (day > 30)
    {
      valid = false;
    }
  }
  else if (month == FEB)
  {
    if (day > 29)
    {
      valid = false;
    }
    else if (day == 29) // determine whether it's a leap year
    {
      bool leap_year = false;

      // it's a leap year when the year is divisible by 100 as well as 400
      // or when it is not divisible by 100 but is divisible by 4
      if (year % 100 == 0)
      {
        if (year % 400 == 0)
        {
          leap_year = true;
        }
      }
      else
      {
        if (year % 4 == 0)
        {
          leap_year = true;
        }
      }

      // if it is not a leap year then February will not have 29 days
      if (!leap_year)
      {
        valid = false;
      }
    }
  }

  // print the date entered by the user
  std::cout << month << "/" << day << "/" << year;


  if (valid == false)
  {
    std::cout << " is not a valid date.\n";
  }
  else
  {
    // get the 2-digit year
    yr2 = year % 100;

    // let the user know whether the product of the month and day is equal
    // to the 2-digit year
    if (month * day == yr2)
    {
      std::cout << " is a special date because " << month << " * " << day
        << " = " << yr2 << ".\n";
    }
    else
    {
      std::cout << " does not qualify because " << month << " * " << day
        << " != " << yr2 << ".\n";
    }
  }

  return 0;
}
