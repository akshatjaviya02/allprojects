# Find the Errors
In this program, you will debug a program that contains the following errors:
1. Compile time bugs
1. Run time bugs (these compile but produce error output values)
1. Style guide violations

## main.cpp
This program asks the user to enter a date, and then displays whether that date contains special characteristics.

1. Try compiling the program to find out what errors the compiler finds
1. Find and fix the compile time bug(s)
1. Once the program compiles, try running it to see whether it outputs the expected results
1. Find and fix any bug(s) in the program that are causing incorrect results to be output

# Hints
1. The compiler outputs the line number and column of the error if a compile time error is encountered
   e.g., `main.cpp:22:37` indicates an error in your code on line 22, column 37

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Enter a 4 digit year: <b>2008</b>
Enter the month (1-12): <b>2</b>
Enter the day (1-31): <b>4</b>
2/4/2008 is a special date because 2 * 4 = 8.
</pre>

## Sample Output #2
<pre>
Enter a 4 digit year: <b>9999</b>
Enter the month (1-12): <b>12</b>
Enter the day (1-31): <b>31</b>
12/31/9999 does not qualify because 12 * 31 != 99.
</pre>

## Sample Output #3
<pre>
Enter a 4 digit year: <b>19000</b>
Enter the month (1-12): <b>3</b>
Enter the day (1-31): <b>11</b>
3/11/19000 is not a valid date.
</pre>

# Grading Checklist
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `==` `&&` `||`, etc.)
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Sample Output**
   - Does your program produce the same results as the Sample Output?
     - *Check the output carefully to be sure it matches*
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
