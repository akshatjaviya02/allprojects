# Midterm Exam Part 2: Programming

## Timing and General Instructions
You have **1 hour** to complete the programming part of the midterm exam. You are welcome to use your notes, textbook, and lecture slides during the exam.

Direct all your questions to the instructor only. The instructor will not answer questions regarding interpreting syntax errors or debugging code, but will be happy to answer questions to clarify the problem instructions.

## Problems and Points
There are two programming problems that you need to complete.

1. Find bugs and style guide violations (*one third of your programming grade*)
1. Create your own program (*two thirds of your programming grade*)

# Submission
Your answers will be submitted through GitHub. You can push your code as many times as you want before the end of the midterm exam. The instructor will check only the last version that was pushed.

If you are running out of time, it is a good idea to push whatever work you have done. Even if it is not complete or not working, you will still get points for the portion of code that you did complete.

## Good luck!

# GitHub and Unix commands
```
git clone your_repository_url
```

```
cd midterm-your_username
cd prob01
```

```
clang++ -std=c++17 main.cpp -o main
./main
```

```
git add main.cpp
git commit -m "short description of code changes being uploaded"
git push
```
