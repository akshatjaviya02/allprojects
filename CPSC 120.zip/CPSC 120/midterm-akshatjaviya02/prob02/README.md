# Change Counter
In this program, you will be using C++ programming constructs, such as the relational operator, and "if" statements.

## main.cpp
Write a program that asks the user to enter the amount of change they have - quarters, dimes, nickels, and pennies. The program will then let the user know whether they have exactly one dollar, or how far off from a dollar the change is, output with exactly 2 digits past the decimal.

If the user enters a negative number for any of the values, display an error message.

# Hints
1. Be sure your program adds up the number of coins that were entered
1. If the change does not total exactly one dollar, be sure your program tells the user whether it is less than or greater than a dollar

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
How much change do you have?
  Quarters: <b>3</b>
  Dimes: <b>1</b>
  Nickels: <b>3</b>
  Pennies: <b>0</b>
Your 7 coins total exactly one dollar.
</pre>

## Sample Output #2
<pre>
How much change do you have?
  Quarters: <b>3</b>
  Dimes: <b>3</b>
  Nickels: <b>3</b>
  Pennies: <b>3</b>
Your 13 coins are greater than one dollar by $0.23.
</pre>

## Sample Output #3
<pre>
How much change do you have?
  Quarters: <b>1</b>
  Dimes: <b>2</b>
  Nickels: <b>3</b>
  Pennies: <b>4</b>
Your 10 coins are less than one dollar by $0.36.
</pre>

## Sample Output #4
<pre>
How much change do you have?
  Quarters: <b>-1</b>
  Dimes: <b>1</b>
  Nickels: <b>1</b>
  Pennies: <b>1</b>
Invalid input. All values must be greater than 0.
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `==` `&&` `||`, etc.)
1. **Variables**
   - Did you use descriptive variable names that tell the purpose/usage of the variable?
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *The output will differ depending on whether the total is less than, greater than, or exactly one dollar*
     - *Be sure to include exactly 2 digits past the decimal*
1. **Error check**
   - Does your program output an error message when the user enters an invalid value?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?
