// This program asks the user to enter the number of quarters, dimes,
// nickels, and pennies they have, and lets the user know whether the
// change adds up to exactly one dollar ($1.00).

#include <iomanip>
#include <iostream>

int main()
{
  double quarters, dimes, nickels, pennies, total1, total2, total3, total4, total5, total6, total7, total8;

  std::cout << "How much change do you have?\n";

  std::cout << "Quarters: ";
  std::cin >> quarters;

  std::cout << "Dimes: ";
  std::cin >> dimes;

  std::cout << "Nickels: ";
  std::cin >> nickels;

  std::cout << "Pennies: ";
  std::cin >> pennies;


  total1 = quarters * .25;

  total2 = dimes * 0.10;

  total3 = nickels * 0.05;

  total4 = pennies * 0.01;

  total5 = quarters + dimes + nickels + pennies;

  total6 = total1 + total2 + total3 + total4;

  bool valid = quarters < 0 || dimes < 0 || nickels < 0 || pennies < 0;
  if (valid == true)
  {
    std::cout << "Invalid input. All values must be greater than 0.\n";
  }
  else
  {
    if (total6 == 1.00)
    {
      std::cout << "your " << total5 << " coins total exactly one dollar\n";
    }
    if (total6 > 1.00)
    {
      total7 = total6 - 1.00;
      std::cout << "your " << total5 << " coins are greater than one dollar by $" << total7 << std::endl;
    }
    if (total6 < 1.00)
    {
      total8 = 1.00 - total6;
      std::cout << "Your " << total5 << " coins are less than one dollar by $" << total8 << std::endl;
    }
  }

  return 0;
}
