// This program reads from a file and writes all data from that file into
// a new file.

#include <fstream>
#include <iostream>
#include <string>

// function prototype
void copyFile(std::string input_filename, std::string output_filename);

int main()
{
  // constants to hold the names of two files
  const std::string INPUT_FILE = "input_file.txt";
  const std::string OUTPUT_FILE = "output_file.txt";

  // TODO: call the function that will copy the contents of the input file
  // into the output file
  // note: this is only one line of code - the function does the work
  // function arguments: pass the two constants for the names of the files

  copyFile (INPUT_FILE, OUTPUT_FILE);

  return 0;
}

// TODO: create a function that takes the names of two files, and copies
// the contents of one file to the other file
void copyFile(std::string input_filename, std::string output_filename)
{
  std::ifstream in_file;
  in_file.open(input_filename);
  std::string file;
  if (in_file)
  {
    std::ofstream out_file;
    out_file.open(output_filename);
    while (getline(in_file, file))
    {
      out_file << file << std::endl;
    }
    out_file.close();
    in_file.close();
    std::cout << "Input file has been copied to: " << output_filename << std::endl;
  }
  else
  {
    std::cout << "File not found: " << input_filename << std::endl;
  }
}
