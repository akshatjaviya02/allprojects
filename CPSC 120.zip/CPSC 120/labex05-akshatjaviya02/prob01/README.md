# Pythagorean Theorem
In this program, you will be using C++ programming constructs, such as cout, cin, and functions from the cmath library.

## main.cpp
You see an airplane just taking off from the airport. Write a program that uses the Pythagorean Theorem ![Pythagorean Theorem](resources/pythagorean.png) to calculate the distance the airplane is from you.

![Airplane](resources/airplane.png)
![Pythagorean Theorem Triangle](resources/triangle.png)

Your program will prompt the user for the altitude of the airplane (side `b` of the triangle) as well as how far you would need to travel on the ground for the airplane to be directly overhead (side `a` of the triangle).

Be sure you use the `cmath` library functions `sqrt` and `pow` in your formula.

The total distance should be represented with exactly 3 digits past the decimal, including when those digits have a value of 0.

# Hints
1. For the Pythagorean Theorem, your program should use the functions **sqrt** and **pow** from the **cmath** library
1. To format the output correctly, use stream manipulators from the **iomanip** library

# Completion Checklist
1. Did you comment your code where appropriate?
1. Did you use both of these functions: sqrt, pow
1. Does your code follow the coding standards (especially spacing and indentation)?
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Does your program produce the same results as both sample output below (including digits past the decimal)?
1. Does the GitHub Website show your latest code updates?

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
How high is the airplane in feet? <b>300</b>
How far away (ground distance)? <b>400</b>
The airplane's actual distance from you is 500.000 feet.
</pre>

## Sample Output #2
<pre>
How high is the airplane in feet? <b>5280</b>
How far away (ground distance)? <b>88</b>
The airplane's actual distance from you is 5280.733 feet.
</pre>
