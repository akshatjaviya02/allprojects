// This program calculates an airplane's distance from someone on the ground.

#include <cmath>
#include <iomanip>
#include <iostream>

int main()
{
  double height, distance, total, total_distance;

  // get the airplane's altitude and distance away
  std::cout << "How high is the airplane in feet? ";
  std::cin >> height;
  std::cout << "How far away (ground distance)? ";
  std::cin >> distance;

  total = pow (height, 2) + pow (distance, 2);
  total_distance = sqrt (total);

  // display the calculation
  std::cout << "The airplane's actual distance from you is " << std::setprecision (3) << std::fixed << total_distance << " feet." << std::endl;
  return 0;
}
