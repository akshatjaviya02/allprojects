# Find the Errors
In this program, you will debug a program that contains the following:
1. Compile time bugs
1. Run time bugs (these compile but produce error output values)
1. Style guide violations

## main.cpp
1. Visually inspect the code and fix any code statements that do not follow the style guide (e.g., spacing and indentation). If needed, refer to the "CPSC 120 C++ Style Guide" on Titanium class page
1. Try compiling the program to find out what errors the compiler finds
1. Find and fix the compile time bug(s)
1. Once the program compiles, try running it to see whether it outputs the expected results
1. Find and fix any bug(s) in the program that are causing incorrect results to be output

# Hints
1. The compiler outputs the line number and column of the error if a compile time error is encountered. For example:

    `main.cpp:24:37` indicates an error in your code on line 24, column 37
1. If you get an error on a function that appears correct, double check its spelling
1. Make sure the username output **includes double quotes** around it as well as **both of the initials** that the user types for middle name and last name
1. Keep in mind how the program reads the input buffer. For example, when the user enters his or her middle initial followed by the <kbd>enter</kbd> key, that creates two characters for your program to read. Make sure the second character (the <kbd>enter</kbd> key) is not being stored in a variable in your program

   Note: if you try to print a variable whose value contains the <kbd>enter</kbd> key, it would show as a newline in the output

# Completion Checklist
1. Does your code follow the coding standards (especially spacing and indentation)?
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Does the username include double quotes in the output?
1. Does your program produce the same results as both of the sample output below? (be careful the username is exactly the same)
1. Does the GitHub Website show your latest code updates?

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Enter your first name: <b>tuffy</b>
Enter the first initial of your middle name: <b>e</b>
Enter the first initial of your last name: <b>t</b>
Your username is "tuffyet"
</pre>

## Sample Output #2
<pre>
Enter your first name: <b>cppisf</b>
Enter the first initial of your middle name: <b>u</b>
Enter the first initial of your last name: <b>n</b>
Your username is "cppisfun"
</pre>
