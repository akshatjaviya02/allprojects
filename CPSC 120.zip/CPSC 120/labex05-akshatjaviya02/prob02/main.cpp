// This program asks the user for their first name and middle/last initials
// and outputs their username.

#include <iostream>
#include <string>

int main()
{
  // get the user's name
  std::string first_name;
  std::cout << "Enter your first name: ";
  std::getline(std::cin, first_name);

  char middle_initial, last_initial;
  std::cout << "Enter the first initial of your middle name: ";
  std::cin.get(middle_initial);
  std::cin.ignore();

std::cout << "Enter the first initial of your last name: ";
  last_initial = std::cin.get();

  // create username out of user's first name and middle/last initials
  // adding double quotes around the username output
  std::string username = first_name + middle_initial + last_initial;
  std::cout << "Your user name is \"" << username << "\" \n";

  return 0;
}
