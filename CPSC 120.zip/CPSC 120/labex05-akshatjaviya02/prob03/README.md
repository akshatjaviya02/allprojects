# Random Rectangle
In this program, you will be using C++ programming constructs, such as cout, rand, and arithmetic operators.

## main.cpp
Write a program that creates a randomly sized rectangle and prints it out. The rectangle will always have a height of 3, but will have a random length.

The sample below shows `@` signs for the symbol used to create the rectangle, but you can choose whatever character you want to make up your rectangle.

Define the following constant in your program:
1. The maximum length of the rectangle, set to 40

# Hints
1. You can use the `assign()` function to create a row of characters for your rectangle
1. The `rand()` function will return a value from 0 to RAND_MAX, which is currently set to the maximum value that an `int` can hold. However, since your rectangle should never be longer than 40, **use the modulus operator (%)** to limit its length
1. Be sure your program will never print a 0 length rectangle. The modulus operator can return 0, but your rectangle length should always be between 1 and 40, inclusive
1. If your rectangle is the same length every time you run your program, look into usage of the `srand()` function

# Completion Checklist
1. Did you comment your code where appropriate?
1. Did you declare and use a constant (also did you name it with all capital letters)?
1. Did you use both of these functions: srand and rand?
1. Does your code follow the coding standards (especially spacing and indentation)?
1. Does your program compile? (i.e. no errors or warnings when you run clang++)
1. Does your program produce different lengths when run multiple times in a row?
1. Does the GitHub Website show your latest code updates?

# Sample Output
Please run your program multiple times to see that the length of the rectangle changes each time you run the program. You do not need to recompile between runs.

*Note: your rectangle's length will not necessarily match the lengths shown in the samples below due to the random length.*

## Sample Output #1
```
@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@
```

## Sample Output #2
```
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
```
