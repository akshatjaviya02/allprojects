// This program creates a randomly sized rectangle.
#include <iostream>
#include <cstdlib>
#include <string>

int main()
{
  //random number
  unsigned seed = time(0);
  srand(seed);
  int max, num;

  // maximum number that can radom can genrate
  max = 40;

  //calculations
  num = 1 + (rand() % max);

  // repeat the character @
  std::string eq;
  eq.assign(num, '@');

  //display the @ in three lines
  std::cout << eq << '\n' << eq << '\n' << eq << std::endl;

  return 0;
}
