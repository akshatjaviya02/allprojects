#  Project Milestone 3 Objectives
1. Usage of if statements and/or switch statements
1. Output results in different forms
1. Compile and run program

# Business Trip Expenses
In this program, you will be learning to use the C++ programming conditional expressions.

# Prerequesites
`main.cpp` from Project Milestone 2

## main.cpp
Update Project Milestone 2 in the following ways:
1. Add a prompt to allow the user to enter an option (see Sample Output below), and read in the character option provided by the user (`char` data type)
1. Add a check on the user input
   - If the user enters 'E' or 'e' then prompt the user to enter the business trip information
   - If the user enters 'X' or 'x' then do not prompt the user for the business trip information
   - If the user enters anything other than 'E', 'e', 'X', or 'x' then print an error message to the user indicating it is an invalid option (see Sample Output below)
1. Add a closing message thanking the user (see Sample Output below)

# Hints
1. A `switch/case` statement is the perfect choice for a menu driven program, but you are welcome to choose an `if/else if` statement instead if you prefer

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
*Note: the string for location gets cut off at 18 characters in the output. Yours needs to as well.*

<pre>
Welcome to the Business Trip Tracker!

What would you like to do?
  E: enter a new expense
  X: exit the program
Option: <b>E</b>

What is the business trip location? <b>Labrador City, Canada</b>
How many days will the trip take? <b>9</b>
What is the hotel expense per day? $<b>188.49</b>
What is the total expense for all meals? $<b>613.22</b>

Location                  Days       Hotel        Meal       Total
Labrador City, Can           9     1696.41      613.22     2309.63

Thank you for using the Business Trip Tracker.
</pre>

## Sample Output #2
<pre>
Welcome to the Business Trip Tracker!

What would you like to do?
  E: enter a new expense
  X: exit the program
Option: <b>X</b>

Thank you for using the Business Trip Tracker.
</pre>

## Sample Output #3
<pre>
Welcome to the Business Trip Tracker!

What would you like to do?
  E: enter a new expense
  X: exit the program
Option: <b>J</b>

'J' is an invalid option.

Thank you for using the Business Trip Tracker.
</pre>

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `+` `-` `*` `/` `%` `=` `<<` `>>`)
1. **Variables**
   - Did you use variable names appropriate for the purpose/usage of the variable?
1. **Constants**
   - Did you use constants in your calls to `setw` and `substr`?
     - *Be sure you used constants instead of hardcoded integer literals*
     - *Be sure you used all UPPERCASE for the name of your constant*
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Input**
   - Does your program produce the same results whether the user enters a lowercase or uppercase option?
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure single quotation marks are included around the user input character in the "invalid option" output*
     - *Be sure the location name is cut off if it is greater than 18 characters*
1. **Table alignment**
   - Are the columns right-aligned for all columns other than the location?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?

# Code Evaluation
*Note:* the explanations of all commands listed below are detailed in **labex00**. Refer to the README file in labex00, if needed.

1. Get a copy of the project milestone from GitHub, change directory into your repo, and open main.cpp for editing in atom.

   ```
   git clone URL

   cd project01-USERNAME

   atom main.cpp
   ```

1. Compile and run your program.

   ```
   clang++ -std=c++17 main.cpp -o main
   ```
   ```
   ./main
   ```

# Submission
1. To upload your code to GitHub you will run the following 3 commands.

    ```
    git add .
    git commit -m "Description of your code changes"
    git push
    ```

1. If it asks you to configure global variables for an email and name, just copy the commands it provides but replace the dummy text with your email and GitHub username. When you're done, make sure you `git commit` your repository again.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```

1. Once you have pushed your changes to GitHub, double check that your local repository is clean. The following should report: **Your branch is up to date with 'origin/master'**

    ```
    git status
    ```

1. Go back to the GitHub Website and refresh the page to see that your changes are there.
