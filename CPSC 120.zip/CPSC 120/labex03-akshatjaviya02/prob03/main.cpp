// This program calculates a person's height in feet (') and inches (").
#include <iostream>

int main()
{
  int height, total_height, inches;
  // entering the hieght of the user
  std::cout <<"Please enter a person's heigh in inches: ";
  std::cin >> height;

  //calculate the height in feet
  total_height= height / 12;

  // Modulus
  inches= height % 12;

  std::cout << "That person is " << total_height << "\'" << inches << "\"" << std::endl;

  return 0;
}
