# Height Calculator
In this program, you will be using C++ programming constructs, such as cin, cout, arithmetic and assignment operators.

## main.cpp
Write a program that asks the user to enter a person's height in inches. Your program will then calculate and output the height in feet and inches. Note that a common way to indicate feet is a single quote ('), and inches is a double quote ("). See sample output below.

# Hints
1. Don't forget to add comments to explain what the code is doing
1. Choose variable names that explain the purpose of the variable
1. Make sure your code follows the coding standards (proper spacing and indentation)
1. The calculation will need to make use of the division operator (/) as well as the modulus operator (%)

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
<pre>
Please enter a person's height in inches: <b>74</b>
That person is 6'2"
</pre>

## Sample Output #2
<pre>
Please enter a person's height in inches: <b>67</b>
That person is 5'7"
</pre>
