# Find the Errors
In this program, you will debug a program that contains the following:
1. Compile time bugs
2. Run time bugs (these compile but produce error output values)
3. Style guide violations

## main.cpp
1. Visually inspect the code and fix any code statements that do not follow the style guide (e.g., spacing and indentation). If needed, refer to the "CPSC 120 C++ Style Guide" on Titanium class page.
1. Try compiling the program to find out what errors the compiler finds.
1. Find and fix the compile time bug(s).
1. Once the program compiles, try running it to see whether it outputs the expected results.
1. Find and fix any bug(s) in the program that are causing incorrect results to be output.

# Hints
1. The compiler outputs the line number and column of the error if a compile time error is encountered.
   e.g., `main.cpp:24:37` indicates an error in your code on line 24, column 37
1. If the column number of the error is the very beginning of a coding statement, then the actual error is most likely on the line of code that comes before the one that the compiler identified.
1. Remember that floating-point division requires one of the operands to be of type floating-point. Otherwise, integer division will occur, which truncates the decimal portion of the result.
1. If the command prompt displays at the end of your program's output rather than on its own line, then your code needs an endline or newline character at the end of the program's output.

# Sample Output
```
It will take 2.38235 gallons of paint to cover a wall that is 9 X 45 feet with 2 coats of paint.
```
