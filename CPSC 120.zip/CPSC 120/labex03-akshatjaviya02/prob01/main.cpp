// This program tests output on the ASCII character set, and on the sizeof operator.

#include <iostream>

int main()
{
  // TODO#1: try changing these values to others found in the ASCII character set
  // The class Quick Reference Guide contains this chart on page 5
  char my_char1 = 65;   // decimal
  char my_char2 = 0x41; // hex
  char my_char3 = 'A';  // character

  std::cout << "Char1: " << my_char1 << std::endl;
  std::cout << "Char2: " << my_char2 << std::endl;
  std::cout << "Char3: " << my_char3 << std::endl;

  std::cout << std::endl; // blank line to separate the different exercises

  // TODO#2: the following statement displays a plus sign
  // add 3 more cout statements that all print the same thing - a plus sign
  // however, use a different method to do so for each cout statement
  // hint: use the ASCII character set similar to how you did in TODO#1
  std::cout << "+" << std::endl;
  char my_char4 = 43;   //decimal
  std::cout << my_char4 << std::endl;
  std::cout << '+' << std::endl;   //character
  char my_char6 = 0x2B;   //hex
  std::cout << my_char6 << std::endl;
  std::cout << std::endl; // blank line to separate the different exercises

  // TODO#3: update the following statement to include escape characters
  // note that the clang compiler does not require an escape character on
  // the single quotation mark, but many other compilers do require it
  std::cout << "\'Y\'" << std::endl;

  std::cout << std::endl; // blank line to separate the different exercises

  // TODO#4: complete the sentence below by replacing the ellipsis (...) with
  // the reason that the value of my_bool changed
  bool my_bool = 8;
  std::cout << "The variable my_bool was set to 5, yet its value is now "
    << my_bool << " because bool is represented as true or false and would represent as 1 or 0\n";

  std::cout << std::endl; // blank line to separate the different exercises

  // TODO#5: complete the sentence below by replacing the ellipsis (...) with
  // the reason that the size of the character A is different in these two
  // cout statements
  std::cout << "The size of 'A' is " << sizeof('A') << ", but the size"
    << " of \"A\" is " << sizeof("A") << " because while using a single quotation the out output would be 1 bit instead of double quotation where the output was 2 bit with null terminator\n";

  std::cout << std::endl; // blank line to separate the different exercises

  // TODO#6: repeat the following line of code for each of the following data
  // types - float (given), double, bool, char, short, int, long, long long
  // Note that the number of bytes for some types, like a long, is dependent
  // on the operating system
  std::cout << "A float is stored in " << sizeof(float) << " bytes\n";
  std::cout << "A double is stored in " << sizeof(double) << " bytes\n";
  std::cout << "A bool is stored in " << sizeof(bool) << " bytes\n";
  std::cout << "A short is stored in " << sizeof(short) << " bytes\n";
  std::cout << "A int is stored in " << sizeof(int) << " bytes\n";
  std::cout << "A long is stored in " << sizeof(long) << " bytes\n";
  std::cout << "A long long is stored in " << sizeof(long long) << " bytes\n";
  return 0;
}
