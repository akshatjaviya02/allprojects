# Complete the TODO Statements
In this program, you will be learning to use the basic C++ programming constructs, such as cout, sizeof, and the ASCII character set.

## main.cpp
Find the statements marked "TODO" in the program, and follow the instructions found there.

# Hints
1. Make sure you have completed the code instructed by every one of the "TODO" statements.
