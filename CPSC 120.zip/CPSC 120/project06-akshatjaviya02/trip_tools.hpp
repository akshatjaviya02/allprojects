// Programmer's Name:

#include <string>

const int SIZE = 18; // declearing an constant for set width for location to line up.
const int COLUMN_WIDTH = 12; // declearing an constant for set width for everything else except location.
const std::string INPUT_FILE = "trips.txt";
const int MAX = 100;

//----------------------
// STRUCTS
//----------------------

// This structure holds all information for a business trip

struct BusinessTripInfo
{
  std::string location;
  int days;
  double hotel;
  double meal;
  double total;
};

//----------------------
// FUNCTION PROTOTYPES
//----------------------

// This function gets a new trip from the user
void getNewTrip(BusinessTripInfo trips[], int & num);

// This function prints just one trip to the console, as selected by the user
void printSingleTrip(BusinessTripInfo trips[], int num);

// This function prints all trips to the console in table format
void printAllTrips(BusinessTripInfo trips[], int num);

// This function prints all trips to a file in table format
void writeTripsToFile(BusinessTripInfo trips[], int num);

// This function reads all trips from a file and adds them to the array
void addTripsFromFile(BusinessTripInfo trips[], int & num);
