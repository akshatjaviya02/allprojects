// This program calculates and displays business trip expenses.
#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include "trip_tools.hpp"


int main()
{
  BusinessTripInfo my_trips[MAX];
  char letter;
  int num = 0;
  //Welcoming to business trip calculator.
  std::cout << "Welcome to the Bussiness Trip Tracker!\n";

  // loop will go on until user inputs small 'x' or captial 'X'.
  do
  {
      std::cout << "\nWhat would you like to do?\n";
      std::cout << "E: enter a new expense\n";
      std::cout << "P: print a single expense\n";
      std::cout << "R: read expenses from a file\n";
      std::cout << "T: print table of all expenses\n";
      std::cout << "W: write expenses to a file\n";
      std::cout << "X: exit the program\n";
      std::cout << "Opition: ";
      std::cin >> letter;
      std::cin.ignore();
      std::cout << '\n';

      // t or T would print an horizontal table.
      if (letter == 't' || letter == 'T')
      {
        printAllTrips(my_trips, num);
      }
      // p or P would print veritcal table.
      else if (letter == 'p' || letter == 'P')
      {
        printSingleTrip(my_trips, num);
      }
      // e or E would let user input the about trip.
      else if (letter == 'e' || letter == 'E')
      {
        getNewTrip(my_trips, num);
      }
      else if (letter == 'R' || letter == 'r')
      {
        addTripsFromFile(my_trips, num);
      }
      else if (letter == 'W' || letter == 'w')
      {
        writeTripsToFile(my_trips, num);
      }

      // if user input other than T,P,X,E,e,p,t,x,R,r,W,w the program would ask user to input a valid option.
      else if (letter != 'x' && letter != 'X')
      {
        std::cout << '\n' << "\'" << letter << "\'" << "that is an invalid option\n";
      }
  } while (letter != 'X' && letter != 'x');

  std::cout << "Thank you for using the Business Trip Tracker.\n";
}
