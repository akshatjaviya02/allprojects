#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
#include "trip_tools.hpp"

void getNewTrip(BusinessTripInfo trips[], int & num)
{
  if (num <= MAX)
  {
    // Bussiness place.
    std::cout << "What is the business trip location? ";
    getline(std::cin, trips[num].location);

    //days of the Bussiness trip.
    std::cout << "How many days will the trip take? ";
    std::cin >> trips[num].days;

    //hotel's expenses.
    std::cout << "What is the hotel expense per day? $";
    std::cin >> trips[num].hotel;

    //total expenses for all meal.
    std::cout << "What is the total expense for all the meals? $";
    std::cin >> trips[num].meal;

    //calculate total expenses.
    trips[num].hotel = trips[num].days * trips[num].hotel;
    trips[num].total = trips[num].hotel + trips[num].meal;

    std::cout << "\nThank you. This trip has been added.\n";
    num++;
  }
  else
  {
    std::cout << "Error over 100 business trips were entered" << std::endl;
  }
}
void printSingleTrip(BusinessTripInfo trips[], int num)
{
  int number;
  const int COUNT1 = 1;
  int count;
  if (num == 0)
  {
    std::cout << "\nNo trips have been entered.\n";
  }
  else
  {
    std::cout << "Which bussiness trip would you like to be printed out?\n";
    for (count = 0; count < num; count++)
    {
      trips[num].location.resize(SIZE);
      std::cout << count + 1 << ". " << trips[count].location << '\n';
    }
    std::cout << "select trip#: ";
    std::cin >> number;
    while(number < 1 || number > (count))
    {
      std::cout << "Trips must be between " << COUNT1 << " and " << count << ": ";
      std::cin >> number;
    }
    trips[number - 1].location.substr(0);
    std::cout << std::setprecision(2) << std::fixed;
    std::cout << "\nLocation: " << trips[number - 1].location << '\n';
    std::cout << "Days:     " << trips[number - 1].days << '\n';
    std::cout << "Hotel:    $" << trips[number - 1].hotel << '\n';
    std::cout << "Meal:     $" << trips[number - 1].meal << '\n';
    std::cout << "Total:    $" << trips[number - 1].total << '\n';
  }
}
void printAllTrips(BusinessTripInfo trips[], int num)
{
  if (num == 0)
  {
    std::cout << "\nNo trips have been entered.\n";
  }
  else
  {
    std::cout << std::left << std::setw(SIZE) << "Location" << std::right << std::setw(COLUMN_WIDTH) << "Days"
      << std::setw(COLUMN_WIDTH) << "Hotel" << std::setw(COLUMN_WIDTH) << "Meal" << std::setw(COLUMN_WIDTH)
      << "Total\n";
    for (int i = 0; i < num; i++)
    {
      // seting the width of columns and setting the answer to be two decimal. Displays the calculations
      std::cout << std::left << std::setw(SIZE) << trips[i].location.substr(0, SIZE) << std::right
        << std::setw(COLUMN_WIDTH) << trips[i].days << std::setprecision(2) << std::fixed << std::setw(COLUMN_WIDTH)
        << trips[i].hotel << std::setw(COLUMN_WIDTH) << trips[i].meal << std::setw(COLUMN_WIDTH)
        << trips[i].total << std::setw(COLUMN_WIDTH) << '\n';
    }
  }
}
void writeTripsToFile(BusinessTripInfo trips[], int num)
{
  std::ofstream out_file;
  out_file.open(INPUT_FILE);
  trips[num].location.resize(SIZE);
  out_file << std::left << std::setw(SIZE) << "Location" << std::right << std::setw(COLUMN_WIDTH) << "Days"
      << std::setw(COLUMN_WIDTH) << "Hotel" << std::setw(COLUMN_WIDTH) << "Meal" << std::setw(COLUMN_WIDTH)
      << "Total\n";
  for (int i = 0; i < num; i++)
  {
    out_file << std::left << std::setw(SIZE) << trips[i].location.substr(0, SIZE) << std::right
      << std::setw(COLUMN_WIDTH) << trips[i].days << std::setprecision(2) << std::fixed << std::setw(COLUMN_WIDTH)
      << trips[i].hotel << std::setw(COLUMN_WIDTH) << trips[i].meal << std::setw(COLUMN_WIDTH) << trips[i].total << '\n';
    }
    out_file.close();
  std::cout << "Trips have been written to file \"" << INPUT_FILE << "\" \n";
}
void addTripsFromFile(BusinessTripInfo trips[], int & num)
{
  int V1 = 0;
  std::ifstream in_file;
  in_file.open(INPUT_FILE);
  std::string ignoreme;
  if (in_file)
  {
    getline(in_file, ignoreme);
    while(num < MAX && in_file.peek() != EOF)
    {
      trips[num].location.resize(SIZE);
      in_file.read(&trips[num].location[0], SIZE);
      in_file >> trips[num].days >> trips[num].hotel >> trips[num].meal >> trips[num].total;
      ++num;
      V1++;
      in_file.ignore();
    }

    if (V1 == 0)
    {
      std::cout << "The file \"" << INPUT_FILE << "\" is empty.\n";
    }
    else
    {
      std::cout << "Trips from file \"" << INPUT_FILE << "\" have been loaded.\n";
    }
    in_file.close();
  }
  else
  {
    std::cout << "The file \"" << INPUT_FILE << "\" does not exist.\n";
  }
}
