#  Project Milestone 6 Objectives
1. Usage of arrays, functions, and structs
1. Compile, debug, and run the program

# Business Trip Expenses
This program displays a menu of options to the user, and responds to whichever option the user selects. The program will continue to display options until the user selects to exit the program.

# Prerequesites
`main.cpp` from Project Milestone 5

## main.cpp
Update Project Milestone 5 in the following ways:
1. Move all constants to the file `trip_tools.hpp` and add a `#include` for this header file in `main.cpp`
1. Create an array of structs to hold all trips entered by the user or read from the file
   - *Note: the struct is already defined in* `trip_tools.hpp`
1. For each of the options, call a function now
   - *Move the code that you currently have for the option to the appropriate function in* `trip_tools.cpp`
   - *The function prototypes are already defined in* `trip_tools.hpp`
   - *You will need to add the function bodies to* `trip_tools.cpp`

## trip_tools.hpp
This file contains all constants, user defined types (the struct), and all function prototypes. The only thing you need to modify in this file are the constants.
1. Move all constants that you currently have defined in `main.cpp` to this file
1. Add a constant for the maximum number of trips, set to 100

## trip_tools.cpp
This file will contain the function bodies for the 5 functions whose prototypes are defined in `trip_tools.hpp`

For each of the options 'E', 'P', 'R', 'T', and 'W' you will move your code from `main()`* to the appropriate function body.
   - 'E' : getNewTrip()
   - 'P' : printSingleTrip()
   - 'R' : addTripsFromFile()
   - 'T' : printAllTrips()
   - 'W' : writeTripsToFile()

In addition, make the following updates to the options:
1. Update option 'E' to check that the array is not full, and if not then add the new trip to the array
   - *If the array is full, do not prompt the user to enter the trip information
   - *Instead, print an error message indicating the user cannot add a new trip*
1. Update option 'R' to read multiple trips from the file
   - *If the array already contains trips, this will add the trips from the file on to the end of the array*
   - *Be sure and check that you don't add past the end of the array*
1. Update options 'T' and 'W' to write multiple trips to the console/file
1. Update option 'P' to allow the user to select which trip they would like to print. This option will now display a numbered list of trips where only the trip location shows, and allow the user to select a number from the list
   - *For example, if the array currently contains 4 trips, then a numbered set of only the locations for those 4 trips will be displayed, and the user can select a number in the range 1-4*
   - *Be sure this works no matter how many trips are in the array*
   - *Continue asking the user for a valid trip# if the user enters an invalid value*

# Hints
1. For option 'P' the numbered list will start at 1, but don't forget that the array starts at 0
   - *Be sure and adjust the values being displayed accordingly*

# Sample Output
Please note that items in **bold** are user input. These values will not be in your program. However, when your program executes and asks for a value, you will type those values into the *Terminal* window.

## Sample Output #1
For this sample, the contents of the file are as follows. You can view the file contents in Atom or by typing `cat trips.txt` at the command prompt in a Terminal window.
```
cat trips.txt
```
Observe that the following is displayed.
```
Location                  Days       Hotel        Meal       Total
Kalamazoo, Michiga           5      600.00      150.00      750.00
Somewhere Far Away           8      800.00      123.34      923.34
New York City                3      649.20      220.80      870.00
Los Angeles, Calif           2      441.11       51.59      492.70
Orlando, Florida             7      733.90      200.00      933.90
```

Now run the program, selecting the following menu options.

<pre>
Welcome to the Business Trip Tracker!

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>r</b>

Trips from file "trips.txt" have been loaded.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>p</b>

Which trip would you like to print?
  1. Kalamazoo, Michiga
  2. Somewhere Far Away
  3. New York City     
  4. Los Angeles, Calif
  5. Orlando, Florida  
Select trip#: <b>6</b>
Trip# must be between 1 and 5: <b>0</b>
Trip# must be between 1 and 5: <b>5</b>

Location: Orlando, Florida  
Days:     7
Hotel:    $733.90
Meal:     $200.00
Total:    $933.90

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>t</b>

Location                  Days       Hotel        Meal       Total
Kalamazoo, Michiga           5      600.00      150.00      750.00
Somewhere Far Away           8      800.00      123.34      923.34
New York City                3      649.20      220.80      870.00
Los Angeles, Calif           2      441.11       51.59      492.70
Orlando, Florida             7      733.90      200.00      933.90

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>e</b>

What is the business trip location? <b>Southampton, England</b>
How many days will the trip take? <b>12</b>
What is the hotel expense per day? $<b>209.19</b>
What is the total expense for all meals? $<b>773.11</b>

Thank you. This trip has been added.

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>t</b>

Location                  Days       Hotel        Meal       Total
Kalamazoo, Michiga           5      600.00      150.00      750.00
Somewhere Far Away           8      800.00      123.34      923.34
New York City                3      649.20      220.80      870.00
Los Angeles, Calif           2      441.11       51.59      492.70
Orlando, Florida             7      733.90      200.00      933.90
Southampton, Engla          12     2510.28      773.11     3283.39

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>w</b>

Trips have been written to file "trips.txt"

What would you like to do?
  E: enter a new expense
  P: print a single expense
  R: read expenses from a file
  T: print table of all expenses
  W: write expenses to a file
  X: exit the program
Option: <b>x</b>

Thank you for using the Business Trip Tracker.
</pre>

Now view the file contents again to be sure the new trip is included at the end of the file as shown below.
```
cat trips.txt
```
Observe that the following is displayed.
```
Location                  Days       Hotel        Meal       Total
Kalamazoo, Michiga           5      600.00      150.00      750.00
Somewhere Far Away           8      800.00      123.34      923.34
New York City                3      649.20      220.80      870.00
Los Angeles, Calif           2      441.11       51.59      492.70
Orlando, Florida             7      733.90      200.00      933.90
Southampton, Engla          12     2510.28      773.11     3283.39
```

# Grading Checklist
1. **Comments**
   - Did you comment your code to explain what the code is doing?
1. **Style**
   - Does your code follow the coding standards?
     - *Be sure your code is properly indented*
     - *Be sure you put a space on either side of all operators* (e.g. `=` `+` `-` `*` `/` `%` `<<` `>>` `||` `&&` `<` `>` `==` `!=`, etc.)
1. **Variables**
   - Did you use variable names and data types appropriate for the purpose and usage of the variable?
1. **Constants**
   - Did you use a constant for the maximum number of trips?
     - *Be sure you used all UPPERCASE for the name of your constant*
   - Did you use this constant in your code rather than a hardcoded integer literal for the value 100?
1. **Compile**
   - Does your program compile?
     - *Be sure there are no errors or warnings when you run clang++*
1. **Input**
   - Does your program produce the same results whether the user enters a lowercase or uppercase option?
1. **Output**
   - Does your program produce the same results as the Sample Output?
     - *Be sure the proper message is printed with each option*
     - *Be sure single quotation marks are included around the user input character in the "invalid option" output*
     - *Be sure the location name is cut off if it is greater than 18 characters for table output*
1. **Table alignment**
   - For table output, are the columns right-aligned for all columns other than the location?
1. **Error check**
   - Does your program output an error message when the array is full?
   - Does your program output an error message when there are no trips entered and the user selects to print or write to the file?
1. **GitHub**
   - Does the GitHub Website show your latest code updates?

# Code Evaluation
*Note:* the explanations of all commands listed below are detailed in **labex00**. Refer to the README file in labex00, if needed.

1. Get a copy of the project milestone from GitHub, change directory into your repo, and open main.cpp for editing in atom.

   ```
   git clone URL

   cd project01-USERNAME

   atom main.cpp
   ```

1. Compile and run your program.

   ```
   clang++ -std=c++17 main.cpp -o main
   ```
   ```
   ./main
   ```

# Submission
1. To upload your code to GitHub you will run the following 3 commands. You will replace the text *"Description of your code changes"* with an actual description of what you are checking in.

    ```
    git add .
    git commit -m "Description of your code changes"
    git push
    ```

1. If it asks you to configure global variables for an email and name, just copy the commands it provides but replace the dummy text with your email and GitHub username. When you're done, make sure you `git commit` your repository again.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```

1. Once you have pushed your changes to GitHub, double check that your local repository is clean. The following should report: **Your branch is up to date with 'origin/master'**

    ```
    git status
    ```

1. Go back to the GitHub Website and refresh the page to see that your changes are there.
