#include "shapes.h"
void PrintShapeInfo(Shape& shape) {
  std::cout << shape.GetType() << " with area " << shape.GetArea() << std::endl;
}
