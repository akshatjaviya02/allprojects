#include "shapes.h"
int main() {
  int width, height;
  std::cout << "Please kindly insert the width of the shape: ";
  std::cin >> width;
  std::cout << "Please kindly insert the hieght of the shape: ";
  std::cin >> height;
  Rectangle rect(width, height);
  PrintShapeInfo(rect);
  Triangle tri(width, height);
  PrintShapeInfo(tri);
  Ellipse elle(width, height);
  PrintShapeInfo(elle);
  return 0;
}
