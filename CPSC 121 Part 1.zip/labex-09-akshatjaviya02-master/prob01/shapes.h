#include <iostream>
#include <string>
#ifndef SHAPES_H
#define SHAPES_H

// Define your Shape and subclasses here.
class Shape {
 private:
  int width_;
  int height_;

 public:
  Shape(int width, int height) : width_(width), height_(height) {}
  int GetWidth() { return width_; }
  int GetHeight() { return height_; }
  virtual int GetArea() = 0;
  virtual std::string GetType() = 0;
};
class Rectangle : public Shape {
 public:
  Rectangle(int width, int height) : Shape(width, height) {}
  int GetArea() override {
    int rect_area = GetWidth() * GetHeight();
    return rect_area;
  }
  std::string GetType() override {
    std::string rect_name = "rectangle";
    return rect_name;
  }
};
class Triangle : public Shape {
 public:
  Triangle(int width, int height) : Shape(width, height) {}
  int GetArea() override {
    const double HALF = 0.5;
    int tri_area = HALF * GetWidth() * GetHeight();
    return tri_area;
  }
  std::string GetType() override {
    std::string tri_name = "triangle";
    return tri_name;
  }
};
class Ellipse : public Shape {
 public:
  Ellipse(int width, int height) : Shape(width, height) {}
  int GetArea() override {
    const double HALF = 0.5;
    const double PI = 3.14159;
    double elle_area = GetWidth() * HALF * GetHeight() * HALF * PI;
    return elle_area;
  }
  std::string GetType() override {
    std::string elle_name = "ellipse";
    return elle_name;
  }
};
void PrintShapeInfo(Shape& shape);
#endif  // SHAPES_H
