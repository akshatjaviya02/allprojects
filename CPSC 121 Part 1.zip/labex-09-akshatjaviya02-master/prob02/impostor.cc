#include "impostor.h"

#include <iostream>

#include "crewmate.h"

// Implement the methods in the Impostor class here.
void Impostor::Kill(Crewmate &crewmate) const {
  crewmate.SetIsAlive(false);
  std::cout << '\"' << GetName() << " killed " << crewmate.GetName() << '\"'
            << std::endl;
}
