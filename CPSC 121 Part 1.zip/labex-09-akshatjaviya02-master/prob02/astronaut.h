#include <string>

#include "cpputils/graphics/image.h"

// These header guards are necessary to keep your class from being defined
// multiple times when it is included from multiple files.
#ifndef ASTRONAUT_H
#define ASTRONAUT_H

// Define your Astronaut class here.
class Astronaut {
 protected:
  std::string astro_name_;
  graphics::Color main_color_;

 public:
  Astronaut(std::string astro_name, graphics::Color main_color)
      : astro_name_(astro_name), main_color_(main_color) {}
  std::string GetName() const { return astro_name_; }
  virtual graphics::Color GetColor() const;
  virtual std::string GetIconFilename() const;
};
#endif  // ASTRONAUT_H
