#include "astronaut.h"

// Implement the methods in the Astronaut class here.
graphics::Color Astronaut::GetColor() const { return main_color_; }
std::string Astronaut::GetIconFilename() const { return "astronaut.bmp"; }
