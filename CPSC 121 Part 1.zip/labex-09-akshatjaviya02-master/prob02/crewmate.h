#include "astronaut.h"

// These header guards are necessary to keep your class from being defined
// multiple times when it is included from multiple files.
#ifndef CREWMATE_H
#define CREWMATE_H

// Define your crewmate class here.
class Crewmate : public Astronaut {
 private:
  bool track_ = true;
  int task_count_ = 0;

 public:
  Crewmate() : Astronaut("James", graphics::Color(0, 0, 255)) {}
  Crewmate(std::string name, graphics::Color color) : Astronaut(name, color) {}
  bool GetIsAlive() const { return track_; }
  void SetIsAlive(bool track) { track_ = track; }
  int GetTaskCount() const { return task_count_; }
  void DoTask(std::string name) {
    task_count_++;
    std::cout << astro_name_ << " is doing " << name << std::endl;
  }
  graphics::Color GetColor() const override;
  std::string GetIconFilename() const override;
};
#endif  // CREWMATE_H
