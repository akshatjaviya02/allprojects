#include "crewmate.h"

// Implement the methods in the Crewmate class here.
graphics::Color Crewmate::GetColor() const {
  if (track_) {
    return Astronaut::GetColor();
  } else {
    graphics::Color die((Astronaut::GetColor().Red() + 256) / 2,
                        (Astronaut::GetColor().Green() + 256) / 2,
                        (Astronaut::GetColor().Blue() + 256) / 2);
    return die;
  }
}
std::string Crewmate::GetIconFilename() const {
  if (track_ == false) {
    return "ghost.bmp";
  } else {
    return "astronaut.bmp";
  }
}
