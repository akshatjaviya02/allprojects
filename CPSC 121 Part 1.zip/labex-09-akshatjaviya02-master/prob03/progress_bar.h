#include "cpputils/graphics/image.h"
#include "cpputils/graphics/image_event.h"

#ifndef PROGRESS_BAR_H
#define PROGRESS_BAR_H

const graphics::Color kProgressBackground(224, 224, 224);
const graphics::Color kProgressForeground(30, 136, 229);

// TODO: Inherit from AnimationEventListener.
class ProgressBar : public graphics::AnimationEventListener {
 public:
  // TODO: Add your constructor, destructor, and member functions.
  ProgressBar() : image_(graphics::Image(500, 30)) {}
  ~ProgressBar() { image_.RemoveAnimationEventListener(*this); }
  void OnAnimationStep() override;
  void Initialize(int speed);
  void Start();
  // Used by unit tests. Do not modify.
  graphics::Image* GetImageForTesting() { return &image_; }

 private:
  // The image onto which you can draw the ProgressBar.
  graphics::Image image_;
  int speed_;
  int Xcord = 0;
  // TODO: Add other data members here.
};

#endif  // PROGRESS_BAR_H
