#include "progress_bar.h"
void ProgressBar::OnAnimationStep() {
  image_.DrawRectangle(0, 0, 500, 30, kProgressBackground);
  if (Xcord <= 300) {
    image_.DrawRectangle(Xcord, 0, 200, 30, kProgressForeground);
  }
  if (Xcord >= 301 && Xcord <= 500) {
    int right = Xcord - 300;
    int left = Xcord - 200;
    image_.DrawRectangle(0, 0, right, 30, kProgressForeground);
    image_.DrawRectangle(Xcord, 0, left, 30, kProgressForeground);
  }
  image_.Flush();
  Xcord = Xcord + speed_;
  if (Xcord >= 500) {
    Xcord -= Xcord;
  }
  std::cout << "Animation step!" << '\n';
}
void ProgressBar::Initialize(int speed) {
  speed_ = speed;
  graphics::Image image(500, 30);
  image_.DrawRectangle(0, 0, 500, 30, kProgressBackground);
  image_.AddAnimationEventListener(*this);
}
void ProgressBar::Start() {
  image_.ShowUntilClosed("Loading league of legend");
}
