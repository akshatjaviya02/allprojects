#include <iostream>
#include "progress_bar.h"
int main() {
  ProgressBar progress_bar;
  progress_bar.Initialize(5);
  progress_bar.Start();
  return 0;
}
