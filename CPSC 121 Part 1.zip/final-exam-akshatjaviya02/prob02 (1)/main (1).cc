#include "cellphone.h"
#include <iostream>
#include <memory>

int main() {

  // TODO
  // provide the function body for your "main" function here
  Cellphone cellphone("Android", "555-555-5555");
  cellphone.Pair(std::unique_ptr<Speaker>sp("Bose"));
  cellphone.Display();

  std::cout << std::endl;
  return 0;
}
