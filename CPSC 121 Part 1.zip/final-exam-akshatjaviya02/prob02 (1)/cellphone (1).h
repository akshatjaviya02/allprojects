#ifndef CELLPHONE_H
#define CELLPHONE_H

#include <memory>
#include <string>

//------------------------------
// Speaker class definition
//------------------------------

class Speaker {
 private:
  std::string name_;

 public:
  Speaker(const std::string &name) : name_(name) {}
  std::string GetName() const { return name_; }
};

//------------------------------
// Cellphone class definition
//------------------------------

// TODO
// provide your Cellphone class here
class Cellphone {
 public:
  Cellphone(const std::string &type, const std::string &number)
      : type_(type), number_(number) {}
  void Pair(std::unique_ptr<Speaker> speaker) { speaker_ = std::move(speaker); }
  void Display() const;

 private:
  std::string type_;
  std::string number_;
  std::unique_ptr<Speaker> speaker_;
};

#endif
