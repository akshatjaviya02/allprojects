#include <iostream>
#include <memory>
#include "cellphone.h"


// TODO
// provide your Cellphone "display" function definition here
void Cellphone::Display() const {
  std::cout << type_ << "\n" << number_ << std::endl;
  if (speaker_ == nullptr) {
    std::cout << "No speaker attached" << std::endl;
  } else {
    std::cout << speaker_->GetName() << " speaker" << std::endl;
  }
}
