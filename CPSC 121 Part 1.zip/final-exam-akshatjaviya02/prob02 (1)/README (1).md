# Cellphone Application
The cellphone application stores basic information about a cell phone.

# Instructions
Part of the code has been provided for you. You will find "TODO" statements throughout the files with basic instructions of what goes there. However, this README file contains more detailed instructions for each of those portions of the code.

## main
Update the `main` function to do the following.
1. Create a `Cellphone` object using its non-default constructor. You can pass the string "Android" for the cell phone type, and "555-555-5555" for the cell phone number
1. Create a `std::unique_ptr` to a `Speaker` object using the non-default constructor for the `Speaker`. You can pass the string "Bose" for the brand of speaker
1. Call the `Pair` function of the `Cellphone` object, and pass in the `Speaker` as the argument
1. Call the `Display` function of the `Cellphone` object

## Speaker class
The `Speaker` class has been provided for you. You do not need to modify this class.

## Cellphone class
Add a class named `Cellphone` that contains the following characteristics.
1. private data members - add three private data members - two members of type `std::string` to represent the type and number of the cell phone, and a `std::unique_ptr` to an object of type `Speaker` to represent the speaker that will be paired with the cell phone
1. constructor - add a public non-default constructor that accepts two constant references to `std::string` representing the cell phone type and number, and sets the private data members accordingly
1. `Pair` - create a member function named `Pair` that takes a unique pointer to a `Speaker` object, and does not return anything. This function sets the private data member for the speaker
1. `Display` - create a member function named `Display` that does not accept any parameters, nor does it return anything. Declare this function to be a constant function. This function prints out the cell phone type and number. In addition, if the speaker pointer has been set, then this function also prints out the name of the speaker. Otherwise, it prints "No speaker attached"

## Hints
1. Don't forget to declare `std::string` parameters as constant reference parameters for all member functions and constructors
1. For member functions that do not modify data members of the class, don't forget to declare these as constant functions

## Run the program
This lab includes a `Makefile` with a rule for `build`. You can invoke the `clang` compiler using the `make build` command, or by typing the following.
```
clang++ -std=c++17 *.cc -o main
```
Whichever you choose, your executable will be called `main`, and you can run your program by typing the following.
```
./main
```

## Sample output
This lab does not include a unit test; therefore, the command `make test` will not work. However, when you run your `main` executable, your program should output the following.
```
Android
555-555-5555
Bose speaker
```

# Submission checklist
1. Compiled the program (`make build`)
1. Ran the driver (`main`)
1. Manually checked for compilation and logical errors

# Code evaluation
Open the terminal and navigate to the folder that contains this exercise. Assuming you have pulled the code inside of `/home/student/midterm-tuffy` and you are currently in `/home/student` you can issue the following commands.
```
cd midterm-tuffy
```

You also need to navigate into the problem you want to answer. To access the files needed to answer problem 1, for example, you need to issue the following command.
```
cd prob01
```

When you want to answer another problem, you need to go back up to the parent folder and navigate into the next problem. Assuming you are currently in `prob01`, you can issue the following commands to go to the parent folder then go into another problem you want to answer; `prob02` for example.
```
cd ..
cd prob02
```

Use the `clang++` command (or ``make build``) to compile your code and the `./` command to run it. The sample code below shows how you would compile code saved in any source file to create the executable file `main`. Make sure you use the correct filenames required in this problem.  Take note that if you make any changes to your code, you will need to compile it first before you see changes when running it.
```
clang++ -std=c++17 *.cc -o main
./main
```

# Submission
We recommend pushing to GitHub frequently to back up your work.
