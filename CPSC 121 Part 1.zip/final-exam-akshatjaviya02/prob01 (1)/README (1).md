# Sports Application
The sports application fills two bobsledding teams with athletes to compete against each other, and also fills slots for two badminton athletes to compete against each other.

# Instructions
Part of the code has been provided for you. You will find "TODO" statements throughout the files with basic instructions of what goes there. However, this README file contains more detailed instructions for each of those portions of the code.

## main
Note that the `main()` function has mostly been provided for you. Find the two "TODO" statements in there and add the code described in the comment for the "TODO".

## Sport class
A shell for the Sport class has been provided for you. You need to add two pure virtual functions called `enroll` and `display` to the class, as described below.
1. `Enroll` - create a pure virtual function called `Enroll` that contains one parameter, a constant reference to a `std::string` representing an athlete's name, and does not return anything.
1. `Display` - create a pure virtual function called `Display` that does not accept any parameters, nor does it return anything. Declare this function to be a constant function.

## Competitive class
Add a class named `Competitive` that inherits from `Sport`. A competitive sport is one where one athlete competes against another in a singles match.
1. private data members - add two private data members, both of type `std::string` to represent the names of the two athletes who will be competing against each other
1. `Enroll` - override the parent `Enroll` function. This function adds both athletes to the competition, one at a time. The first time `Enroll` is called, it will set the name (parameter) to the first data member. The second time `Enroll` is called it will set the name (parameter) to the second data member. If both names have already been set, then display an error message. You can assume that the values of the name data members start as empty `std::string`s.
1. `Display` - override the parent `Display` function. This function prints out the names of the two athletes competing against each other in the format: Name1 vs. Name2

## Team class
The `Team` class has been provided for you. A team sport is one where a team of athletes compete against another team with the same number of athletes.

## Athlete class
Add a class named `Athlete` that contains the following characteristics.
1. private data member - add a private data member of type `std::string` to represent the name of the athlete
1. constructor - add a public non-default constructor that accepts a constant reference to a `std::string` representing the athlete's name, and sets the private data member to that name
1. `Join` - create a member function named `Join` that takes a pointer to a `Sport` object, and does not return anything. This function calls the `Enroll` function for the sport to enroll the `Athlete` in that sport

## Hints
1. Don't forget to declare `std::string` parameters as constant reference parameters for all member functions and constructors
1. For member functions that do not modify data members of the class, don't forget to declare these as constant functions

## Run the program
This lab includes a `Makefile` with a rule for `build`. You can invoke the `clang` compiler using the `make build` command, or by typing the following.
```
clang++ -std=c++17 *.cc -o main
```
Whichever you choose, your executable will be called `main`, and you can run your program by typing the following.
```
./main
```

## Sample output
This lab does not include a unit test; therefore, the command `make test` will not work. However, when you run your `main` executable, your program should output the following.
```
Dudley Stokes, Devon Harris, Michael White, Chris Stokes vs. Takao Sakai, Toshio Wakita, Yuji Yaku, Naomi Takewaki
Tai Tzu-ying vs. Chen Yufei
Both teams are full
Both athletes have already been registered
```

# Submission checklist
1. Compiled the program (`make build`)
1. Ran the driver (`main`)
1. Manually checked for compilation and logical errors

# Code evaluation
Open the terminal and navigate to the folder that contains this exercise. Assuming you have pulled the code inside of `/home/student/midterm-tuffy` and you are currently in `/home/student` you can issue the following commands.
```
cd midterm-tuffy
```

You also need to navigate into the problem you want to answer. To access the files needed to answer problem 1, for example, you need to issue the following command.
```
cd prob01
```

When you want to answer another problem, you need to go back up to the parent folder and navigate into the next problem. Assuming you are currently in `prob01`, you can issue the following commands to go to the parent folder then go into another problem you want to answer; `prob02` for example.
```
cd ..
cd prob02
```

Use the `clang++` command (or ``make build``) to compile your code and the `./` command to run it. The sample code below shows how you would compile code saved in any source file to create the executable file `main`. Make sure you use the correct filenames required in this problem.  Take note that if you make any changes to your code, you will need to compile it first before you see changes when running it.
```
clang++ -std=c++17 *.cc -o main
./main
```

# Submission
We recommend pushing to GitHub frequently to back up your work.
