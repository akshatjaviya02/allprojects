#ifndef SPORTS_H
#define SPORTS_H

#include <iostream>
#include <string>
#include <vector>

//------------------------------
// constants
//------------------------------

const int TEAM_SIZE = 4;

//------------------------------
// Sport class definition
//------------------------------

class Sport {
 public:
  // TODO
  // provide the Sport class pure virtual functions here
  void Enroll(const std::string &athlete_name);
  void Display() const;
};

//------------------------------
// Competitive class definition
//------------------------------

// TODO
// provide your Competitive class here
class Competitive : public Sport {
 public:
  void Enroll(const std::string &athlete_name);
  void Display() const;
  std::string GetName1() { return athlete1_; }
  std::string GetName2() { return athlete2_; }
  void SetName1(std::string name1) { athlete1_ = name1; }
  void SetName2(std::string name2) { athlete2_ = name2; }

 private:
  std::string athlete1_;
  std::string athlete2_;
};

//------------------------------
// Team class definition
//------------------------------

class Team : public Sport {
 private:
  int team_size_;
  std::vector<std::string> team1_;
  std::vector<std::string> team2_;

 public:
  Team(int size) : team_size_(size) {}
  void Enroll(const std::string &athlete_name);
  void Display() const;
};

//------------------------------
// Athlete class definition
//------------------------------

// TODO
// provide your Athlete class here
class Athlete {
 public:
  Athlete(const std::string &athlete_name1) : athlete3_(athlete_name1) {}
  void Join(Sport *sport) {
    sport->Enroll(athlete3_); 
  }

 private:
  std::string athlete3_;
};

#endif
