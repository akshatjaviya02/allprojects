#include "sports.h"
#include <iostream>
#include <string>

// TODO
// provide the "enroll" function definition for the Competitive class here
void Competitive::Enroll(const std::string &athlete_name) {
  if(athlete1_.size() == 0) {
    athlete1_ = athlete_name;
  } else if(athlete2_.size() == 0){
    athlete2_ = athlete_name;
  } else {
    std::cout << "Both athletes have already been registered" << std::endl;
  }
}
void Competitive::Display() const {
  std::cout << athlete1_ << " vs. " << athlete2_;
}
void Team::Enroll(const std::string &athlete_name) {
  if (team1_.size() < team_size_) {
    team1_.push_back(athlete_name);
  } else if (team2_.size() < team_size_) {
    team2_.push_back(athlete_name);
  } else {
    std::cout << "Both teams are full\n";
  }
}

void Team::Display() const {
  for (int i = 0; i < team1_.size(); i++) {
    if (i != 0) {
      std::cout << ", ";
    }
    std::cout << team1_[i];
  }
  std::cout << " vs. ";
  for (int i = 0; i < team2_.size(); i++) {
    if (i != 0) {
      std::cout << ", ";
    }
    std::cout << team2_[i];
  }
}
