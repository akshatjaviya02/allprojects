# Final Exam
## Content and Timing
This exam will evaluate your ability to apply the concepts discussed in the course by answering programming problems. You are expected to design your solution, implement your solution in C++, compile and run your program to solve the program, and debug your program to fix issues.

You have **1 hour** to answer two programming problems. You can push your code as many times as you want before the end of the exam time.

## General Instructions
This is an open notes exam. You are free to look at your notes, any of the resources we used in class, or any website. However, you are not allowed to talk to your classmates or any other person to get help with the exam. You should not help your classmates with the exam or share any information about the exam to anyone. Any form of cheating will not be tolerated and will result in a grade of 0 for the exam and disciplinary action.

You are free to use any editor and the command line to write, compile, and test your program. The suggested programming environments for you to use are CS50 Sandbox and Tuffix. The instructor will use `clang++` to check your programs when grading them, so make sure your code works with this compiler.

Instructors and lab assistants will not answer questions regarding interpreting syntax errors or debugging code.

## Problem and points
There are two programming problems that you need to complete.

1. Sports *(45 pts)*
1. Cellphone *(30 pts)*

If you get stuck on any one of the problems, it is highly recommended that you move on to other problems before spending too much time on one problem.

# Submission
Your answers will be submitted through GitHub and Gradescope. You can push your code as many times as you want before the end of the exam. I will check the last version that you pushed during the exam.

When you are done, verify you have pushed your code properly on GitHub. Simply refresh the webpage with your GitHub repo and click on the individual files to see that they have your latest changes.

Submit your code to Gradescope (via Canvas) as you would with your labs and milestones.

Before leaving the Zoom session, please send a message to your instructor who will verify that you submitted your exam properly.

# Good luck!

## Instructions for pushing code to GitHub

1. When everything runs correctly, let's copy your code into the Github repository. You can also do this as often as you want in order to back up and save your work. The first step is to add your code to what is called the staging area using git's `add` command. The parameter after `add` is the name of the file you want to add. There are cases when you have multiple changed files, so you can just type . (period) to add all modified files.

    ```
    git add .
    ```
1. Once everything is in the staging area, we use the `commit` command to tell git that we have added everything we need into the staging area.

    ```
    git commit
    ```
    Alternatively, you could add a comment to the `commit` command in order to skip the *nano* editor step described below.

    ```
    git commit -m "Finished prob01"
    ```
1. In case it asks you  to configure global variables for an email and name, just copy the commands it provides then replace the dummy text with your email and Github username.

    ```
    git config --global user.email "tuffy@csu.fullerton.edu"
    git config --global user.name "Tuffy Titan"
    ```
    When you're done, make sure you type `git commit` again.    
1. Git will ask you to describe what you have added to the staging area. By default, you will use a command-line based editor called *nano*. Go ahead and provide a description then press <kbd>Ctrl</kbd> + <kbd>x</kbd> to exit. Press <kbd>Y</kbd> to confirm that you want to make changes and then press <kbd>Enter</kbd>.
1. Lets push all changes to the Github repository using git's `push` command. Provide your Github username and password when you are asked.

    ```
    git push
    ```
1. When you finish the exercise, go back to Canvas and find the corresponding assignment. Submit your solution to Gradescope (via Canvas).
