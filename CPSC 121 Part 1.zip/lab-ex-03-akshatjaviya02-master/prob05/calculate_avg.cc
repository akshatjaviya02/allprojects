#include <vector>

double CalculateAvg(std::vector<double>& input) {
  // Complete this function.
}
