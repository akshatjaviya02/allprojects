#include <vector>

#ifndef CALCULATE_AVG_H
#define CALCULATE_AVG_H

// You do not need to edit this file.
double CalculateAvg(std::vector<double>& vector);

#endif  // CALCULATE_AVG_H
