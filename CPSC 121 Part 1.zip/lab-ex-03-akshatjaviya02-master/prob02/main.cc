#include <iostream>
#include <map>
#include <string>

int main() {
  std::string input;
  std::cout << "Enter text to analyze: ";
  std::getline(std::cin, input);

  // Your code here to analyze the input and let the user see what letters
  // are in it.
  std::string c1;
  bool flag = true;

  while (flag == true) {
    int count = 0;
    std::cout << "\nWhat character do you want stats on? ";
    std::cin >> c1;

    if (c1 == "quit") {
      flag = false;
    }
    if (flag == true) {
      for (int j = 0; j < input.size(); j++) {
        if (input[j] == c1[0]) {
          count++;
        }
      }
    }
    std::cout << "The character " << c1 << " appears " << count << " times.";
  }
  std::cout << "Goodbye!" << std::endl;
  return 0;
}
