#include "desaturate.h"
#include <iostream>
void Desaturate(graphics::Image& image) {
  // Your code here to desaturate the image.
  int width = image.GetWidth();
  int height = image.GetHeight();
  for (int x = 0; x < width; x++) {
    for (int y = 0; y < height; y++) {
      int red = image.GetRed(x, y);
      int green = image.GetGreen(x, y);
      int blue = image.GetBlue(x, y);
      int avg = (red + green + blue) / 3;
      image.SetRed(x, y, avg);
      image.SetGreen(x, y, avg);
      image.SetBlue(x, y, avg);
    }
  }
}
