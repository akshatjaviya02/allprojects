#include "tic_tac_toe.h"
#include <iostream>
#include <vector>

int CheckGame(std::vector<std::vector<int>>& game) {
  std::vector<int> full_b;
  // Your code here to determine if there was a return, a draw, or if the
  // game can continue.
  // checks all columns
  if (game[0][0] == 1 && game[0][1] == 1 && game[0][2] == 1) {
    return 1;
  }
  if (game[0][0] == 2 && game[0][1] == 2 && game[0][2] == 2) {
    return 2;
  }
  if (game[1][0] == 1 && game[1][1] == 1 && game[1][2] == 1) {
    return 1;
  }
  if (game[1][0] == 2 && game[1][1] == 2 && game[1][2] == 2) {
    return 2;
  }
  if (game[2][0] == 1 && game[2][1] == 1 && game[2][2] == 1) {
    return 1;
  }
  if (game[2][0] == 2 && game[2][1] == 2 && game[2][2] == 2) {
    return 2;
  }
  // check for the rows
  if (game[0][0] == 1 && game[1][0] == 1 && game[2][0] == 1) {
    return 1;
  }
  if (game[0][0] == 2 && game[1][0] == 2 && game[1][0] == 2) {
    return 2;
  }
  if (game[0][1] == 1 && game[1][1] == 1 && game[2][1] == 1) {
    return 1;
  }
  if (game[0][1] == 2 && game[1][1] == 2 && game[2][1] == 2) {
    return 2;
  }
  if (game[0][2] == 1 && game[1][2] == 1 && game[2][2] == 1) {
    return 1;
  }
  if (game[0][2] == 2 && game[1][2] == 2 && game[2][2] == 2) {
    return 2;
  }

  // check for diagonal
  if (game[0][0] == 1 && game[1][1] == 1 && game[2][2] == 1) {
    return 1;
  }
  if (game[0][0] == 2 && game[1][1] == 2 && game[2][2] == 2) {
    return 2;
  }

  // check for diagonal
  if (game[0][2] == 1 && game[1][1] == 1 && game[2][0] == 1) {
    return 1;
  }
  if (game[0][2] == 2 && game[1][1] == 2 && game[2][0] == 2) {
    return 2;
  }
  // all the tic_tac_toe full board
  for (int i = 0; i < 2; i++) {
    for (int j = 0; j < 2; j++) {
      full_b.push_back(game[i][j]);
    }
  }
  // check for over game
  for (int h = 0; h < full_b.size(); h++) {
    if (full_b.at(h) == 0) {
      return 0;
    }
  }
  return -1;
}
