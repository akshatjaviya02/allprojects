#include "cpputils/graphics/image.h"

void Mirror(graphics::Image& image);
