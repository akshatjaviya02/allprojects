#include "mirror.h"

void Mirror(graphics::Image& image) {
  // Your code here to mirror the image.
}
