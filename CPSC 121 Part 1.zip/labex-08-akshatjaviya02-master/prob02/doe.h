#include <iostream>
#include <string>
#include "joey.h"
#include "kangaroo.h"

#ifndef DOE_H
#define DOE_H

// Doe class here.
class Doe : public Kangaroo {
 public:
  Doe() : Kangaroo() {}
  Doe(std::string doe, std::string joey) : Kangaroo(doe), joey_(joey) {}
  Joey &GetJoey() { return joey_; }
  void Bounce() {
    num++;
    std::cout << GetName() << " goes boing" << std::endl;
    joey_.Bounce();
    Doe::SetBounceCount(num);
  }

 private:
  Joey joey_;
  int num = 0;
};

#endif  // DOE_H
