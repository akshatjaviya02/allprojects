
#ifndef JOEY_H
#define JOEY_H
#include <string>
#include "kangaroo.h"
// Joey class here.
class Joey : public Kangaroo {
 public:
  Joey(std::string joey) : Kangaroo(joey) { joey_ = joey; }
  Joey() {}

 private:
  std::string joey_;
};

#endif  // JOEY_H
