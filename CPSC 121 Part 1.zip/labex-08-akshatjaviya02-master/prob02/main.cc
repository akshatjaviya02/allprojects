// Include any headers you might need.
#include <iostream>
#include <string>
#include "doe.h"
#include "joey.h"
#include "kangaroo.h"

int main() {
  // 1. Ask the user for the doe's name, and the joey's name.
  // 2. Create a Doe with these names.
  // 3. Get a reference to the Doe's Joey.
  std::string joey, doe;
  std::cout << "What is the doe\'s name? ";
  std::cin >> doe;
  std::cout << "What is the joey\'s name? ";
  std::cin >> joey;
  Doe b1(doe, joey);
  Joey &b2 = b1.GetJoey();
  std::string answer;
  do {
    // 4. Bounce the Doe once and then the Joey once.
    b1.Bounce();
    b2.Bounce();
    // 5. Print a message about the number of bounces for the Doe and then the
    // Joey using the format from the README.
    std::cout << b1.GetName() << " has bounced " << b1.GetBounceCount()
              << " times. \n";
    std::cout << b2.GetName() << " has bounced " << b2.GetBounceCount()
              << " times. \n";

    // 6. Check if the user wants to bounce again.
    std::cout << "Do you want to bounce again? \"n\" to exit ";
    std::cin >> answer;

  } while (answer != "n");

  return 0;
}
