#ifndef KANGAROO_H
#define KANGAROO_H
#include <iostream>
#include <string>

// Kangaroo class here.
class Kangaroo {
 public:
  Kangaroo() : name_("James") {}
  Kangaroo(std::string name) : name_(name) {}
  std::string GetName() { return name_; }
  void SetName(std::string name) { name_ = name; }
  int GetBounceCount() { return count_; }
  void Bounce() {
    std::cout << name_ << " goes boing" << std::endl;
    count_++;
  }

 protected:
  void SetBounceCount(int count) { count_ = count; }

 private:
  std::string name_;
  int count_ = 0;
};

#endif  // KANGAROO_H
