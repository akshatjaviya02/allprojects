#ifndef BUTTON_H
#define BUTTON_H
#include <iostream>
#include <string>
#include "rect.h"
// Button class here
class Button {
 public:
  Button() : button_name_("random"), rect_(0, 0, 100, 30) {}
  Button(std::string button_name, Rect rect)
      : button_name_(button_name), rect_(rect) {}
  virtual bool GetActive() { return active_; }
  virtual void SetActive(bool active) { active_ = active; }
  Rect GetRect() { return rect_; }
  std::string GetName() { return button_name_; }
  virtual void Click() { std::cout << "Clicked " << button_name_ << std::endl; }

 private:
  bool active_ = false;
  std::string button_name_;
  Rect rect_;
};

#endif  // BUTTON_H
