#ifndef TOGGLE_BUTTON_H
#define TOGGLE_BUTTON_H
#include <iostream>
#include <string>
#include "rect.h"
// ToggleButton class here.
class ToggleButton : public Button {
 public:
  ToggleButton() : Button(){};
  ToggleButton(std::string toggle_button_text, Rect rect)
      : Button(toggle_button_text, rect) {}
  bool GetEnabled() {
    SetActive(active);
    return active;
  }
  void Click() override {
    if (!active) {
      std::cout << "Clicked " << GetName() << " (enabled)";
      active = true;
    } else {
      std::cout << "Clicked " << GetName() << " (disabled)";
      active = false;
    }
  }

 private:
  bool active = false;
};

#endif  // TOGGLE_BUTTON_H
