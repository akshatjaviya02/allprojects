#include "rect.h"
bool Rect::Contains(int x, int y) {
  bool scan = false;
  for (int a = 0; a <= width_; a++) {
    for (int b = 0; b <= height_; b++) {
      int presentx = x_ + a;
      int presenty = y_ + b;
      if (presentx == x && presenty == y) {
        scan = true;
        return scan;
      }
    }
  }
  return scan;
}
