#ifndef RECT_H
#define RECT_H

// Rect class here.
class Rect {
 public:
  Rect(int x, int y, int width, int height)
      : x_(x), y_(y), width_(width), height_(height) {}
  int GetX() { return x_; }
  int GetY() { return y_; }
  int GetWidth() { return width_; }
  int GetHeight() { return height_; }
  bool Contains(int x, int y);

 private:
  int x_;
  int y_;
  int width_;
  int height_;
};

#endif  // RECT_H
