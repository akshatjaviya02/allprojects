#include "pointer_utils.h"
#include <iostream>

void Negate(bool *value) {
  // Your code here.
  *value = !*value;
}

void Increment(int *number) {
  // Your code here.
  *number += 1;
}

double ComputeSum(double *first, double *second) {
  // Your code here. return 0 is a placeholder so the program compiles.
  return *first + *second;
}

void Swap(int *first, int *second) {
  // Your code here.
  int num;
  num = *first;
  *first = *second;
  *second = num;
}

void MakeSus(std::string *player) {
  // Your code here.
  *player += " is sus";
}

std::string *GetLongestString(std::vector<std::string> *strings) {
  // Your code here. return nullptr is a palceholder so the program compiles.
  int max_num = 0;
  int index = 0;
  if ((*strings).size() == 0) {
    return nullptr;
  }
  for (int i = 0; i < (*strings).size(); i++) {
    if ((*strings)[i].size() > max_num) {
      max_num = (*strings)[i].size();
      index = i;
    }
  }
  return &(strings->at(index));
}
