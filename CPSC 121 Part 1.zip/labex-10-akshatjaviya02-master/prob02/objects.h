#include "cpputils/graphics/image.h"

#ifndef OBJECTS_H
#define OBJECTS_H

// Define your object classes here.
class SolidObject {
 private:
  int x_;
  int y_;
  int width_;
  int height_;
  graphics::Image *my_image_;

 public:
  SolidObject(int x, int y, int width, int height, graphics::Image *my_image)
      : x_(x), y_(y), width_(width), height_(height), my_image_(my_image) {}
  int GetWidth() const { return width_; }
  int GetHeight() const { return height_; }
  int GetX() const { return x_; }
  int GetY() const { return y_; }
  void SetX(int x) { x_ = x; }
  void SetY(int y) { y_ = y; }
  virtual void Draw() const = 0;
  bool CollidesWith(const SolidObject *solidobject);

 protected:
  graphics::Image *GetImage() const { return my_image_; }
};
class Brick : public SolidObject {
 private:
  graphics::Color color_;

 public:
  Brick(int width, int height, graphics::Color color, graphics::Image *my_image)
      : SolidObject(0, 0, width, height, my_image), color_(color) {}
  void Draw() const override;
};
class Paddle : public Brick {
 public:
  Paddle(int width, int height, graphics::Image *my_image)
      : Brick(width, height, graphics::Color(50, 50, 50), my_image) {}
};
class Ball : public SolidObject {
 public:
  Ball(int diameter, graphics::Image *my_image)
      : SolidObject(0, 0, diameter, diameter, my_image) {}
  void Draw() const override;
};
#endif  // OBJECTS_H
