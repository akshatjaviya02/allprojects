// Implement your Object classes here.
#include "objects.h"
bool SolidObject::CollidesWith(const SolidObject* solidobject) {
  if ((solidobject->GetWidth() == 0 || solidobject->GetHeight() == 0) ||
      (GetWidth() == 0 || GetHeight() == 0)) {
    return false;
  } else {
    return !(GetX() > solidobject->GetX() + solidobject->GetWidth() ||
             solidobject->GetX() > GetX() + GetWidth() ||
             GetY() > solidobject->GetY() + solidobject->GetHeight() ||
             solidobject->GetY() > GetY() + GetHeight());
  }
}
void Brick::Draw() const {
  int x = GetX();
  int y = GetY();
  int width = GetWidth();
  int height = GetHeight();
  graphics::Image* brick = GetImage();
  brick->DrawRectangle(x, y, width, height, color_);
}
void Ball::Draw() const {
  int r = GetHeight() / 2;
  int x = GetX();
  int y = GetY();
  graphics::Image* ball = GetImage();
  ball->DrawCircle(x + r, y + r, r, graphics::Color(210, 25, 25));
}
