#include "game.h"

// Create and start the Breakout game. You do not need to modify this code.
int main() {
  Game game;
  game.Initialize();
  game.Start();
}
