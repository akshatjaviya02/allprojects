#include <iostream>
#include <vector>

#include "print_vector_reverse.h"

int main() {
  int size;
  std::vector<int> vector;

  std::cout << "Enter an integer for the size of the vector: ";
  std::cin >> size;
  std::cout << "Inputs for the vector:\n";
  for (int i = 0; i < size; i++) {
    std::cout << "Enter the integer for index " << i << ": ";
    // TODO:
    // Assign values from cin into indicies of the vector.
  }
  // TOD:
  // Call your PrintVectorReverse function and pass the necessary parameters.

  return 0;
}
