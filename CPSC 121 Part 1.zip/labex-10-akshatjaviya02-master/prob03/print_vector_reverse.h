#include <vector>

void PrintVectorReverse(std::vector<int>* vector);
