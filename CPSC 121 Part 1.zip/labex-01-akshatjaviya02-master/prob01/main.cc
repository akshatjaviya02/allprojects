#include <iostream>
#include <string>

int main()
{
  double user_number1;
  std::string user_name, user_name1, user_animal, user_emotion;
  int user_number;
  char user_letter;
  std::cout << "Welcome to MadLibs!\n";
  std::cout << "Name: ";
  getline(std::cin,user_name);
  std::cout << "Emotion: ";
  std::cin >> user_emotion;
  std::cout << "Animal: ";
  std::cin >> user_animal;
  std::cout << "Number: ";
  std::cin >> user_number;
  std::cout << "Letter: ";
  std::cin >> user_letter;
  std::cout << "Floating point number between 0 and 100: ";
  std::cin >> user_number1;
  std::cout << "Name: ";
  std::cin >> user_name1;
  std::cout << "Dear " << user_name << ", \n" << "I am " << user_emotion << " that I was not able to complete my homework on time. My pet " << user_animal
            << " ate my textbook, and I was only able to retrieve " << user_number << " pages from its jaws. I hope I can get at least a " << user_letter
            << " grade because I've done " << user_number1 << "% of the work. \n" << "Sincerely, \n" << user_name1 <<std::endl;
  return 0;
}
