#include <iostream>
#include <cmath>
#include <iomanip>

int main ()
{
  double const TAX = 0.075;
  double meal_cost, tip_percentage, taxes, tip, total;
  int const EQ = 20;
  int const DEC = 2;
  // User input the values
  std::cout << "Please input meal cost: ";
  std::cin >> meal_cost;
  std::cout << "Please input tip percentage: ";
  std::cin >> tip_percentage;
  // Calculations
  taxes = meal_cost * TAX;
  tip = (tip_percentage / 100) * (meal_cost);
  total = meal_cost + taxes + tip;
  std::cout << std::endl;
  std::cout << "Restaurant Bill" << std::endl;
  // The for loop would print "="
  for(int i = 0; i < EQ; i++)
  {
    std::cout << "=";
  }
  std::cout << std::endl;
  std::cout << "Subtotal: $" << std::setprecision(2) << std::fixed << meal_cost << std::endl;
  std::cout << "Taxes: $" << std::setprecision(2) << std::fixed << taxes << std::endl;
  std::cout << "Tip: $" << std::setprecision(2) << std::fixed << tip << std::endl;
  // The for loop would print "="
  for(int i = 0; i < EQ; i++)
  {
    std::cout << "=";
  }
  std::cout << std::endl;
  std::cout << "Total: $" << std::setprecision(2) << std::fixed << total << std::endl;
  return 0;
}
