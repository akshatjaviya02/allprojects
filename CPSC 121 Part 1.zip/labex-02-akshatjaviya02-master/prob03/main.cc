#include <iostream>

int main() {
  int pep, oni, jal;
  std::cout << "How many pepperoni do you want? ";
  std::cin >> pep;
  std::cout << "How many onions do you want? ";
  std::cin >> oni;
  std::cout << "How many jalapenos do you want? ";
  std::cin >> jal;
  if ((pep == 0) && (oni == 0) && (jal == 0)) {
    std::cout << "Looks like you weren't hungry. Maybe next time?" << std::endl;
  } else {
    std::cout << "Here's your pizza!" << std::endl;
    std::cout << "Pizza with: ";
    for (int p = 0; p < pep; p++) {
      std::cout << "pepperoni ";
    }
    for (int o = 0; o < oni; o++) {
      std::cout << "onion ";
    }
    for (int j = 0; j < jal; j++) {
      std::cout << "jalapeno ";
    }
    std::cout << std::endl;
  }
}
