#include <iostream>
#include <string>

#include "cpputils/graphics/image.h"
#include "pizza.h"

using graphics::Image;

int main() {
  std::cout << "Welcome to PizzaMaker 2.0!" << std::endl;
  char i1, i2, i3, i4, i5, i6;
  // Add your code here to ask the user what kind of pizza they want,
  // and create that pizza for them.
  std::cout << "Would you like a pizza?" << std::endl;
  std::cout << "(y/n): ";
  std::cin >> i1;
  if (i1 == 'y') {
    Image my_image(500, 500);
    AddCrust(my_image);
    std::cout << "Would you like  tomato sauce?" << std::endl;
    std::cout << "(y/n): ";
    std::cin >> i2;
    if (i2 == 'y') {
      AddSauce(my_image);
    }
    std::cout << "Would you like cheese with that?" << std::endl;
    std::cout << "(y/n): ";
    std::cin >> i3;
    if (i3 == 'y') {
      AddCheese(my_image);
    }
    std::cout << "Would you like pepperoni?" << std::endl;
    std::cout << "(y/n): ";
    std::cin >> i4;
    if (i4 == 'y') {
      AddPepperoni(my_image);
    }
    std::cout << "Would you like jalapeno with that?" << std::endl;
    std::cout << "(y/n): ";
    std::cin >> i5;
    if (i5 == 'y') {
      AddJalapeno(my_image);
    }
    std::cout << "Would you like onion?" << std::endl;
    std::cout << "(y/n): ";
    std::cin >> i6;
    if (i6 == 'y') {
      AddOnion(my_image);
    }
    my_image.SaveImageBmp("pizza.bmp");
  }
  std::cout << "Great! Your pizza is at pizza.bmp. Enjoy!" << std::endl;
  return 0;
}
