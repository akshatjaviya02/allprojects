#ifndef INPUT_H
#define INPUT_H

// Your code here to define the function prototype.
bool GetYesOrNoInput();

#endif  // INPUT_H
