// Your code here to implement the function.
#include "input.h"
#include <iostream>
#include <string>
bool GetYesOrNoInput() {
  std::string user_input;
  std::cin >> user_input;
  while (user_input != "yes" && user_input != "no") {
    std::cout << "I didn't understand. Try again";
    std::cin >> user_input;
  }

  if (user_input == "yes") {
    return true;
  } else {
    return false;
  }
}
