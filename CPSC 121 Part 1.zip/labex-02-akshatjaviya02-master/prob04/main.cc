#include <iostream>

int main() {
  char expression;
  int first_input, second_input, answer;
  std::cout << "Please enter in the operation (+, -, *, /): ";
  std::cin >> expression;
  std::cout << "Please input the first number: ";
  std::cin >> first_input;
  std::cout << "Please input the second number: ";
  std::cin >> second_input;
  if (expression == '+' || expression == '-' || expression == '*' ||
      expression == '/') {
    if (expression == '+') {
      answer = first_input + second_input;
      std::cout << "You chose to add: " << first_input << " " << expression
                << " " << second_input << " = " << answer << std::endl;
    } else if (expression == '-') {
      answer = first_input - second_input;
      std::cout << "You chose to subtract: " << first_input << " " << expression
                << " " << second_input << " = " << answer << std::endl;
    } else if (expression == '*') {
      answer = first_input * second_input;
      std::cout << "You chose to multiply: " << first_input << " " << expression
                << " " << second_input << " = " << answer << std::endl;
    } else if (expression == '/') {
      answer = first_input / second_input;
      std::cout << "You chose to divide: " << first_input << " " << expression
                << " " << second_input << " = " << answer << std::endl;
    }
  } else {
    std::cout << "Invalid operation type.\n";
  }
}
