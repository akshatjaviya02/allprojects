#include <iostream>
#include <string>

#ifndef POGIL_H
#define POGIL_H

// TODO: Student, PogilGroup classes and PrintGroupInformation function.

#endif  // POGIL_H
