#include <iostream>
#include "person.h"

int main() {
  std::string great_grandparent_name, grandparent_name, parent_name, kid_name;
  std::cout << "What is the great-grandparent's name? ";
  std::cout << "What is the grandparent's name? ";
  std::cout << "What is the parent's name? ";
  std::cout << "What is the kid's name? ";
  std::cout << "The family tree is: \n";
  std::cin >> great_grandparent_name;
  std::cin >> grandparent_name;
  std::cin >> parent_name;
  std::cin >> kid_name;
  Person greatgrandparent(great_grandparent_name);
  Person grandparent(grandparent_name);
  greatgrandparent.SetChild(&grandparent);
  Person parent(parent_name);
  grandparent.SetChild(&parent);
  Person kid(kid_name);
  parent.SetChild(&kid);
  greatgrandparent.Print();
  return 0;
}
