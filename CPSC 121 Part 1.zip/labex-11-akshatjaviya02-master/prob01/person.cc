#include "person.h"
void Person::Print() const {
  if (GetChild() == nullptr) {
    std::cout << name_ << "\n";
  } else {
    std::cout << name_ << ", parent of ";
    ptr_->Print();
  }
}
