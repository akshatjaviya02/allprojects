#include <iostream>
#include <string>

#ifndef PERSON_H
#define PERSON_H

// TODO: put your Person class here.
class Person {
 public:
  Person(std::string name) : name_(name) {}
  std::string GetName() const { return name_; }
  Person *GetChild() const { return ptr_; }
  void SetChild(Person *ptr) { ptr_ = ptr; }
  void Print() const;

 private:
  std::string name_;
  Person *ptr_ = nullptr;
};

#endif  // PERSON_H
