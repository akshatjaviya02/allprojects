#include "raindrop.h"

// TODO: Implement your Raindrop class here.
void Raindrop::Fall() { y_ += speed_; }
void Raindrop::Draw() { raindrop_->DrawCircle(x_, y_, 10, red); }
