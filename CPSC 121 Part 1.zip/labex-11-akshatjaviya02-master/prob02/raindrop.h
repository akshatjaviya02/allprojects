#include "cpputils/graphics/image.h"

#ifndef RAINDROP_H
#define RAINDROP_H
const graphics::Color red(255, 0, 0);
// TODO: Define your Raindrop class here.
class Raindrop {
 public:
  Raindrop(graphics::Image *raindrop, int x, int y, int speed)
      : raindrop_(raindrop), x_(x), y_(y), speed_(speed) {}
  int GetY() const { return y_; }
  void Fall();
  void Draw();

 private:
  graphics::Image *raindrop_;
  int x_;
  int y_;
  int speed_;
};
#endif  // RAINDROP_H
