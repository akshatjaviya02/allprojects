#include "rainstorm.h"
#include <iostream>
#include <random>
#include <vector>
#include "raindrop.h"

// Constants you can use in your program.
const int kRaindropSize = 10;
const int kImageSize = 300;
const int kFastRate = 5;
const int kSlowRate = 3;
const graphics::Color kWhite(255, 255, 255);

// Provided function to calculate a raindrop's initial state. Pass pointers to
// a x coordianet, a y coordinate, and a integer rate of fall.
void CalculateRandomRaindropParams(int *x, int *y, int *rate) {
  const int kFastRate = 5;
  const int kSlowRate = 3;
  *x = rand() % kImageSize;
  *y = rand() % kImageSize;
  *rate = rand() % 2 ? kSlowRate : kFastRate;
}

Rainstorm::~Rainstorm() {
  // Remove itself as an animation event listener.
  image_.RemoveAnimationEventListener(*this);

  // TODO:
  // Deallocate all dynamically allocated memory.
  for (int i = 0; i < RainVec_.size(); i++) {
    delete RainVec_[i];
  }
}

// Initializes the Rainstorm class.
void Rainstorm::Initialize(int raindrop_count) {
  // Create the image to be 300x300px. Do not change the size.
  image_.Initialize(kImageSize, kImageSize);
  // Adds itself as an animation event listener to the image.
  image_.AddAnimationEventListener(*this);

  // TODO:
  // Create the integer parameter number of Raindrop* by dynamically
  // allocating memory. Use the provided function,
  // CalculateRandomRaindropParams, to get the initial x, y and rate.
  int x;
  int y;
  int rate;
  for (int i = 0; i < raindrop_count; i++) {
    CalculateRandomRaindropParams(&x, &y, &rate);
    Raindrop *raindrop = new Raindrop(&image_, x, y, rate);
    raindrop->Draw();
    RainVec_.push_back(raindrop);
  }
}

void Rainstorm::Start() {
  // Feel free to rename the window.
  image_.ShowUntilClosed("Rainy day");
}

void Rainstorm::OnAnimationStep() {
  // TODO:
  // Clear the image by drawing a white rectangle across the whole background.
  image_.DrawRectangle(0, 0, kImageSize, kImageSize, kWhite);
  // TODO:
  // For each Raindrop* in the vector, ask it to Fall(), then check its
  // y coordinate is still within the image bounds. If it is within bounds,
  // Draw() it, otherwise delete it and dynamically allocate memory for a new
  // Raindrop*, replacing the old Raindrop* at that location with the new one,
  // using CalculateRandomRaindropParams and starting y at 0.
  int x, y, rate;
  for (int i = 0; i < RainVec_.size(); i++) {
    RainVec_[i]->Fall();
    if (RainVec_[i]->GetY() < 300) {
      RainVec_[i]->Draw();
    } else {
      delete RainVec_[i];
      CalculateRandomRaindropParams(&x, &y, &rate);
      Raindrop *raindrops = new Raindrop(&image_, x, 0, rate);
      raindrops->Draw();
      RainVec_.at(i) = raindrops;
    }
  }
  // TODO:
  // Refresh the drawing using Image::Flush.
  image_.Flush();
}
