#include "rainstorm.h"
int main() {
  Rainstorm rain;
  rain.Initialize(50);
  rain.OnAnimationStep();
  rain.Start();
  return 0;
}
