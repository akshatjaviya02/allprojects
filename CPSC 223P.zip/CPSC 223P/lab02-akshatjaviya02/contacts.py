# Name: Akshat Javiya
# Date: 02/03/2022
# Purpose: Multiple functions to print, modify, add, and delete contacts
def print_list(contact):
    '''Prints the contact list'''
    print("================== CONTACT LIST ==================\n")
    print("Index   First Name            Last Name\n")
    print("======  ====================  ====================\n")
    for i in range(len(contact)):
        print(f'{str(i):8}{contact[i][0]:22}{contact[i][1]:22}')

def add_contact(contact):
    '''Adds the contacts to list'''
    firstname = input("Enter first name: ")
    lastname = input("Enter last name : ")
    contact.append([firstname, lastname])
    return contact

def modify_contact(contact):
    '''Modify the contact'''
    edit = int(input("Enter the index to edit the contact: "))
    if len(contact) < edit:
        print("Invalid index number.")
        return contact
    else:
        Nfirstname = input("Enter first name: ")
        Nlastname = input("Enter last name: ")
        contact[edit] = [Nfirstname, Nlastname]
        return contact

def delete_contact(contact):
    '''Delete the contact'''
    edit = int(input("Enter the index to edit the contact: "))
    if len(contact) < edit:
        print("Invalid index number.")
        return contact
    else:
        contact.pop(edit)
        return contact
