# Name: Akshat Javiya
# Date: 02/03/2022
# File Purpose: Lab02 main program driver program

from contacts import *

contact = []
boolean = True
while boolean :
    print("      *** TUFFY TITAN CONTACT MAIN MENU\n")
    print("1. Print list\n2. Add contact\n3. Modify contact\n4. Delete contact\n5. Exit the program\n")
    userinput = int(input("Enter menu choice: "))
    if userinput == 1 :
        print_list(contact)
    elif userinput == 2 :
        contact = add_contact(contact)
        print("\n")
    elif userinput == 3 :
        contact = modify_contact(contact)
        print("\n")
    elif userinput == 4 :
        contact = delete_contact(contact)
        print("\n")
    elif userinput == 5 :
        break
