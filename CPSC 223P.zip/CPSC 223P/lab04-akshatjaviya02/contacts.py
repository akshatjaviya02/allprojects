import json
class Contacts():
    '''contacts class'''

    def __init__(self, /, *, filename):
        '''init contacts class'''
        self.data = {}
        self.filename = filename
        try:
            f = open(self.filename)
            self.data = json.load(f)
            f.close()
        except FileNotFoundError :
            return None
    def add_contact(self, /, *, id, first_name, last_name, ):
        '''Adds the contacts to dictionary'''
        if id in self.data.keys():
            s = "error"
            return s
        else:
            self.data[id] = [first_name, last_name]
            self.data = {val[0] : val[1] for val in sorted(self.data.items(),
                                                    key=lambda x: (x[1], x[0]))}

            S = json.dumps(self.data)
            F = open(self.filename, "w")
            F.write(S)
            F.close()
            return self.data.get(id)
    def modify_contact(self, /, *, id, first_name, last_name):
        '''Modify the contact'''
        if id in self.data.keys():
            self.data.update({id: [first_name, last_name]})
            self.data = {val[0] : val[1] for val in sorted(self.data.items(),
                                                    key=lambda x: (x[1], x[0]))}

            S = json.dumps(self.data)
            F = open(self.filename, "w")
            F.write(S)
            F.close()
            return self.data.get(id)
        else:
            s = "error"
            return s
    def delete_contact(self, /, *, id):
        '''Delete the contact'''
        if id in self.data.keys():
            removed = self.data.pop(id)
            S = json.dumps(self.data)
            F = open(self.filename, "w")
            F.write(S)
            F.close()
            return removed
        else:
            s = "error"
            return s
    def write_data(self, /, *, data, filename):
        '''Writes to the file'''
        S = json.dumps(self.data)
        F = open(self.filename, "w")
        F.write(S)
        F.close()
