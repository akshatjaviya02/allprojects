# Name: Akshat Javiya
# Date: 2/13/2022
# File Purpose: Lab04 main program driver program

from contacts import *

contact = {}
boolean = True
while True :
    print("      *** TUFFY TITAN CONTACT MAIN MENU\n")
    print("1. Add contact\n")
    print("2. Modify contact\n")
    print("3. Delete contact\n")
    print("4. Print list\n")
    print("5. Find contact\n")
    print("6. Exit the program\n")
    userinput = int(input("Enter menu choice: "))
    if userinput == 1 :
        id = input("Enter phone number: ")
        first_name = input("Enter first name: ")
        last_name = input("Enter last name : ")
        if id.isnumeric():
            id = int(id)
            output =  add_contact(contact, id=id, first_name=first_name, last_name=last_name)
            if output == "error":
                print("Phone number already exists.\n")
            else:
                print("Added:", output)
        else:
            print("Invalid input,")
        print("\n")
    elif userinput == 2 :
        id = input("Enter phone number: ")
        first_name = input("Enter first name: ")
        last_name = input("Enter last name: ")
        if id.isnumeric():
            id = int(id)
            output2 = modify_contact(contact, id=id, first_name=first_name, last_name=last_name)
            if output2 == "error":
                print("Phone number does not exist.\n")
            else:
                print("Modified", output2)
        else:
            print("Invalid input,")
        print("\n")
    elif userinput == 3 :
        id = input("Enter phone number: ")
        if id.isnumeric():
            id = int(id)
            output3 = delete_contact(contact, id=id)
            if output3 == "error":
                print("Invalid phone number.")
            else:
                print("Deleted: ", output3)
        else:
            print("Invalid input,")
        print("\n")
    elif userinput == 4 :
        print("================== CONTACT LIST ======================\n")
        print("Last Name             First Name            Phone\n")
        print("====================  ====================  ==========\n")
        print_list(contact)
        print("\n")
    elif userinput == 5 :
        find = input("Enter search string: ")
        sorted_contact = find_contact(contact, find=find)
        print("================== FOUND CONTACT(S) ======================\n")
        print("Last Name             First Name            Phone\n")
        print("====================  ====================  ==========\n")
        print_list(sorted_contact)
        print("\n")
    elif userinput == 6 :
        break
