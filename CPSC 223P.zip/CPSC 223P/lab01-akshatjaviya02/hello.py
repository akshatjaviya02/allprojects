# Name: Akshat Javiya
# Date: 1/21/2022
# File Purpose: Multiple hello functions
def helloworld():
    return "Hello World!"
def helloname(name):
    return "Hello " + name + "!"
