# Name: Akshat Javiya
# Date: 1/21/2022
# File Purpose: Lab01 main program driver program

from hello import *

print("*** TUFFY TITAN HELLO PROGRAM ***")
print(helloworld())
print(helloname("Steve"))
