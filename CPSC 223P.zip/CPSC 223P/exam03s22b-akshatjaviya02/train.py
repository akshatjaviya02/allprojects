class Train:
    def __init__(self, /, *, color , motor_type):
        Train.track_gauge = "Standard"
        self.color = color
        self.motor_type = motor_type
        self.max_cars = 10
class Passenger(Train):
    train_classification = Train
    """docstring forPassenger."""

    def __init__(self, /, *, color , motor_type, axel_load):
        super().__init__(color=color , motor_type=motor_type)
        Passenger.train_classification= "Passenger"
        self.axel_load = axel_load
class Freight(Train):
    """docstring for Freight."""
    train_classification = "Freight"

    def __init__(self, /, *, color , motor_type, axel_load):
        super().__init__(color=color , motor_type=motor_type)
        self.axel_load = axel_load
class Metro(Passenger):
    def __init__(self,/, *,  axel_load, motor_type, color):
        super().__init__(axel_load=axel_load, motor_type=motor_type, color=color)
        Metro.train_type = "Metro"
        Metro.chassis_length = 70
class Amtrak(Passenger):
    """docstring for Amtrak."""
    def __init__(self, /, *, axel_load , motor_type, color):
        super().__init__(axel_load=axel_load, motor_type=motor_type, color=color)
        Amtrak.train_type = "Amtrak"
        Amtrak.chassis_length = 80
class Box(Freight):
    """docstring for Box."""

    def __init__(self, /, *, color , motor_type, axel_load):
        super().__init__(axel_load=axel_load, motor_type=motor_type, color=color)
        Box.train_type = "Box"
        Box.chassis_length = 90
class Container(Freight):
    """docstring forContainer."""

    def __init__(self, /, *, color , motor_type, axel_load):
        super().__init__(axel_load=axel_load, motor_type=motor_type, color=color)
        Container.train_type = "Container"
        Container.chassis_length = 100
