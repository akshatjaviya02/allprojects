# Name: Akshat Javiya
# Date: 04/28/2022
# Purpose: unit test for si.py
import unittest
import io
from si import SimpleInteger

class Test01_add_valid_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test01 *** FUNCTION CALL: Test01 = SimpleInteger() *** EXPECT: add(5, 6) == 11  ***
        """
        Test01 = SimpleInteger()
        value = Test01.add(5, 6)
        self.assertEqual(11, value)
        print()
class Test02_add_invalid_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test02 *** FUNCTION CALL: Test02 = SimpleInteger() *** EXPECT: add(3.5, 6) == None  ***
        """
        Test02 = SimpleInteger()
        value = Test02.add(3.5, 6)
        self.assertEqual(None, value)
        print()
class Test03_subtract_valid_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test03 *** FUNCTION CALL: Test03 = SimpleInteger() *** EXPECT: subtract(9, 6) == 3  ***
        """
        Test03 = SimpleInteger()
        value = Test03.subtract(9, 6)
        self.assertEqual(3, value)
        print()
class Test04_subtract_invalid_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test04 *** FUNCTION CALL: Test04 = SimpleInteger() *** EXPECT: subtract(9.5, 6) == None  ***
        """
        Test04 = SimpleInteger()
        value = Test04.subtract(9.5, 6)
        self.assertEqual(None, value)
        print()
class Test05_multiply_valid_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test05 *** FUNCTION CALL: Test05 = SimpleInteger() *** EXPECT: multiply(2, 6) == 12  ***
        """
        Test05 = SimpleInteger()
        value = Test05.multiply(2, 6)
        self.assertEqual(12, value)
        print()
class Test06_multiply_invalid_data (unittest.TestCase):
    def test_list_int(self):
        """
        *** Test06 *** FUNCTION CALL: Test06 = SimpleInteger() *** EXPECT: subtract(2.2, 6) == None  ***
        """
        Test06 = SimpleInteger()
        value = Test06.multiply(2.2, 6)
        self.assertEqual(None, value)
        print()
class Test07_isequal_valid_true_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test07 *** FUNCTION CALL: Test07 = SimpleInteger() *** EXPECT: isequal(6, 6) == True  ***
        """
        Test07 = SimpleInteger()
        value = Test07.isequal(6, 6)
        self.assertEqual(True, value)
        print()

class Test08_isequal_valid_false_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test08 *** FUNCTION CALL: Test08 = SimpleInteger() *** EXPECT: isequal(8, 6) == False  ***
        """
        Test08 = SimpleInteger()
        value = Test08.isequal(8, 6)
        self.assertEqual(False, value)
        print()
class Test09_isequal_invalid_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test09 *** FUNCTION CALL: Test09 = SimpleInteger() *** EXPECT: isequal(8.5, 6) == None  ***
        """
        Test09 = SimpleInteger()
        value = Test09.isequal(8.5, 6)
        self.assertEqual(None, value)
        print()
class Test10_isgreaterthan_valid_true_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test10 *** FUNCTION CALL: Test10 = SimpleInteger() *** EXPECT: isgreaterthan(9, 6) == True  ***
        """
        Test10 = SimpleInteger()
        value = Test10.isgreaterthan(9, 6)
        self.assertEqual(True, value)
        print()

class Test08_isequal_valid_false_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test11 *** FUNCTION CALL: Test11 = SimpleInteger() *** EXPECT: isgreaterthan(3, 6) == False  ***
        """
        Test11 = SimpleInteger()
        value = Test11.isgreaterthan(3, 6)
        self.assertEqual(False, value)
        print()
class Test12_isgreaterthan_invalid_data(unittest.TestCase):
    def test_list_int(self):
        """
        *** Test12 *** FUNCTION CALL: Test12 = SimpleInteger() *** EXPECT: isgreaterthan(3, 6) == None  ***
        """
        Test12 = SimpleInteger()
        value = Test12.isgreaterthan(3.5, 6)
        self.assertEqual(None, value)
        print()
if __name__ == '__main__':
    with open('test.txt', "w") as f:
        runner = unittest.TextTestRunner(f)
        unittest.main(testRunner=runner)
