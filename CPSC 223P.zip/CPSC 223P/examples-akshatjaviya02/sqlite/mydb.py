import sqlite3
import os

def create_db(db_name):
    #remove old, create new, and connect to database
    if os.path.exists(db_name):
      os.remove(db_name)
    con = sqlite3.connect(db_name)
    cur = con.cursor()

    #create customers table
    cur.execute('''CREATE TABLE IF NOT EXISTS customers (
        customer_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        last_name TEXT NOT NULL,
        first_name TEXT NOT NULL,
        tax_rate REAL NOT NULL)''')

    #create products table
    cur.execute('''CREATE TABLE IF NOT EXISTS products (
        product_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        taxable INTEGER NOT NULL)''')

    #create orders table
    cur.execute('''CREATE TABLE IF NOT EXISTS orders (
        order_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        customer_id INTEGER NOT NULL REFERENCES customers(customer_id) ON DELETE CASCADE,
        subtotal REAL NOT NULL DEFAULT 0.0,
        tax REAL NOT NULL DEFAULT 0.0,
        total REAL NOT NULL DEFAULT 0.0)''')

    #create items table
    cur.execute('''CREATE TABLE IF NOT EXISTS items (
        order_id INTEGER NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
        product_id INTEGER NOT NULL REFERENCES products(product_id) ON DELETE CASCADE,
        qty INTEGER NOT NULL)''')

    #commit and close
    con.commit()
    con.close()

def add_customer(db_name, last_name, first_name, tax_rate):
    #connect to database
    con = sqlite3.connect(db_name)
    cur = con.cursor()

    #add_customer
    cur.execute('''INSERT INTO customers (last_name, first_name, tax_rate) VALUES (?, ?, ?)''',
        (last_name,
        first_name,
        tax_rate))

    #commit and close
    con.commit()
    con.close()

def add_product(db_name, name, price, taxable):
    #connect to database
    con = sqlite3.connect(db_name)
    cur = con.cursor()

    #add product
    cur.execute('''INSERT INTO products (name, price, taxable) VALUES (?, ?, ?)''',
        (name,
        price,
        taxable))

    #commit and close
    con.commit()
    con.close()

def start_order(db_name, customer_id):
    #connect to database
    con = sqlite3.connect(db_name)
    cur = con.cursor()

    #add order
    cur.execute('''INSERT INTO orders (customer_id) VALUES (?)''', (customer_id,))

    #capture new order number and return
    cur.execute('''SELECT max(order_id) FROM orders''')
    tmp = cur.fetchall()

    #commit and close
    con.commit()
    con.close()
    return tmp[0][0]

def add_item(db_name, order_id, product_id, qty):
    #connect to database
    con = sqlite3.connect(db_name)
    cur = con.cursor()

    #add_item
    cur.execute('''INSERT INTO items (order_id, product_id, qty) VALUES (?, ?, ?)''',
        (order_id,
        product_id,
        qty))CUSTOMERS: [(1, 'Mickey', 'Mouse', 8.75), (2, 'Donald', 'Duck', 9.0), (3, 'Minie', 'Mouse', 7.5), (4, 'Buzz', 'Lightyear', 10.0)]
PRODUCTS: [(1, 'Paper', 1.25, 1), (2, 'Water', 1.5, 0), (3, 'Pencils', 4.95, 1), (4, 'Book', 44.5, 1), (5, 'Backpack', 29.95, 1)]
ORDERS: [(1, 2, 0.0, 0.0, 0.0)]
ITEMS: [(1, 1, 3), (1, 2, 5), (1, 3, 2)]
ORDERS: [(1, 2, 21.15, 1.23, 22.38)]


    #commit and close
    con.commit()
    con.close()

def finish_order(db_name, order_id):
    #connect to database
    con = sqlite3.connect(db_name)
    cur = con.cursor()

    #collect all the items along with the product price, taxable, and customer tax rate
    cur.execute('''SELECT items.*, products.*, orders.*, customers.*
        FROM items
        LEFT JOIN products ON items.product_id=products.product_id
        LEFT JOIN orders ON items.order_id=orders.order_id
        LEFT JOIN customers ON orders.customer_id=customers.customer_id
        WHERE items.order_id = (?)''', (order_id,))
    tmp = cur.fetchall()
    subtotal = 0
    tax = 0
    total = 0
    for x in tmp:
        price = x[2]
        qty = x[5]
        tax_rate = x[15]
        subtotal = round(subtotal + (price * qty),2)
        tax_tmp = 0
        if x[6] == 1:
            tax_tmp = round(price * qty * tax_rate / 100.0, 2)
        tax = tax + tax_tmp
        total = round(subtotal + tax,2)

    #update the orders table
    sql = 'UPDATE orders SET subtotal={}, tax={}, total={} WHERE order_id={}'.format(subtotal,tax,total,order_id)
    cur.execute(sql)

    #commit and close
    con.commit()
    con.close()

def print_order(db_name, order_id):
    #connect to database
    con = sqlite3.connect(db_name)
    cur = con.cursor()

    #collect all the items along with the product price, taxable, and customer tax rate
    cur.execute('''SELECT items.*, products.*, orders.*, customers.*
        FROM items
        LEFT JOIN products ON items.product_id=products.product_id
        LEFT JOIN orders ON items.order_id=orders.order_id
        LEFT JOIN customers ON orders.customer_id=customers.customer_id
        WHERE items.order_id = (?)''', (order_id,))
    tmp = cur.fetchall()
    #print('DUMP:',tmp)
    print('')
    print('==================================================')
    print('Name        :', tmp[0][13], tmp[0][14])
    print('Order Number:', order_id)
    print('==================================================')
    print('Item             Qty     Price       Tax    Amount')
    print('============  ======  ========  ========  ========')

    subtotal = 0
    tax = 0
    total = 0
    for x in tmp:
        price = x[2]
        qty = x[5]
        tax_rate = x[15]
        subtotal = round(price * qty,2)
        tax = 0
        if x[6] == 1:
            tax = round(price * qty * tax_rate / 100.0, 2)
        subtotal = (price * qty) + tax

        #print(f'{org:7}{dest:12}{num:>6}{dep:>10}{arr:>9}{dur:>9}')
        print(f'{x[4]:10}{x[2]:10}{x[5]:10.2f}{tax:10.2f}{subtotal:10.2f}')


    print('                                          ========')
    print(f'                               Subtotal:{tmp[0][9]:10.2f}')
    print(f'                                    Tax:{tmp[0][10]:10.2f}')
    print(f'                                  Total:{tmp[0][11]:10.2f}')
    print('==================================================')
    print('')

    #commit and close
    con.commit()
    con.close()

def get_table_contents(db_name, table):
    #connect to database
    con = sqlite3.connect(db_name)
    cur = con.cursor()

    sql = 'SELECT * FROM {}'.format(table)

    #retrieve contents
    cur.execute(sql)
    tmp = cur.fetchall()

    #commit and close
    con.commit()
    con.close()

    return tmp
