from mydb import *

#create a new database
create_db('shopping.db')

#populate customer table
add_customer('shopping.db','Mickey','Mouse','8.75')
add_customer('shopping.db','Donald','Duck','9.0')
add_customer('shopping.db','Minie','Mouse','7.5')
add_customer('shopping.db','Buzz','Lightyear','10.0')
print('CUSTOMERS:',get_table_contents('shopping.db','customers'))



#populate products table
add_product('shopping.db','Paper',1.25,1)
add_product('shopping.db','Water',1.50,0)
add_product('shopping.db','Pencils',4.95,1)
add_product('shopping.db','Book',44.50,1)
add_product('shopping.db','Backpack',29.95,1)
print('PRODUCTS:',get_table_contents('shopping.db','products'))



#start an order
customer_number = 2
order_number = start_order('shopping.db',customer_number)
print('ORDERS:',get_table_contents('shopping.db','orders'))


#add some items to the order
add_item('shopping.db',order_number,1,3)
add_item('shopping.db',order_number,2,5)
add_item('shopping.db',order_number,3,2)
print('ITEMS:',get_table_contents('shopping.db','items'))


#complete an order
finish_order('shopping.db',order_number)
print('ORDERS:',get_table_contents('shopping.db','orders'))



#pretty print the order
print_order('shopping.db',order_number)
