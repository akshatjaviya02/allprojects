#!/usr/bin/python3

# EXECUTE THE BELOW COMAND FROM THE TERMINAL PROMPT - ADJUST THE PATH IF NEEDED
# chmod 0755 /home/student/Documents/ips/server/cgi-bin/SERVER_GET_get_contact.py

import cgi
from contacts import *

print("Content-Type: text/html")    # HTML is following
print()                             # blank line, end of headers

form = cgi.FieldStorage()
if "name" in form:
    my_contact = get_contact(name=form['name'].value)
    print(my_contact)
else:
    print('ERROR: must have name value')
