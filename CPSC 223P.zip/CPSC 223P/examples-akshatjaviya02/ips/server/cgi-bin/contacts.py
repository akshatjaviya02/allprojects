import json

# EXECUTE THE BELOW COMAND FROM THE TERMINAL PROMPT - ADJUST THE PATH IF NEEDED
# chmod 0666 /home/student/Documents/ips/server/cgi-bin/contacts.dat

def read_file(*, filename):
    try:
        with open(filename, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def write_file(*, data, filename):
    with open(filename, 'w') as f:
        json.dump(data, f)

def set_contact(*, name, phone):
    my_filename = '/home/student/Documents/ips/server/cgi-bin/contacts.dat'
    my_data = read_file(filename=my_filename)
    my_dictionary = {'name':name, 'phone':phone}
    my_data.append(my_dictionary)
    write_file(data=my_data, filename=my_filename)

def get_contact(*, name):
    my_filename = '/home/student/Documents/ips/server/cgi-bin/contacts.dat'
    my_data = read_file(filename=my_filename)
    for x in my_data:
        if x['name'] == name:
            return x
    return {}
