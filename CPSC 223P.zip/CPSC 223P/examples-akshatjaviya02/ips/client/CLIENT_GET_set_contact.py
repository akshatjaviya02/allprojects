import urllib.parse
import urllib.request

data = {}
data['name'] = 'Daffy Duck'
data['phone'] = '888-333-5555'

url_values = urllib.parse.urlencode(data)
url = 'http://0.0.0.0:8080/cgi-bin/SERVER_GET_set_contact.py'
full_url = url + '?' + url_values
with urllib.request.urlopen(full_url) as response:
    the_page = response.read()
    print(the_page)
