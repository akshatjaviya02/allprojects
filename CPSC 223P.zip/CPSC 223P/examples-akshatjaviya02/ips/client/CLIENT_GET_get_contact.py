import urllib.parse
import urllib.request

data = {}
data['name'] = 'Woody'

url_values = urllib.parse.urlencode(data)
url = 'http://0.0.0.0:8080/cgi-bin/SERVER_GET_get_contact.py'
full_url = url + '?' + url_values
with urllib.request.urlopen(full_url) as response:
    the_page = response.read()
    print(the_page)
