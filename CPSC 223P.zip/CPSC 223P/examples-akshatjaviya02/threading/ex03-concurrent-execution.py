#Example of the Thread Class

from time import sleep, perf_counter
import threading


def taskxyz(id):
    print(f'Starting the task {id}...')
    print(threading.main_thread())
    print(threading.current_thread())
    sleep(1)
    print(f'done {id}')


start_time = perf_counter()
print('active_count: ' + str(threading.active_count()))

# create and start 10 threads
threads = []
for n in range(1, 11):
    t = threading.Thread(target=taskxyz, args=(n,))
    threads.append(t)
    t.start()

print('active_count: ' + str(threading.active_count()))
print(threading.enumerate())

# wait for the threads to complete
for t in threads:
    t.join()


end_time = perf_counter()
print('active_count: ' + str(threading.active_count()))

print(f'It took {end_time- start_time: 0.2f} second(s) to complete.')
