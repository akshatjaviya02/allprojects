# Name: Akshat Javiya
# Date: 3/25/2022
# File Purpose: Lab07 user interface
from contacts import *
def main():
    '''user interface'''
    contacts = Contacts(filename="contact.dat")
    while True:
        string1 = "*** TUFFY TITAN CONTACT MAIN MENU\n"
        string1 = string1 + "1. Add contact\n"
        string1 = string1 + "2. Modify contact\n"
        string1 = string1 + "3. Delete contact\n"
        string1 = string1 + "4. Print contact list\n"
        string1 = string1 + "5. Set contact filename\n"
        string1 = string1 + "6. Exit the program\n\n"
        string1 = string1 + "Enter menu choice:"
        userinput = int(input(string1))
        if userinput == 1:
            id = input("Enter phone number: ")
            first_name = input("Enter first name: ")
            last_name = input("Enter last name: ")
            s = contacts.add_contact(id=id, first_name=first_name,
                                                    last_name=last_name)
            if s == "error":
                print("Phone number already exists.\n")
            else:
                print("Added:", s)
        elif userinput == 2:
            id = input("Enter phone number: ")
            first_name = input("Enter first name: ")
            last_name = input("Enter last name: ")
            s = contacts.modify_contact(id=id, first_name=first_name,
                                                        last_name=last_name)
            if s == "error":
                print("Phone number already exists.\n")
            else:
                print("Added:", s)
        elif userinput == 3 :
            id = input("Enter phone number: ")
            output3 = delete_contact(contact, id=id)
            if output3 == "error":
                print("Invalid phone number.")
            else:
                print("Deleted: ", output3)
        elif userinput == 4 :
            print_list(contacts.data)
        elif userinput == 5 :
            filename = input("Enter file name: ")
            contact = Contacts(filename=filename)
            contacts = contact
        elif userinput == 6 :
            break
def print_list(data):
    '''Prints the contact dictionary'''
    p =     "================== CONTACT LIST ======================\n"
    p = p + "Last Name             First Name            Phone\n"
    p = p + "====================  ====================  ==========\n"
    keys = tuple(data.keys())
    vals = list(data.values())
    for i in range(len(vals)):
        p = p + f'{vals[i][1]:22}{vals[i][0]:22}{keys[i]:23}' + "\n"
    print(p)
if __name__ == '__main__':
    main()
