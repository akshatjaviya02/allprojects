# Name: Akshat Javiya
# Date: 3/25/2022
# File Purpose: class of contacts and helper functions
import json
class Contacts:
    '''contacts class'''

    def __init__(self, /, *, filename):
        '''init contacts class'''
        self.data = {}
        self.filename = filename
        try:
            with open(self.filename) as json_file:
                data = json.load(json_file)
            self.data = data
            json_file.close()
        except FileNotFoundError:
            return None
    def add_contact(self, /, *, id, first_name, last_name):
        '''Adds the contacts to dictionary'''
        if id in self.data.keys():
            s = "error"
            return s
        else:
            self.data[id] = [first_name, last_name]
            self.data = sort_contacts(self.data)
            write_data(data=self.data, filename=self.filename)
            return self.data.get(id)
    def modify_contact(self, /, *, id, first_name, last_name):
        '''Modify the contact'''
        if id in self.data.keys():
            self.data.update({id: [first_name, last_name]})
            self.data = sort_contacts(self.data)
            write_data(data=self.data, filename=self.filename)
            return self.data.get(id)
        else:
            s = "error"
            return s
    def delete_contact(self, /, *, id):
        '''Delete the contact'''
        if id in self.data.keys():
            removed = self.data.pop(id)
            write_data(data=self.data, filename=self.filename)
            return removed
        else:
            s = "error"
            return s

def write_data(*, data, filename):
    '''Writes to the file'''
    S = json.dumps(data)
    F = open(filename, "w")
    F.write(S)
    F.close()
def sort_contacts(data, /):
    '''Sorts the accordingly by user input'''
    sort_c = {val[0] : val[1] for val in sorted(data.items(), key =
                                                    lambda x: (x[0], x[1]))}
    return sort_c
