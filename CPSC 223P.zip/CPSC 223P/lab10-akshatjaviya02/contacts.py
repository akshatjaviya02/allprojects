# Name: Akshat Javiya
# Date: 05/5/2022
# Purpose: contacts class and its functions
import sqlite3
class Contacts(object):
    """docstring for Contacts."""
    def __init__(self):
        self.database_name = ""
        self.contact_id = 0
        self.phone_id = 0
    def set_database_name(self, database_name):
        '''sets the database by user'''
        if database_name != self.database_name:
            self.database_name = database_name
            conn = sqlite3.connect(self.database_name)
            c = conn.cursor()
            c.execute('''CREATE TABLE contacts
                     (contact_id      INTEGER  PRIMARY KEY AUTOINCREMENT,
                     first_name       TEXT    NOT NULL,
                     last_name        TEXT     NOT NULL);''')
            c.execute('''CREATE TABLE phones
                     (phone_id       INT  PRIMARY KEY  NOT NULL,
                     contact_id      INT       NOT NULL,
                     phone_type      TEXT      NOT NULL,
                     phone_number    TEXT      NOT NULL,
                     FOREIGN KEY (contact_id)
                     REFERENCES contacts (contact_id));''')
            conn.commit()
    def get_database_name(self):
        '''gets the database by user'''
        return self.database_name
    def add_contact(self, firstname, lastname):
        '''adds the contacts to database'''
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        self.contact_id = self.contact_id + 1
        c.execute("INSERT INTO contacts values (?, ?, ?)", (self.contact_id, firstname, lastname))
        conn.commit()
    def modify_contact(self, id, first_name, last_name):
        '''modify the contacts to database'''
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("UPDATE contacts SET first_name = ? WHERE contact_id = ?",(first_name, id))
        c.execute("UPDATE contacts SET  last_name = ? WHERE contact_id = ?",(last_name, id))
        conn.commit()
    def add_phone(self, contact_id, phone_type, phone_number):
        '''adds the phone to database'''
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        self.phone_id = self.phone_id + 1
        c.execute("INSERT INTO phones values (?, ?, ?, ?)", (self.phone_id, contact_id, phone_type, phone_number))
        conn.commit()
    def modify_phone(self, phone_id, phone_type, phone_number):
        '''modify the phone to database'''
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("UPDATE phones SET phone_type = ? WHERE phone_id = ?",(phone_type, phone_id))
        c.execute("UPDATE phones SET  phone_number = ? WHERE phone_id = ?",(phone_number, phone_id))
        conn.commit()
    def get_contact_phone_list(self):
        '''prints all the contacts'''
        conn = sqlite3.connect(self.database_name)
        c = conn.cursor()
        c.execute("SELECT contacts.*, phones.* FROM contacts LEFT JOIN phones ON contacts.contact_id=phones.contact_id")
        arr = c.fetchall()
        return arr
