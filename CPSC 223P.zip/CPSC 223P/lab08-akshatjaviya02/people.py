# Name: Akshat Javiya
# Date: 04/10/2022
# Purpose: Multiple Class with base class.
class Person:
    """Base class: Person."""

    def __init__(self, firstname, lastname):
        '''Init the person class'''
        self.firstname = firstname
        self.lastname = lastname

class Faculty(Person):
    """Class Faculty would inherit Person class"""

    def __init__(self, firstname, lastname, department):
        super().__init__(firstname, lastname)
        self.department = department


class Student(Person):
    """Class Student would inherit Person class"""

    def __init__(self, firstname, lastname):
        super().__init__(firstname, lastname)

    def set_class(self, classyear):
        '''sets the class year for student'''
        self.classyear = classyear
    def set_major(self, major):
        '''sets the major for stiudent'''
        self.major = major
    def set_advisor(self, faculty):
        '''sets the advisor for stiudent'''
        self.advisor = faculty
