# Name: Akshat Javiya
# Date: 04/10/2022
# Purpose: Main function (user Interface) and Helper function
from people import Student, Faculty

def main():
    '''User Interface'''
    Student_list = []
    Faculty_list = []
    s = "1. Add faculty\n"
    s = s + "2. Print faculty\n"
    s = s + "3. Add student\n"
    s = s + "4. Print student\n"
    s = s + "9. Exit Program\n"
    s = s + "Enter menu choice: "
    while True:
        user_choice = int(input(s))
        if user_choice == 1:
            Faculty_list = Add_faculty(Faculty_list)
        elif user_choice == 2:
            print(print_faculty(Faculty_list))
        elif user_choice == 3:
            Student_list = Add_student(Student_list, Faculty_list)
        elif user_choice == 4:
            print(print_student(Student_list))
        elif user_choice == 9:
            break


def Add_faculty(Faculty_list):
    '''Adds the faculty to list'''
    firstname = input("Enter first name: ")
    lastname = input("Enter last name:")
    department = input("Enter the department: ")
    faculty = Faculty(firstname, lastname, department)
    Faculty_list.append(faculty)
    return Faculty_list

def Add_student(Student_list, Faculty_list):
    '''Adds the student to list'''
    firstname = input("Enter first name: ")
    lastname = input("Enter last name:")
    classyear = input("Enter class year: ")
    major = input("Enter major: ")
    advisor = int(input("Enter faculty advisor: "))
    student = Student(firstname, lastname)
    student.set_class(classyear)
    student.set_major(major)
    name = Faculty_list[advisor]
    student.set_advisor(name)
    Student_list.append(student)
    return Student_list

def print_faculty(Faculty_list):
    '''Prints all the faculty members'''
    s =     "======================= FACLUTY =======================\n"
    s = s + "Record  Name                  Department\n"
    s = s + "======  ====================  =========================\n"
    for i in range(len(Faculty_list)):
        s = s + f'{str(i):8}{Faculty_list[i].firstname + " " + Faculty_list[i].lastname:22}{Faculty_list[i].department:22}' + "\n"
    return s
def print_student(Student_list):
    '''Prints all the students'''
    s =     "===================================== STUDENTS ======================================\n"
    s = s + "Name                  Class      Major                      Advisor\n"
    s = s + "====================  =========  =========================  =========================\n"
    for i in range(len(Student_list)):
        s = s + f'{Student_list[i].firstname + " " + Student_list[i].lastname:22}{Student_list[i].classyear:11}{Student_list[i].major:27}{Student_list[i].advisor.firstname + " " + Student_list[i].advisor.lastname:20}' + "\n"
    return s


if __name__ == '__main__':
    main()
