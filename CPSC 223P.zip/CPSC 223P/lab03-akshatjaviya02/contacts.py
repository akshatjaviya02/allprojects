# Name: Akshat Javiya
# Date: 02/10/2022
# Purpose: Multiple functions to print, modify, add, sort by first and last name and delete contacts
def print_list(contact):
    '''Prints the contact list'''
    print("================== CONTACT LIST ==================\n")
    print("Index   First Name            Last Name\n")
    print("======  ====================  ====================\n")
    for i in range(len(contact)):
        print(f'{str(i):8}{contact[i][0]:22}{contact[i][1]:22}')

def add_contact(contact, /, *, first_name, last_name):
    '''Adds the contacts to list'''
    contact.append([first_name, last_name])

def modify_contact(contact, /, *, index, first_name, last_name):
    '''Modify the contact'''
    if len(contact) < index:
        print("Invalid index number.")
        return False
    else:
        contact[index] = [first_name, last_name]
        return True

def delete_contact(contact, /, *, index):
    '''Delete the contact'''
    if len(contact) < index:
        print("Invalid index number.")
        return False
    else:
        contact.pop(index)
        return True
def sort_contacts(contact, /, *, column):
    '''Sorts the accordingly by user input'''
    if column == 0:
        contact.sort(key = lambda x: x[0])
    else:
        contact.sort(key = lambda y: y[1])
