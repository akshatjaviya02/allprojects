# Name: Akshat Javiya
# Date: 2/10/2022
# File Purpose: Lab03 main program driver program

from contacts import *

contact = []
boolean = True
while True :
    print("      *** TUFFY TITAN CONTACT MAIN MENU\n")
    print("1. Print list\n")
    print("2. Add contact\n")
    print("3. Modify contact\n")
    print("4. Delete contact\n")
    print("5. Sort list by first name\n")
    print("6.  Sort list by last name\n")
    print("7. Exit the program\n")
    userinput = int(input("Enter menu choice: "))
    if userinput == 1 :
        print_list(contact)
    elif userinput == 2 :
        first_name = input("Enter first name: ")
        last_name = input("Enter last name : ")
        add_contact(contact, first_name=first_name, last_name=last_name)
        print("\n")
    elif userinput == 3 :
            index = int(input("Enter the index to edit the contact: "))
            first_name = input("Enter first name: ")
            last_name = input("Enter last name: ")
        boolean = modify_contact(contact, index=index, first_name=first_name, last_name=last_name)
        print("\n")
    elif userinput == 4 :
        index = int(input("Enter the index to edit the contact: "))
        boolean = delete_contact(contact, index=index)
        print("\n")
    elif userinput == 5 :
        sort_contacts(contact, column = 0)
        print("\n")
    elif userinput == 6 :
        sort_contacts(contact, column = 1)
        print("\n")
    elif userinput == 7 :
        break
