# Name: Akshat Javiya
# Date: 03/03/2022
# Purpose: Testing all the function
import mathematics.numbers.simple as  simple
import mathematics.geometry.rectangle as rectangle
import mathematics.geometry.cube as cube
import mathematics.geometry.circle as circle
import mathematics.numbers.series as series

print("\n\n Welcome to Student made Calculator\n\n")
user = input("Do you want to active the calculator? Y or N. ")
if user == 'y' or user == 'Y' or user == 'Yes' or user == 'yes':
    input1 = int(input("First number: "))
    input2 = int(input("Second number: "))
    print("Passing {} and {} in addition function".format(input1, input2))
    add = simple.addition(left=input1, right=input2)
    print("The value that should be returning ", str(add), "\n")
    print("Passing {} and {} in the subtraction function".format(input1, input2))
    sub = simple.subtraction(left=input1, right=input2)
    print("The value that should be returning ", str(sub), "\n")
    print("Passing {} and {} in the multiplication function".format(input1, input2))
    mul = simple.multiplication(left=input1, right=input2)
    print("The value that should be returning ", str(mul), "\n")
    print("Passing {} and {} in the division function".format(input1, input2))
    div = simple.division(left=input1, right=input2)
    print("The value that should be returning ", str(div), "\n")
    list = [1, 5, 68, 65, 465, 65, 10]
    print("Passing ", list, "in sum function")
    total = series.sum(list=list)
    print("The value that should be returning ", str(total), "\n")
    print("Passing ", list, "in average function")
    total = series.average(list=list)
    print("The value that should be returning ", str(total), "\n")
    print("Passing {} and {} in parimeter function".format(input1, input2))
    add = rectangle.perimeter(length=input1, width=input2)
    print("The value that should be returning ", str(add), "\n")
    print("Passing {} and {} in the area function of rectangle".format(input1, input2))
    sub = rectangle.area(length=input1, width=input2)
    print("The value that should be returning  is 2070 and should be equal to ", str(sub), "\n")
    print("Passing {} in the circumference function".format(input1))
    mul = circle.circumference(radius=input1)
    print("The value that should be returning ", str(mul), "\n")
    print("Passing {} in the area function of circle".format(input1))
    div = circle.area(radius=input1)
    print("The value that should be returning ", str(div), "\n")
    area = cube.surface_area(side=input1)
    print("Passing {} in the surface_area function".format(input1))
    print("The value that should be returning ", str(area), "\n")
    print("Passing {} in the volume function".format(input1))
    vol = cube.volume(side=input1)
    print("The value that should be returning ", str(vol), "\n")
else:
    print("GoodBye")
