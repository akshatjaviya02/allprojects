# Akshat Javiya
# Date: 03/03/2022
# Purpose: Function inside of the package
def perimeter(*, length, width):
    ''' Calculates the perimeter of rectangle'''
    rec = 2 * (length + width)
    return rec

def area(*, length, width):
    ''' Calculates the area of rectangle'''
    return length * width
