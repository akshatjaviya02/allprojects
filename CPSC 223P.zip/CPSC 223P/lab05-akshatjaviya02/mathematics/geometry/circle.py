# Akshat Javiya
# Date: 03/03/2022
# Purpose: Functions inside of the package
pi = 3.141592653589793
def circumference(*, radius):
    ''' finding circumference of circle'''
    return 2 * pi * radius

def area(*, radius):
    '''Calculates the area of circle'''
    return pi * radius * radius
