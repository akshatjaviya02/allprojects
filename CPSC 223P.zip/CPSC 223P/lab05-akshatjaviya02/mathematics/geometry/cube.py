# Akshat Javiya
# Date: 03/03/2022
# Purpose: Functions inside of the package
def surface_area(*, side):
    '''Calculates surface area'''
    return side * side * 6

def volume(*, side):
    '''Calculates the volume'''
    return side * side * side
