# Akshat Javiya
# Date: 03/03/2022
# Purpose: Functions inside of the package
def addition(*, left, right):
    ''' Adds the left number to right number'''
    return left + right

def subtraction(*, left, right):
    '''Subtract the left number to right number'''
    return left - right

def multiplication(*, left, right):
    ''' multiplies the left number to right number'''
    return left * right

def division(*, left, right):
    '''divides the left number to right number'''
    return left / right
