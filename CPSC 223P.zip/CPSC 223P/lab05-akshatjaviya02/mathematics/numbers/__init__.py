# Akshat Javiya
# Date: 03/03/2022
# Purpose: Tells the compiler to treat as package
__all__ = ['whoami', 'series']
