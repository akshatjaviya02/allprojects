# Akshat Javiya
# Date: 03/03/2022
# Purpose: Functions inside of the package
def sum(*, list):
    '''Sum of all the elements'''
    total = 0
    for i in range(len(list)):
        total = total + list[i]
    return total

def average(*, list):
    '''Average of the elements inside the list'''
    avg = sum(list=list)
    a = len(list)
    avg = avg / a
    return avg
