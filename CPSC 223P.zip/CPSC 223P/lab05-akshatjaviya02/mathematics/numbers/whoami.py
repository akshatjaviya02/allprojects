# Akshat Javiya
# Date: 03/03/2022
# Purpose: Function inside of the package
def getname():
    return __name__
