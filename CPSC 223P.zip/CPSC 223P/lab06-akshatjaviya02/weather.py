# Name: Akshat Javiya
# Date: 3/15/2022
# File Purpose: functions to calculate the weather
import json
import os.path as path
import calendar

def read_data(filename=""):
    '''reads from the file'''
    data = {}
    try:
        f = open(filename)
        data = json.load(f)
        f.close()
        return data
    except FileNotFoundError :
        return data

def write_data(data="", filename=""):
    '''Writes to the file'''
    S = json.dumps(data)
    F = open(filename, "w")
    F.write(S)
    F.close()

def max_temperature(data="", date=""):
    '''Return the maximum temperature'''
    s = 0
    for key, value in data.items():
        date_format = key[0:8]
        if date_format == date:
            for v in value:
                if v == "t":
                    if s < value[v]:
                        s = value[v]
    return s
def min_temperature(data="", date=""):
    '''Return the minimum temperature'''
    s = 0
    for key, value in data.items():
        for v in value:
            if v == "t":
                date_format = key[0:8]
                if date_format == date:
                    if s == 0:
                        s = value[v]
                    elif s > value[v]:
                        s = value[v]
    return s
def max_humidity(data="", date=""):
    '''Return the maximum humidity'''
    s = 0
    for key, value in data.items():
        for v in value:
            if v == "h":
                date_format = key[0:8]
                if date_format == date:
                    if s < value[v]:
                        s = value[v]
    return s
def min_humidity(data="", date=""):
    '''Return the minimum humidity'''
    si = 0
    for key, value in data.items():
        for v in value:
            if v == "h":
                date_format = key[0:8]
                if date_format == date:
                    if si == 0:
                        si = value[v]
                    elif si > value[v]:
                        si = value[v]
    return si
def tot_rain(data="", date=""):
    '''total rain throughout the data'''
    s = 0
    for key, value in data.items():
        for v in value:
            if v == "r":
                date_format = key[0:8]
                if date_format == date:
                        s = s + value[v]
    return s
def report_daily(data="", date=""):
    '''gives daily report'''
    s =     "========================= DAILY REPORT ========================\n"
    s = s + "Date                      Time  Temperature  Humidity  Rainfall\n"
    s = s + "====================  ========  ===========  ========  ========\n"
    month = date[4:6]
    month = int(month)
    month = calendar.month_name[month]
    for key, value in data.items():
        date_format = key[0:8]
        if date_format == date:
            for v in value:
                year = key[0:4]
                day = key[6:8]
                time = key[8:10]
                time2 = key[10:12]
                time3 = key[12:]
                time = time + ":" + time2 + ":" + time3
                day = int(day)
                temperature = value["t"]
                humidity = value["h"]
                rainfall = value["r"]
                dat = month + " " + str(day) + ", " + year
            s = s + f"{dat:22}{time:10}{temperature:11}{humidity:10}{rainfall:10.2f}" + "\n"
    return s
print(report_daily(data={"20210203075501": {"t": 55, "h": 87, "r": 0}, "20210203090602": {"t": 63, "h": 84, "r": 0}, "20210203102903": {"t": 71, "h": 79, "r": 0}, "20210203125504": {"t": 72, "h": 69, "r": 0}, "20210203183905": {"t": 59, "h": 75, "r": 0}, "20210205044406": {"t": 57, "h": 68, "r": 0.01}, "20210205083307": {"t": 65, "h": 63, "r": 0.05}, "20210205122208": {"t": 73, "h": 56, "r": 0.11}, "20210205161109": {"t": 74, "h": 60, "r": 0.19}}, date='20210205'))

def report_historical(data=""):
    '''Gives the historical report of the month'''
    check_for_date = ""
    s =     "============================== HISTORICAL REPORT ===========================\n"
    s = s + "                          Minimum      Maximum   Minumum   Maximum     Total\n"
    s = s + "Date                  Temperature  Temperature  Humidity  Humidity  Rainfall\n"
    s = s + "====================  ===========  ===========  ========  ========  ========\n"
    for key, value in data.items():
        date_format = key[0:8]
        max_temp = max_temperature(data=data, date=date_format)
        min_temp = min_temperature(data=data, date=date_format)
        min_hum = min_humidity(data=data, date=date_format)
        max_hum = max_humidity(data=data, date=date_format)
        total_rain = tot_rain(data=data, date=date_format)
        month = key[4:6]
        month = int(month)
        month = calendar.month_name[month]
        year = key[0:4]
        day = key[6:8]
        day = int(day)
        dat = month + " " + str(day) + ", " + year
        if len(check_for_date) == 0:
            check_for_date = date_format
            s = s + f"{dat:26}{min_temp:7}{max_temp:13}{min_hum:10}{max_hum:10}{total_rain:10.2f}" + "\n"
        elif date_format != check_for_date:
            check_for_date = date_format
            s = s + f"{dat:26}{min_temp:7}{max_temp:13}{min_hum:10}{max_hum:10}{total_rain:10.2f}" + "\n"
    return s
