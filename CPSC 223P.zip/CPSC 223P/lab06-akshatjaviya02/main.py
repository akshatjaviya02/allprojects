# Name: Akshat Javiya
# Date: 3/15/2022
# File Purpose: Lab06 main program driver program
from weather import *

def main():
    '''Drriver function of weather module'''
    data = {}
    while True:
        global gfilename
        s =     "*** TUFFY TITAN WEATHER LOGGER MAIN MENU\n"
        s = s + "1. Set data filename\n"
        s = s + "2. Add weather data\n"
        s = s + "3. Print daily report\n"
        s = s + "4. Print historical report\n"
        s = s + "9. Exit the program\n"
        s = s + "Enter menu choice: "
        userinput = int(input(s))
        if userinput == 1:
            filename = input("Enter data filename: ")
            data = read_data(filename=filename)
            gfilename = filename
        elif userinput == 2:
            date = input("Enter date (YYYYMMDD): ")
            time = input("Enter time (hhmmss): ")
            temp = int(input("Enter temperature: "))
            hum  = int(input("Enter humidity: "))
            rain = float(input("Enter rainfall: "))
            date = date + time
            data[date] = {"t" : temp, "h" : hum, "r" : rain}
            write_data(data=data, filename=gfilename)
        elif userinput == 3:
            date = input("Enter date (YYYYMMDD): ")
            print(report_daily(data=data, date=date))
        elif userinput == 4:
            print(report_historical(data=data))
        elif userinput == 9:
            break
if __name__ == '__main__':
    main()
