# Name: Akshat Javiya
# Date: 04/12/2022
import json
class Inventory:
    def __init__(self, /, *, filename):
        self.data = {}
        self.filename = filename
        try:
            f = open(filename)
            data = json.load(f)
            f.close()
            self.data = data
            self.filename = filename
        except FileNotFoundError:
            return None
    def add_item(self, /, *, barcode, description):
        if type(barcode) == int:
            return 109
        if type(barcode) == str:
            if not len(barcode) == 6 or not barcode[:2] == "BC":
                return 109
            if not barcode[2:6].isdigit():
                return 109
        for key in self.data.keys():
            if key == barcode:
                return 101
        self.data[barcode] = [description, 0]
        f = open(self.filename, "w")
        s = json.dump(self.data, f)
        f.close()
        return 100
    def modify_description(self, /, *, barcode, description):
        for key in self.data.keys():
            if not key == barcode:
                return 102
        self.data[barcode][0] = description
        f = open(self.filename, "w")
        s = json.dump(self.data, f)
        f.close()
        return 100
    def add_qty(self, /, *, barcode, qty):
        if not type(qty) == int:
            return 108
        for key, value in self.data.items():
            if key == barcode:
                i = value[1]
                self.data[barcode][1] = qty + i
                f = open(self.filename, "w")
                s = json.dump(self.data, f)
                f.close()
                return 100
        return 102
    def remove_qty(self, /, *, barcode, qty):
        if not type(qty) == int:
            return 108
        for key, value in self.data.items():
            if key == barcode:
                i = value[1]
                if i < qty:
                    return 103
                self.data[barcode][1] = i - qty
                f = open(self.filename, "w")
                s = json.dump(self.data, f)
                f.close()
                return 100
        return 102
    def get_inventory(self):
        s = ""
        for key, value in self.data.items():
            qty = value[1]
            s = s + f'{key:8}{value[0]:20}{qty:5}' + "\n"
        return s
