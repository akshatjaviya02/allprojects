#include <iostream>
#include <string>
#include "cpputils/graphics/image.h"

class Bubble {
 public:
  // accessor
  int GetXCoordinate() { return x_; }
  int GetYCoordinate() { return y_; }
  int GetSize() { return size_; }
  graphics::Color GetColor() { return color_; }
  void SetXCoordinate(int x) { x_ = x; }
  void SetYCoordinate(int y) { y_ = y; }
  void SetSize(int size) { size_ = size; }
  void SetColor(graphics::Color color) { color_ = color; }

 private:
  int x_;
  int y_;
  int size_;
  graphics::Color color_;
};
