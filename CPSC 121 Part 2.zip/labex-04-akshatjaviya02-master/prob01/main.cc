#include <stdlib.h>

#include <iostream>
#include <string>

#include "cpputils/graphics/image.h"

int HexToInteger(std::string hex) {
  // Only works on strings length 2.
  if (hex.size() != 2) {
    return -1;
  }
  // Convert hex string, base 16 string, to integer.
  const int kBaseSixteen = 16;
  return strtoul(hex.c_str(), nullptr, kBaseSixteen);
}

int main() {
  //
  // Your code here.
  //
  const int size = 150;
  graphics::Image my_image(150, 150);
  std::string user_input;
  std::cout << "Enter a hex code: ";
  std::cin >> user_input;
  std::string red;
  std::string green;
  std::string blue;
  red = user_input.substr(0, 2);
  green = user_input.substr(2, 2);
  blue = user_input.substr(4, 2);
  int r = HexToInteger(red);
  int g = HexToInteger(green);
  int b = HexToInteger(blue);
  graphics::Color image(r, g, b);
  my_image.DrawRectangle(0, 0, size, size, image);
  my_image.SaveImageBmp(user_input + ".bmp");
  std::cout << "Color swatch saved to " << user_input << ".bmp" << std::endl;
  return 0;
}
