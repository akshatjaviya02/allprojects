#include <iostream>
// TODO: Include any necessary headers.
#include <vector>
#include "minimum.h"
int main() {
  int size;
  std::cout << "How many elements? ";
  std::cin >> size;

  // TODO: Construct the vector and array.
  std::vector<double> input;
  double num[size];
  // TODO: Prompt the user for the value of each element and populate the vector
  // and array.
  for (int i = 0; i < size; i++) {
    std::cout << "Element" << i << ": ";
    double number;
    std::cin >> num[i];
    number = num[i];
    input.push_back(number);
  }
  // TODO: Call the IndexOfMin* functions using the vector or array as
  // appropriate, and display the output.
  int num0 = IndexOfMinWithVector(input);
  int num1 = IndexOfMinWithArray(num, size);
  double *num3 = num;
  int num2 = IndexOfMinWithPointer(num3, size);
  std::cout << "Minimum index using vector: " << std::to_string(num0)
            << std::endl;
  std::cout << "Minimum index using array: " << std::to_string(num1)
            << std::endl;
  std::cout << "Minimum index using pointer math: " << std::to_string(num2)
            << std::endl;
}
