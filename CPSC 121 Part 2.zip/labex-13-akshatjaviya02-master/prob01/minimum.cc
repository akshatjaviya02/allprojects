#include "minimum.h"

int IndexOfMinWithVector(std::vector<double> input) {
  // TODO
  int index = 0;
  double small = 0;
  if (input.size() == 0) {
    return -1;
  }
  if (input.size() == 1) {
    return 0;
  } else {
    for (int i = 0; i < input.size(); i++) {
      if (small > input[i]) {
        small = input[i];
        index = i;
      }
    }
    return index;
  }
}

int IndexOfMinWithArray(double input[], int size) {
  // TODO
  int index = 0;
  double small = 0;
  if (size == 0) {
    return -1;
  } else {
    for (int i = 0; i < size; i++) {
      if (small > input[i]) {
        small = input[i];
        index = i;
      }
    }
    return index;
  }
}

int IndexOfMinWithPointer(double *input, int size) {
  // TODO
  int index = 0;
  double *small = input;
  if (size == 0) {
    return -1;
  }
  if (size == 1) {
    return 0;
  } else {
    for (int i = 0; i < size; i++) {
      if (*small > (*input)) {
        *small = (*input);
        index = i;
      }
      input += 1;
    }
    return index;
  }
}
