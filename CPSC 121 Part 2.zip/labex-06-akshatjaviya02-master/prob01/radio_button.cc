#include <iostream>
#include <string>
#include <vector>

#include "radio_button.h"

void SelectRadioButton(std::vector<RadioButton>& buttons, int index) {
  for (int i = 0; i < buttons.size(); i++) {
    if (index == i) {
      buttons[i].SetSelected(true);
    } else {
      buttons[i].SetSelected(false);
    }
  }
}
void PrintRadioButtons(const std::vector<RadioButton> buttons) {
  bool print = false;
  int check = -1;
  for (int h = 0; h < buttons.size(); h++) {
    if (buttons[h].IsSelected() == true) {
      check = h;
      std::cout << "(*) " << buttons[h].GetText() << "\n";
    } else {
      std::cout << "( ) " << buttons[h].GetText() << "\n";
    }
  }
  if (check == -1) {
    std::cout << "No button selected yet.\n";
  } else {
    std::cout << "The button at index " << check << " is selected.\n";
  }
}
