#include <iostream>
#include <string>
#include <vector>
class RadioButton {
 private:
  std::string text_;
  bool select_;

 public:
  void SetText(std::string text) { text_ = text; }
  std::string GetText() const { return text_; }
  void SetSelected(bool select) { select_ = select; }
  bool IsSelected() const { return select_; }
};
void PrintRadioButtons(const std::vector<RadioButton> buttons);
void SelectRadioButton(std::vector<RadioButton> &buttons, int index);
