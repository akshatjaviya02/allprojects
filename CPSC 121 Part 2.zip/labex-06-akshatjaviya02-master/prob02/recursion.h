#include <vector>

// Function prototypes for your recursive functions.
// You do NOT need to change this file.

bool IsEven(int value);

int RaiseIntToPower(int value, int power);

int SumArray(std::vector<int> array, int start_index);
