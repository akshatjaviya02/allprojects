#include "recursion.h"
#include <cmath>
#include <iostream>

bool IsEven(int value) {
  // TODO: Fill this in with a recursive solution!
  // The starter code returns false to ensure it will compile, you should delete
  // this and implement your own solution.
  if (value == 0) {
    return 1;
  } else if (value == 1) {
    return 0;
  } else if (value < 0) {
    return IsEven(-value);
  } else {
    return IsEven(value - 2);
  }
}

int RaiseIntToPower(int value, int power) {
  // TODO: Fill this in with a recursive solution!
  // The starter code returns 0 to ensure it will compile, you should delete
  // this and implement your own solution.
  if (power == 0) {
    return 1;
  } else {
    return (value * RaiseIntToPower(value, power - 1));
  }
}

int SumArray(std::vector<int> array, int start_index) {
  // TODO: Fill this in with a recursive solution!
  // The starter code returns 0 to ensure it will compile, you should delete
  // this and implement your own solution.
  if (array.size() == start_index) {
    return 0;
  } else if (array.size() == 1) {
    start_index += array[0];
    return start_index;
  } else {
    return SumArray(array, start_index + 1) + array[start_index];
  }
}
