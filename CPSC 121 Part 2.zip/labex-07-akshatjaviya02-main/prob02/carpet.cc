#include "carpet.h"
#include "cpputils/graphics/image.h"
void DrawCarpet(int x, int y, int size, int order, graphics::Image &image) {
  // Your code here to draw a carpet with top left corner at (x, y), recursive
  const graphics::Color black(0, 0, 0);
  if (order == 0) {
    image.DrawRectangle(x, y, size, size, black);
  } else {
    int size_;
    size_ = size / 3;
    DrawCarpet(x + size_, y, size_, order - 1, image);
    DrawCarpet(x, y + size_, size_, order - 1, image);
    DrawCarpet(x, y, size_, order - 1, image);
    DrawCarpet(x + (2 * size_), y, size_, order - 1, image);
    DrawCarpet(x, y + (2 * size_), size_, order - 1, image);
    DrawCarpet(x + size_, y + size_ * 2, size_, order - 1, image);
    DrawCarpet(x + size_ * 2, y + size_ * 2, size_, order - 1, image);
    DrawCarpet(x + size_ * 2, y + size_, size_, order - 1, image);
  }
}
