#include "recursion.h"
#include <iostream>
#include <map>
#include <string>

// In recursion it's normal to have a helper function call the recursive
// function, passing in the appropriate parameters to start the recursion.
// In this case, the Unscramble function should create a helper function which
// is recursive.
void PermuteForUnscramble(std::string prefix, std::string letters,
                          std::map<std::string, bool> &words) {
  if (letters.size() == 0) {
    if (words[prefix]) {
      std::cout << prefix << "\n";
    }
  } else {
    for (int i = 0; i < letters.size(); i++) {
      char current = letters[i];
      std::string new_prefix = prefix + current;
      std::string remaining = letters;
      remaining.erase(i, 1);
      PermuteForUnscramble(new_prefix, remaining, words);
    }
  }
}
void Unscramble(std::string letters, std::map<std::string, bool> &words) {
  // TODO
  PermuteForUnscramble("", letters, words);
}

// Like Unscramble, ScrabbleSolver should create a helper function which is
// is recursive.
void AllScrabbleSlover(std::string prefix, std::string letters,
                       std::map<std::string, bool> &words) {
  if (letters.size() == 0) {
    if (words[prefix]) {
      std::cout << prefix << "\n";
    }
  } else {
    for (int i = 0; i < letters.size(); i++) {
      char current = letters[i];
      std::string new_prefix = prefix + current;
      std::string remaining = letters;
      remaining.erase(i, 1);
      if (words[prefix]) {
        std::cout << prefix << "\n";
      }
      AllScrabbleSlover(new_prefix, remaining, words);
    }
  }
}
void ScrabbleSolver(std::string letters, std::map<std::string, bool> &words) {
  // TODO
  AllScrabbleSlover("", letters, words);
}

// ScrabbleSolverNoDupes needs to keep track of the previous words which were
// found in order not to print them again. Create a recursive helper function to
// recursively unscramble without duplications.
void AllScrabbleSloverNoDupes(std::map<std::string, bool> &used_words,
                              std::string prefix, std::string letters,
                              std::map<std::string, bool> &words) {
  if (letters.size() == 0) {
    if (words[prefix] && !used_words[prefix]) {
      std::cout << prefix << '\n';
      used_words[prefix] = true;
    }
  } else {
    for (int i = 0; i < letters.size(); i++) {
      char current = letters[i];
      std::string new_prefix = prefix + current;
      std::string remaining = letters;
      remaining.erase(i, 1);
      if (words[new_prefix] && !used_words[new_prefix]) {
        std::cout << new_prefix << "\n";
        used_words[new_prefix] = true;
      }
      AllScrabbleSloverNoDupes(used_words, new_prefix, remaining, words);
    }
  }
}
void ScrabbleSolverNoDupes(std::string letters,
                           std::map<std::string, bool> &words) {
  // TODO
  std::map<std::string, bool> used_words;
  AllScrabbleSloverNoDupes(used_words, "", letters, words);
}
