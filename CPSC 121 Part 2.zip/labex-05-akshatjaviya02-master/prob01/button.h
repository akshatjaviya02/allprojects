#include <iostream>
#include <string>
#include "cpputils/graphics/image.h"
class Button {
 private:
  graphics::Color text_color_;
  double ratio_;
  graphics::Color background_color_;

 public:
  Button(graphics::Color foreground, graphics::Color background)
      : text_color_(foreground), background_color_(background) {}
  graphics::Color GetTextColor() const { return text_color_; }
  graphics::Color GetBackgroundColor() const { return background_color_; }
  double GetContrastRatio() const;
  bool IsAccessible() {
    if (GetContrastRatio() >= 4.5) {
      return true;
    } else {
      return false;
    }
  }
};
int ButtonWithMostContrast(std::vector<Button> &buttons);
