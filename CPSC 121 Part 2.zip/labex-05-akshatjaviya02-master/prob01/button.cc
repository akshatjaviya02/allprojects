// cmath is used for GetScaledChannel.
#include <cmath>

#include "button.h"
#include "cpputils/graphics/image.h"

// Don't forget to include button.h and cpputils/graphics/image.h.

// Use this to scale a color channel from the range (0, 255)
// to the range (0, 1).
double GetScaledChannel(int channel) {
  double scaled = channel / 255.;
  const double min = 0.03928;
  if (scaled <= min) {
    return scaled / 12.92;
  } else {
    return pow((scaled + .055) / 1.055, 2.4);
  }
}

// Implement the functions from button.h here.
double ContrastColor(graphics::Color color) {
  int red = color.Red();
  int green = color.Green();
  int blue = color.Blue();
  double rb = GetScaledChannel(red);
  double gb = GetScaledChannel(green);
  double bb = GetScaledChannel(blue);
  return (.2126 * rb) + (.7152 * gb) + (.0722 * bb);
}
double Button::GetContrastRatio() const {
  double L1, L2;
  double text = ContrastColor(GetTextColor());
  double background = ContrastColor(GetBackgroundColor());
  if (text > background) {
    L1 = text;
    L2 = background;
  } else {
    L1 = background;
    L2 = text;
  }
  return (L1 + 0.05) / (L2 + 0.05);
}
int ButtonWithMostContrast(std::vector<Button> &buttons) {
  int value = 0;
  if (buttons.size() == 1) {
    return 0;
  }
  if (buttons.size() == 2) {
    if (buttons.front().GetContrastRatio() >
        buttons.back().GetContrastRatio()) {
      return 0;
    } else {
      return 1;
    }
  }
  for (int i = 0; i < buttons.size() - 1; i++) {
    if (buttons[i].GetContrastRatio() > buttons[i + 1].GetContrastRatio()) {
      return i;
    }
  }
  return value;
}
