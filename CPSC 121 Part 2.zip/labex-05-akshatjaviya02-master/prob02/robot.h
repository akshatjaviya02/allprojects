#include "cpputils/graphics/image.h"
class Robot {
 private:
  std::string filename1_;
  std::string filename2_;
  int x_;
  int y_;

 public:
  Robot(std::string filename1, std::string filename2)
      : filename1_(filename1), filename2_(filename2) {}

  int GetX() { return x_; }
  int GetY() { return y_; }
  void SetPosition(int x, int y) {
    x_ = x;
    y_ = y;
  }
  void Draw(graphics::Image &image);
};
