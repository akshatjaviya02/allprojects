#include "robot.h"

#include <iostream>
#include <string>

#include "cpputils/graphics/image.h"

void Robot::Draw(graphics::Image &image) {
  static unsigned int count = 0;
  graphics::Image my_Image;

  if (count % 2 == 0) {
    my_Image.Load(filename1_);
  } else if (count % 2 == 1) {
    my_Image.Load(filename2_);
  }
  int wid = my_Image.GetWidth();
  int hei = my_Image.GetHeight();

  for (int h = 0; h < wid; h++) {
    for (int k = 0; k < hei; k++) {
      int red = my_Image.GetRed(h, k);
      int green = my_Image.GetGreen(h, k);
      int blue = my_Image.GetBlue(h, k);

      if ((x_ - (wid + h) >= (hei)) || (y_ - (wid + h) >= (hei))) {
        break;
      } else {
        image.SetRed(x_ - (wid / 2) + h, y_ - (hei / 2) + k, red);
        image.SetGreen(x_ - (wid / 2) + h, y_ - (hei / 2) + k, green);
        image.SetBlue(x_ - (wid / 2) + h, y_ - (hei / 2) + k, blue);
      }
    }
  }

  count++;
}
