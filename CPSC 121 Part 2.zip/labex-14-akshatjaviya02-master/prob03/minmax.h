#include <iostream>
template <class T>
T Maximum(T a, T b) {
  return a < b ? b : a;
}
template <class B>
B Minimum(B a, B b) {
  return a < b ? a : b;
}
