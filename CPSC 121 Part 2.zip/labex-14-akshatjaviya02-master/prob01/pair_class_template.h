#include <iostream>
template <class T>
class MyPair {
 public:
  MyPair(T value1, T value2) : value1_(value1), value2_(value2) {}
  T GetValue1() { return value1_; }
  T GetValue2() { return value2_; }
  void Display() { std::cout << "[" << value1_ << ", " << value2_ << "]"; }
  void DisplayReverse() {
    std::cout << "[" << value2_ << ", " << value1_ << "]";
  }
  T MaxValue() {
    T v2 = value1_;
    if (value2_ > value1_) {
      v2 = value2_;
    } else if (value1_ > value2_) {
      v2 = value1_;
    }
    return v2;
  }
  T MinValue() {
    T v2 = value1_;
    if (value2_ < value1_) {
      v2 = value2_;
    } else if (value1_ < value2_) {
      v2 = value1_;
    }
    return v2;
  }
  void SwapValue() {
    T swap;
    swap = value1_;
    value1_ = value2_;
    value2_ = swap;
  }

 private:
  T value1_;
  T value2_;
};
