// TODO: Include any necessary headers.
#include <iostream>

#include "abstract_bubble.h"
#ifndef BUBBLES_H
#define BUBBLES_H

// TODO: Declare your BigBubble and SmallBubble classes here.
class BigBubble : public AbstractBubble {
 public:
  BigBubble(int x, int y, graphics::Image* image_ptr)
      : AbstractBubble(x, y, image_ptr) {}
  int GetBubbleSize() override;
};

class SmallBubble : public AbstractBubble {
 public:
  SmallBubble(int x, int y, graphics::Image* image_ptr)
      : AbstractBubble(x, y, image_ptr) {}
  int GetBubbleSize() override;
};
#endif  // BUBBLES_H
