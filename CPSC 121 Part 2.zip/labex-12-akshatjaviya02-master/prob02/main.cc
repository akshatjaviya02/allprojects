#include "bubble_jar.h"

int main() {
  // TODO: Update the creation of the BubbleJar to pass in a maximum age.
  BubbleJar jar;
  jar.Initialize(100);
  jar.Start();
  return 0;
}
