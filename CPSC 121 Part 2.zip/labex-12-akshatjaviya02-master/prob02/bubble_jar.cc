#include "bubble_jar.h"
#include <iostream>
#include "bubbles.h"

// Some helpful constants.
const int kSize = 300;
const graphics::Color kWhite(255, 255, 255);

BubbleJar::~BubbleJar() {
  // Clean up state. You do not need to make changes.
  image_.RemoveMouseEventListener(*this);
  image_.RemoveAnimationEventListener(*this);
}

void BubbleJar::Initialize(int age) {
  // TODO: Add to this function per the instructions in the README.
  image_.Initialize(kSize, kSize);
  image_.AddAnimationEventListener(*this);
  image_.AddMouseEventListener(*this);
  age_ = age;
}

void BubbleJar::Start() {
  // Displays the BubbleJar. Feel free to rename the image.
  image_.ShowUntilClosed("Bubble Jar");
}

void BubbleJar::OnMouseEvent(const graphics::MouseEvent& event) {
  std::cout << "BubbleJar got a MouseEvent" << std::endl;
  // TODO: Create a BigBubble on mouse press and a SmallBubble on mouse release
  // and add them to the vector.
  if (event.GetMouseAction() == graphics::MouseAction::kPressed) {
    std::unique_ptr<BigBubble> Big_;
    Big_ = std::make_unique<BigBubble>(event.GetX(), event.GetY(), &image_);
    Big_->Draw();
    bubbles.push_back(std::move(Big_));
    image_.Flush();
  }
  if (event.GetMouseAction() == graphics::MouseAction::kReleased) {
    std::unique_ptr<SmallBubble> small_;
    small_ = std::make_unique<SmallBubble>(event.GetX(), event.GetY(), &image_);
    small_->Draw();
    bubbles.push_back(std::move(small_));
    image_.Flush();
  }
}

void BubbleJar::OnAnimationStep() {
  std::cout << "BubbleJar got an animation step" << std::endl;
  // TODO: Update all the bubbles, making sure to remove the old ones
  // from the vector when they get above the maximum age.
  image_.DrawRectangle(0, 0, 300, 300, 255, 255, 255);
  for (int i = 0; i < bubbles.size(); i++) {
    if (bubbles[i]->GetAge() >= age_) {
      bubbles.erase(bubbles.begin() + i);
      i = i - 1;
    }
  }
  for (int i = 0; i < bubbles.size(); i++) {
    bubbles[i]->Move();
    bubbles[i]->Draw();
  }
  image_.Flush();
}
