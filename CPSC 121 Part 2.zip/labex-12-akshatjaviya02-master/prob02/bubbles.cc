// TODO: Provide implementation of methods from bubbles.h if necessary.
#include "bubbles.h"

int BigBubble::GetBubbleSize() { return 20; }

int SmallBubble::GetBubbleSize() { return 10; }
