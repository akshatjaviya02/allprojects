#include "cat.h"
#ifndef HUMAN_H
#define HUMAN_H

// TODO: Place your Human class here.
class Human {
 public:
  ~Human() { std::cout << human_name_ << " walks away.\n"; }
  std::string GetName() const { return human_name_; }
  void SetName(std::string human_name) { human_name_ = human_name; }
  void Adopt(std::unique_ptr<Cat> cats);
  void TransferTo(Human *humans);
  void Print() const;

 private:
  std::string human_name_;
  std::unique_ptr<Cat> cats_ = nullptr;
};
#endif  // HUMAN_H
