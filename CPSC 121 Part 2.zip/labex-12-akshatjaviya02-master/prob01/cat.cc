#include "cat.h"

// TODO: Implement Cat methods and CreateKitty function here.
std::unique_ptr<Cat> CreateKitty(std::string name) {
  std::unique_ptr<Cat> cats(new Cat);
  cats->SetName(name);
  return cats;
}
