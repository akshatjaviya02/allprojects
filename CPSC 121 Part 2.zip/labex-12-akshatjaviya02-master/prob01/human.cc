#include "human.h"

// TODO: Implement Human methods here.
void Human::Print() const {
  if (cats_) {
    std::cout << GetName() << " is a human with a cat named "
              << cats_->GetName() << std::endl;
  } else {
    std::cout << GetName() << " is a human with no cat\n";
  }
}
void Human::TransferTo(Human *humans) { humans->Adopt(std::move(cats_)); }
void Human::Adopt(std::unique_ptr<Cat> cats) { cats_ = std::move(cats); }
