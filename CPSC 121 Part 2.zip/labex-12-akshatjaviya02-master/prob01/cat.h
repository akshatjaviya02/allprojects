#include <iostream>
#include <memory>
#include <string>
#ifndef CAT_H
#define CAT_H

// TODO: Place your Cat class and CreateKitty function here.
class Cat {
 public:
  ~Cat() { std::cout << name_ << " stalks away.\n"; }
  std::string GetName() const { return name_; }
  void SetName(std::string name) { name_ = name; }

 private:
  std::string name_;
};

std::unique_ptr<Cat> CreateKitty(std::string name);
#endif  // CAT_H
