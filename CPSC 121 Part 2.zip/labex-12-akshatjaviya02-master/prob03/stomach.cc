// TODO: Include any necessary headers.

// TODO: Implement necessary Stomach class methods here.
