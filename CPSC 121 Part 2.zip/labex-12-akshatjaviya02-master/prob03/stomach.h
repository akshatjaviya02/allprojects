// TODO: Include any necessary headers

#ifndef STOMACH_H
#define STOMACH_H

// TODO: Stomach class here.

#endif  // STOMACH_H
