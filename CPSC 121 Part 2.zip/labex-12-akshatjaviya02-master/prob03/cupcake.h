// TODO: Include any necessary headers.

#ifndef CUPCAKE_H
#define CUPCAKE_H

// TODO: Cupcake class here.

#endif  // CUPCAKE_H
