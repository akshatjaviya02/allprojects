// TODO: Include any necessary headers.

int main() {
  std::string flavor1;
  std::string flavor2;
  std::cout << "What is the first flavor? ";
  std::cin >> flavor1;
  std::cout << "What is the second flavor? ";
  std::cin >> flavor2;

  // TODO: Your code here.

  return 0;
}
