#include <cmath>                                                      // abs(), pow()
#include <compare>                                                    // weak_ordering
#include <iomanip>                                                    // quoted()
#include <iostream>
#include <string>
#include <type_traits>                                                // is_floating_point_v, common_type_t
#include <utility>                                                    // move()

#include "Book.hpp"



// C++20 Transition Workaround
//
// Clang (well, more accurately libc++) 12.0.* and before doesn't define and implement operator<=>(string, string) yet.
// Update this section as new versions of Clang are released that still do not implement these capabilities.
#if defined( _LIBCPP_VERSION )
#  if _LIBCPP_VERSION < 13'000
     namespace std
     {
       strong_ordering operator<=>( string const & lhs, string const & rhs) noexcept
       {
         int comp = lhs.compare( rhs );
         return comp == 0  ?   strong_ordering::equivalent
              : comp  < 0  ?   strong_ordering::less
              :                strong_ordering::greater;
       }
     }
#  else
#    pragma message ("A potentially obsolete C++20 workaround is present.  Either remove the workaround if no longer needed, or update the version number requiring it")
#  endif
#endif












/*******************************************************************************
**  Implementation of non-member private types, objects, and functions
*******************************************************************************/
namespace    // unnamed, anonymous namespace
{
  // Avoid direct equality comparisons on floating point numbers. Two values are equal if they are "close enough", which is
  // represented by Epsilon.  Usually, this is a pretty small number, but since we are dealing with money (only two, maybe three
  // decimal places) we can be a bit more tolerant.  Two floating point values are considered equal if they are within EPSILON of
  // each other.
  template< typename T,  typename U >   requires std::is_floating_point_v<std::common_type_t<T, U> >
  constexpr bool floating_point_is_equal( T const lhs,  U const rhs,  double const EPSILON = 1e-4 ) noexcept
  {
    ///////////////////////// TO-DO (1) //////////////////////////////
      ///  Write the lines of code that compare two floating point numbers.  Return true when the left hand side (lhs) and the right
      ///  hand side (rhs) are within Epsilon, and false otherwise.
      ///
      ///  See: "Floating point equality" in https://www.learncpp.com/cpp-tutorial/relational-operators-and-floating-point-comparisons/
      ///
      ///  Hint:  Avoid writing code that looks like this:
      ///           if( some expression that is true ) return the constant "true"
      ///           else                               return the constant "false"
      ///         for example, avoid:
      ///           if (a < b) return true;
      ///           else       return false;
      ///         do this instead:
      ///           return a < b;
      if(std::abs(lhs - rhs) < EPSILON)  // to compare price that it is same until 1e-4.
      {
        return true;
      }
      return false;
    /////////////////////// END-TO-DO (1) ////////////////////////////
  }
}    // unnamed, anonymous namespace







/*******************************************************************************
**  Constructors, assignments, and destructor
*******************************************************************************/

// Default and Conversion Constructor
Book::Book( std::string title,  std::string author,  std::string isbn,  double price )
///////////////////////// TO-DO (2) //////////////////////////////
:  _isbn(isbn), _title(title), _author(author), _price(price) {} // it will set variable according if the user don't pass any variable then it will be empty
/////////////////////// END-TO-DO (2) ////////////////////////////




// Copy constructor
Book::Book( Book const & other )
///////////////////////// TO-DO (3) //////////////////////////////
 : _isbn(other._isbn), _title(other._title), _author(other._author), _price(other._price) {} // create a temporary reference of the book object
/////////////////////// END-TO-DO (3) ////////////////////////////




// Move constructor
Book::Book( Book && other ) noexcept
///////////////////////// TO-DO (4) //////////////////////////////
: _isbn(std::move(other._isbn)), _title(std::move(other._title)), _author(std::move(other._author)), _price(std::move(other._price)) {} // using the std::Move to move ownership to the original or permanent
/////////////////////// END-TO-DO (4) ////////////////////////////




// Copy Assignment Operator
Book & Book::operator=( Book const & rhs ) &
///////////////////////// TO-DO (5) //////////////////////////////
{
  if(this != &rhs)
  {
    _isbn = rhs._isbn;
    _title = rhs._title;
    _author = rhs._author;
    _price = rhs._price;
  }
  return *this;
}
//This function is deep copy.
// This function checks for if the rhs which is the object reference of Book class.
// if the rhs is not equal to the Book class then set the values of the rhs obeject to object of the class to Book
/////////////////////// END-TO-DO (5) ////////////////////////////




// Move Assignment Operator
Book & Book::operator=( Book && rhs ) & noexcept
///////////////////////// TO-DO (6) //////////////////////////////
{
  if(this != &rhs)
  {
    _isbn = std::move(rhs._isbn);
    _title = std::move(rhs._title);
    _author = std::move(rhs._author);
    _price = std::move(rhs._price);
  }
  return *this;
}
// This function is considered as shallow copy.
// Because you are moving ownership to Book's object from rhs's object.
/////////////////////// END-TO-DO (6) ////////////////////////////



// Destructor
Book::~Book() noexcept
///////////////////////// TO-DO (7) //////////////////////////////
{} // At the end it will destory everything
/////////////////////// END-TO-DO (7) ////////////////////////////








/*******************************************************************************
**  Accessors
*******************************************************************************/

// isbn() const
std::string const & Book::isbn() const &
{
  ///////////////////////// TO-DO (8) //////////////////////////////
  return _isbn; // Isbn is Accessor for the private data member of Book class _isbn and is for l-value.
  /////////////////////// END-TO-DO (8) ////////////////////////////
}




// title() const
std::string const & Book::title() const &
{
  ///////////////////////// TO-DO (9) //////////////////////////////
  return _title; // Title is Accessor for the private data member of Book class _title and is for l-value.
  /////////////////////// END-TO-DO (9) ////////////////////////////
}




// author() const
std::string const & Book::author() const &
{
  ///////////////////////// TO-DO (10) //////////////////////////////
  return _author; // Author is Accessor for the private data member of Book class _author and is for l-value.
  /////////////////////// END-TO-DO (10) ////////////////////////////
}



// price() const
double Book::price() const &
{
  ///////////////////////// TO-DO (11) //////////////////////////////
  return _price; // Price is Accessor for the private data member of Book class _price and is for l-value.
  /////////////////////// END-TO-DO (11) ////////////////////////////
}




// isbn()
std::string Book::isbn() &&
{
  ///////////////////////// TO-DO (12) //////////////////////////////
  return std::move(_isbn); // Isbn is Accessor for the private data member of Book class _isbn and is for r-value.
  /////////////////////// END-TO-DO (12) ////////////////////////////
}




// title()
std::string Book::title() &&
{
  ///////////////////////// TO-DO (13) //////////////////////////////
  return std::move(_title); // Title is Accessor for the private data member of Book class _title and is for r-value.
  /////////////////////// END-TO-DO (13) ////////////////////////////
}




// author()
std::string Book::author() &&
{
  ///////////////////////// TO-DO (14) //////////////////////////////
  return std::move(_author); // Author is Accessor for the private data member of Book class _author and is for r-value.
  /////////////////////// END-TO-DO (14) ////////////////////////////
}








/*******************************************************************************
**  Modifiers
*******************************************************************************/

// isbn()
Book & Book::isbn( std::string newIsbn ) &
{
  ///////////////////////// TO-DO (15) //////////////////////////////
  _isbn = newIsbn;
  return *this; // Isbn is Modifier for the private data member of Book class _isbn.
  /////////////////////// END-TO-DO (15) ////////////////////////////
}




// title()
Book & Book::title( std::string newTitle ) &
{
  ///////////////////////// TO-DO (16) //////////////////////////////
  _title = newTitle;
  return *this; // Title is Modifier for the private data member of Book class _title.
  /////////////////////// END-TO-DO (16) ////////////////////////////
}




// author()
Book & Book::author( std::string newAuthor ) &
{
  ///////////////////////// TO-DO (17) //////////////////////////////
  _author = newAuthor;
  return *this; // Author is Modifier for the private data member of Book class _author.
  /////////////////////// END-TO-DO (17) ////////////////////////////
}




// price()
Book & Book::price( double newPrice ) &
{
  ///////////////////////// TO-DO (18) //////////////////////////////
  _price = newPrice;
  return *this; // Price is Modifier for the private data member of Book class _price.
  /////////////////////// END-TO-DO (18) ////////////////////////////
}








/*******************************************************************************
**  Relational Operators
*******************************************************************************/

// operator<=>
std::weak_ordering Book::operator<=>( const Book & rhs ) const noexcept
{
  // Design decision:  A very simple and convenient defaulted 3-way comparison operator
  //                         auto operator<=>( const Book & ) const = default;
  //                   in the class definition (header file) would get very close to what is needed and would allow both the <=> and
  //                   the == operators defined here to be skipped.  The physical ordering of the attributes in the class definition
  //                   would have to be changed (easy enough in this case) but the default directly compares floating point types
  //                   (price) for equality, and that should be avoided, in general. For example, if x and y are of type double,
  //                   then x < y is okay but x == y is not.  So these (operator<=> and operator==) explicit definitions are
  //                   provided.
  //
  //                   Also, many ordering (sorting) algorithms, like those used in std::map and std::set, require at least a weak
  //                   ordering of elements. operator<=> provides only a partial ordering when comparing floating point numbers.
  //
  // Weak order:       Objects that compare equal but are not substitutable (identical).  For example, since _price can be within
  //                   EPSILON, Book("Title", "Author", "ISBN", 9.99999) and Book("Title", "Author", "ISBN", 10.00001) are equal but
  //                   they are not identical.  If you ignore case when comparing strings, as another example, Book("Title") and
  //                   Book("title") are equal but they are not identical.
  //
  // See std::weak_ordering    at https://en.cppreference.com/w/cpp/utility/compare/weak_ordering and
  //     std::partial_ordering at https://en.cppreference.com/w/cpp/utility/compare/partial_ordering
  //     The Three-Way Comparison Operator at  http://modernescpp.com/index.php/c-20-the-three-way-comparison-operator
  //     Spaceship (Three way comparison) Operator Demystified https://youtu.be/S9ShnAFmiWM
  //
  //
  // Books are equal if all attributes are equal (or within Epsilon for floating point numbers, like price). Books are ordered
  // (sorted) by ISBN, author, title, then price.

  ///////////////////////// TO-DO (19) //////////////////////////////
  if(auto result = _isbn <=> rhs._isbn; result != 0) // The code will run the statement before the semi colon and then the argument.
  {
    return result; //  wanted to declare the reuslt in the scope and didn't wanted to create in gobally throughtout the function.
  }
  if(auto result = _author <=> rhs._author; result != 0) // <=> will compare the variables three way.
  {
    return result;
  }
  if(auto result = _title <=> rhs._title; result != 0)
  {
    return result;
  }
  if(floating_point_is_equal(_price, rhs._price)){
    return std::weak_ordering::equivalent; // equall will return 0.
  }
  if(_price > rhs._price)
  {
    return std::weak_ordering::greater; // greater will return +1.
  }
  else {
    return std::weak_ordering::less; // There is weaking odering in std namespace and less is under weak_ordering namespace.
  } // less will return -1.
  /////////////////////// END-TO-DO (19) ////////////////////////////
}




// operator==
bool Book::operator==( const Book & rhs ) const noexcept
{
  // All attributes must be equal for the two books to be equal to the other.  This can be done in any order, so put the quickest
  // and then the most likely to be different first.

  ///////////////////////// TO-DO (20) //////////////////////////////
  if(!floating_point_is_equal(_price, rhs._price)) // to compares floating point double
  {
    return false;
  }
  if(_isbn != rhs._isbn)
  {
    return false;
  }
  if(_title != rhs._title)
  {
    return false;
  }
  return _author == rhs._author; // will return true if the author is same and false if the other elments are true but author is not true.
  /////////////////////// END-TO-DO (20) ////////////////////////////
}








/*******************************************************************************
**  Insertion and Extraction Operators
*******************************************************************************/

// operator>>
std::istream & operator>>( std::istream & stream, Book & book )
{
  ///////////////////////// TO-DO (21) //////////////////////////////
    /// A lot can go wrong when reading from streams - no permission, wrong types, end of file, etc. Minimal exception guarantee says
    /// there should be no side affects if an error or exception occurs, so let's do our work in a local object and move it into place
    /// at the end if all goes well.
    ///
    /// This function should be symmetrical with operator<< below.  Read what your write, and write what you read
    ///
    ///
    /// Assume fields are separated by commas and string attributes are enclosed with double quotes.  For example:
    ///    ISBN             | Title                 | Author             | Price
    ///    -----------------+-----------------------+--------------------+-----
    ///    "9789998287532",   "Over in the Meadow",   "Ezra Jack Keats",   91.11
    ///
    ///
    /// Hint:  Use std::quoted to read and write quoted strings.  See
    ///        1) https://en.cppreference.com/w/cpp/io/manip/quoted
    ///        2) https://www.youtube.com/watch?v=Mu-GUZuU31A
    Book b1;
    char comma[3];
    stream >> std::quoted(b1._isbn) >> comma[0] >> std::quoted(b1._title) >> comma[1] >> std::quoted(b1._author) >> comma[2] >> b1._price;
    // std::quoted will read from double quoted to end of the quoted it is very handy tool to use in c++.
    if((stream) && (comma[0] == ',') && (comma[1] == ',') && (comma[2] == ',')) // check weather the read was properly done or not and also if the comma was read and not something else.
    {
      book = b1;
    }
    else
    {
      stream.setstate(std::ios::failbit); // set the stream to fail.
    }
   return stream;
  /////////////////////// END-TO-DO (21) ////////////////////////////
}




// operator<<
std::ostream & operator<<( std::ostream & stream, const Book & book )
{
  ///////////////////////// TO-DO (22) //////////////////////////////
    /// This function should be symmetrical with operator>> above.  Read what your write, and write what you read
  const std::string C1 = ", ";
  stream << std::quoted(book.isbn()) << C1 << std::quoted(book.title()) << C1 << std::quoted(book.author()) << C1 << book.price();
  return stream;
  // In the code it is seen a way that how  you read that's how the you write in file or output.
  /////////////////////// END-TO-DO (22) ////////////////////////////
}
