#include <memory>                                                     // For smart Pointers
#include <vector>                                                     // For vector
#include "Book.hpp"

int main()
{
  std::cout << "Welcome to Forgotten Books, a bookstore filled with books from all nations.  Place books into your shopping cart by entering each book's information."
            << "\n   enclose string entries in quotes, separate fields with comas"
            << "\n   Enter CTL-Z (Windows) or CTL-D (Linux) to quit\n\n";
  std::vector<std::unique_ptr<Book>> my_book; // vector hoding pointer of the Book object.
  Book b; // create a book object to read in the isbn, title, author, price.
  while(std::cout << "Enter ISBN, Title, Author, and Price:\n", std::cin >> b)
  {
    my_book.push_back(std::make_unique<Book>(std::move(b))); // making the b object to unique pointer to move the ownership to my_book vector.
    std::cout << "Item added to shopping cart:" << *my_book.back() << "\n\n";
  }
  std::cout << "\n\nHere is an itemized list of the items in your shopping cart:\n";
  for (auto i = my_book.size(); i > 0; i--) {
        std::cout << *my_book[i - 1] << " ";
        std::cout << "\n";
    } // This for loop will print books from last read first print and first read last to print.
  return 0;
}
